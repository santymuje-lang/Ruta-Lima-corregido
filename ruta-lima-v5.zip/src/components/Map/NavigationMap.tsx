import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as maplibregl from 'maplibre-gl';
import type { StyleSpecification } from 'maplibre-gl';
import maplibreWorkerCode from 'maplibre-gl/dist/maplibre-gl-worker.mjs?raw';
import {
  Coordinates,
  GPSLocation,
  MapPOI,
  MapTileMode,
  RouteData,
  RouteStep,
  SearchResult,
  TrafficAlert,
  TrafficAlertType,
  TravelMode,
} from '../../types/navigation';
import { Compass, LocateFixed, Layers, Settings, AlertTriangle, Navigation, X, Check, MapPin, Trash2, PlusCircle, Share2, Loader2 } from 'lucide-react';
import { MapSettingsModal, MapSettingsData } from './MapSettingsModal';
import { AddFixedRadarModal } from './AddFixedRadarModal';
import { FixedRadar } from '../../data/fixedRadars';
import {
  confirmFixedRadarLocation,
  getActiveRegionsForFilter,
  getMergedFixedRadarsForRegions,
  reportFixedRadarRemoved,
  resolvePendingRadarsForRegions,
} from '../../services/fixedRadars';
import { reverseGeocodeCoords } from '../../services/nominatim';
import { voiceGuidance } from '../../services/tts';
import { logSystemNotice } from '../../services/systemNotices';
import {
  isAlertExpired,
  getInspectorMarkerOpacity,
} from '../../services/alertLifecycle';
import {
  getPoliceSubtypeLabel,
  normalizePoliceSubtype,
  renderPoliceMarkerSvg,
} from '../../services/policeReports';
import {
  getInspectorSubtypeImage,
  getInspectorSubtypeLabel,
  normalizeInspectorSubtype,
  renderInspectorMarkerHtml,
} from '../../services/inspectorReports';
import {
  closeAllSmallOverlays,
  hasAnyOpenSmallOverlay,
  notifySmallOverlayClose,
  notifySmallOverlayOpen,
  shouldSuppressMapClick,
} from '../../services/overlayCoordinator';
import {
  matchUserToRoute,
  getBearing,
  getDistanceMeters,
  projectPointOnSegment,
} from '../../services/routeMatching';
import {
  DEFAULT_POI_CATEGORIES,
  GeoBounds,
  PIZZA_ICON_SVG,
  POI_CATEGORY_META,
  boundsOverlapRatio,
  doesBoundsCover,
  expandBoundsSlightly,
  fetchOverpassPOIsForBounds,
  formatPoiDistance,
  getAllCachedPois,
  getPoiDetailLevelForZoom,
  getPoiSortKey,
  getPoiZoomTier,
  ingestVectorTileFeatures,
  isBoundsCoveredByCache,
} from '../../services/overpassPoi';
import { getPoiIconKey, registerPoiMapIcons } from '../../services/poiMapIcons';
import {
  CarriagewaySnapResult,
  formatDirectionLabelSpanish,
  getAlertTargetCoords,
  getOppositeHeading,
  shortestAngularDiffDeg,
} from '../../services/reportDirection';

// Solo lugares útiles para la conducción mientras hay navegación activa (CAMBIO 5)
const NAV_USEFUL_POI_CATEGORIES = new Set<string>([
  'fuel',
  'hospital',
  'bus_stop',
  'subway',
  'police',
  'fire_station',
  'school',
]);

function getCommunityAlertVisual(type: TrafficAlertType): {
  bgHex: string;
  bubbleIconSvg: string;
  cardIconSvg: string;
} {
  let bgHex = '#f59e0b';
  let svgAttrs =
    'viewBox="0 0 24 24" fill="none" stroke="#ffffff" color="#ffffff"';
  let innerPaths = `
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
  `;

  if (type === 'accident') {
    bgHex = '#e11d48';
    svgAttrs =
      'viewBox="0 0 24 24" fill="none" stroke="#ffffff" color="#ffffff"';
    innerPaths = `
      <path d="M2 15h6l2-2.5V11L7 8H3.5L2 11v4z" stroke-width="1.5" stroke-linejoin="round" fill="currentColor" fill-opacity="0.3" />
      <path d="M22 15h-6l-2-2.5V11l3-3h3.5L22 11v4z" stroke-width="1.5" stroke-linejoin="round" fill="currentColor" fill-opacity="0.3" />
      <path d="M12 4l.6 1.8 1.8.6-1.8.6-.6 1.8-.6-1.8-1.8-.6 1.8-.6z" fill="#fecdd3" stroke="#fecdd3" stroke-width="0.5" />
    `;
  } else if (type === 'construction') {
    bgHex = '#f97316';
    svgAttrs = 'viewBox="0 0 24 24" fill="none"';
    innerPaths = `
      <rect x="3" y="19" width="18" height="2.5" rx="1.2" fill="#ffffff" />
      <polygon points="12,2.5 10.5,8 13.5,8" fill="#ffffff" />
      <polygon points="10.5,8 9.2,12 14.8,12 13.5,8" fill="#fed7aa" />
      <polygon points="9.2,12 8,15.5 16,15.5 14.8,12" fill="#ffffff" />
      <polygon points="8,15.5 6.8,19 17.2,19 16,15.5" fill="#fed7aa" />
    `;
  } else if (type === 'pothole') {
    bgHex = '#d97706';
    svgAttrs = 'viewBox="0 0 24 24" fill="none"';
    innerPaths = `
      <path d="M2 13h4.5c1 1.5 2 3.5 5.5 3.5s4.5-2 5.5-3.5H22" stroke="#ffffff" stroke-width="2" stroke-linecap="round" />
      <g transform="translate(12, 11) rotate(22) translate(-12, -11)">
        <circle cx="12" cy="11" r="4.5" stroke="#ffffff" stroke-width="2" fill="#78350f" fill-opacity="0.5" />
        <circle cx="12" cy="11" r="1.8" fill="#fef3c7" />
      </g>
    `;
  } else if (type === 'broken_light') {
    bgHex = '#eab308';
    svgAttrs = 'viewBox="0 0 24 24" fill="none"';
    innerPaths = `
      <rect x="7.5" y="2" width="9" height="17" rx="3.5" fill="#0f172a" stroke="#ffffff" stroke-width="1.6" />
      <circle cx="12" cy="5.5" r="1.5" fill="#ef4444" fill-opacity="0.4" />
      <circle cx="12" cy="10.5" r="1.5" fill="#eab308" fill-opacity="0.4" />
      <circle cx="12" cy="15.5" r="1.5" fill="#22c55e" fill-opacity="0.3" />
      <path d="M17 7l-3 4h2.5l-3.5 5" stroke="#facc15" stroke-width="1.8" stroke-linecap="round" />
    `;
  } else if (type === 'road_closed') {
    bgHex = '#b91c1c';
    svgAttrs = 'viewBox="0 0 24 24" fill="none"';
    innerPaths = `
      <circle cx="12" cy="12" r="9" fill="#dc2626" fill-opacity="0.3" stroke="#ffffff" stroke-width="1.8" />
      <rect x="6" y="10.5" width="12" height="3" rx="1" fill="#ffffff" />
    `;
  } else if (type === 'stopped_vehicle') {
    bgHex = '#9333ea';
    svgAttrs =
      'viewBox="0 0 24 24" fill="none" stroke="#ffffff" color="#ffffff"';
    innerPaths = `
      <path d="M3 15h18v3H3z" stroke-width="1.5" />
      <path d="M5 15l2-5h5l2 5" stroke-width="1.5" fill="currentColor" fill-opacity="0.3" />
      <line x1="14" y1="15" x2="19" y2="10.5" stroke-width="1.8" stroke-linecap="round" />
      <circle cx="7" cy="18" r="1.2" fill="currentColor" />
      <circle cx="17" cy="18" r="1.2" fill="currentColor" />
    `;
  } else if (type === 'speed_camera') {
    bgHex = '#c026d3';
    svgAttrs =
      'viewBox="0 0 24 24" fill="none" stroke="#ffffff" color="#ffffff"';
    innerPaths = `
      <rect x="4" y="6" width="13.5" height="8.5" rx="2.2" stroke-width="1.7" fill="currentColor" fill-opacity="0.25" />
      <circle cx="10.8" cy="10.2" r="2.3" stroke-width="1.6" fill="#fae8ff" fill-opacity="0.35" />
      <path d="M10.8 14.5v5.5M7.5 20h6.6" stroke-width="1.7" stroke-linecap="round" />
      <path d="M19 8.2a3.2 3.2 0 0 1 0 4.1M21 6.6a5.5 5.5 0 0 1 0 7.3" stroke="#fae8ff" stroke-width="1.6" stroke-linecap="round" />
    `;
  } else if (type === 'flood') {
    bgHex = '#0891b2';
    svgAttrs =
      'viewBox="0 0 24 24" fill="none" stroke="#ffffff" color="#ffffff"';
    innerPaths = `
      <path d="M8 4.2s2.2 2.7 2.2 4a2.2 2.2 0 1 1-4.4 0c0-1.3 2.2-4 2.2-4z" fill="currentColor" fill-opacity="0.35" stroke-width="1.5" />
      <path d="M16 3.5s2.2 2.7 2.2 4a2.2 2.2 0 1 1-4.4 0c0-1.3 2.2-4 2.2-4z" fill="currentColor" fill-opacity="0.35" stroke-width="1.5" />
      <path d="M3 15.2c1.5 1.3 3 1.3 4.5 0s3-1.3 4.5 0 3 1.3 4.5 0 3-1.3 4.5 0" stroke-width="1.9" stroke-linecap="round" />
      <path d="M3 19c1.5 1.3 3 1.3 4.5 0s3-1.3 4.5 0 3 1.3 4.5 0 3-1.3 4.5 0" stroke="#cffafe" stroke-width="1.9" stroke-linecap="round" />
    `;
  } else if (type === 'traffic') {
    bgHex = '#ef4444';
    svgAttrs =
      'viewBox="0 0 24 24" fill="none" stroke="#ffffff" color="#ffffff"';
    innerPaths = `
      <path d="M4 14l1.5-4.5h5L12 14v4H4v-4z" stroke-width="1.5" fill="currentColor" fill-opacity="0.3" />
      <circle cx="6" cy="18" r="1.2" fill="currentColor" />
      <circle cx="10" cy="18" r="1.2" fill="currentColor" />
      <path d="M13 11l1.2-3.5h4L19.5 11v3H13v-3z" stroke-width="1.4" />
    `;
  }

  return {
    bgHex,
    bubbleIconSvg: `<svg x="18.5" y="15.5" width="27" height="27" ${svgAttrs}>${innerPaths}</svg>`,
    cardIconSvg: `<svg width="24" height="24" style="display:block;" ${svgAttrs}>${innerPaths}</svg>`,
  };
}

function isPoiNearActiveRoute(
  poiLat: number,
  poiLng: number,
  routeCoords: [number, number][],
  maxDistMeters = 150
): boolean {
  if (!routeCoords || routeCoords.length < 2) return true;
  // Filtro rápido por caja aproximada (~0.002° ≈ 220m) antes de proyectar por segmento
  const latMargin = 0.0022;
  const lngMargin = 0.0022;
  for (let i = 0; i < routeCoords.length - 1; i++) {
    const a = routeCoords[i];
    const b = routeCoords[i + 1];
    const minLat = Math.min(a[0], b[0]) - latMargin;
    const maxLat = Math.max(a[0], b[0]) + latMargin;
    if (poiLat < minLat || poiLat > maxLat) continue;
    const minLng = Math.min(a[1], b[1]) - lngMargin;
    const maxLng = Math.max(a[1], b[1]) + lngMargin;
    if (poiLng < minLng || poiLng > maxLng) continue;

    const proj = projectPointOnSegment(poiLat, poiLng, a[0], a[1], b[0], b[1]);
    if (proj.distanceMeters <= maxDistMeters) {
      return true;
    }
  }
  return false;
}

if (typeof window !== 'undefined' && typeof Blob !== 'undefined' && typeof URL !== 'undefined') {
  const maplibreWorkerBlobUrl = URL.createObjectURL(
    new Blob([maplibreWorkerCode], { type: 'text/javascript' })
  );
  maplibregl.setWorkerUrl(maplibreWorkerBlobUrl);
}

// Storage key for user preferences persistence across sessions
const SETTINGS_STORAGE_KEY = 'ruta_lima_map_config';

// Inclinación única de cámara en navegación activa (55° idénticos en Día, Noche y Satelital)
const NAV_PITCH_DEGREES = 55;

// Constantes de ajuste fino para la pantalla principal (sin ruta activa)
const ZOOM_PANTALLA_PRINCIPAL = 17.5;

// Zoom dinámico según velocidad (estilo Waze): detenido = cerca, avenida rápida = lejos
const SPEED_ZOOM_STOPS: Array<[number, number]> = [
  [0, 18.0],
  [20, 17.4],
  [50, 16.3],
  [80, 15.2],
  [100, 15.0],
];
// Zoom de aproximación a maniobra: desde 200 m se acerca suavemente; a ≤150 m queda en 18.0
const MANEUVER_ZOOM = 18.0;
const MANEUVER_ZOOM_START_M = 200;
const MANEUVER_ZOOM_FULL_M = 150;

function speedToZoom(speedKmh: number): number {
  const v = Math.max(0, Number.isFinite(speedKmh) ? speedKmh : 0);
  if (v >= SPEED_ZOOM_STOPS[SPEED_ZOOM_STOPS.length - 1][0]) {
    return SPEED_ZOOM_STOPS[SPEED_ZOOM_STOPS.length - 1][1];
  }
  for (let i = 1; i < SPEED_ZOOM_STOPS.length; i++) {
    const [v1, z1] = SPEED_ZOOM_STOPS[i];
    if (v <= v1) {
      const [v0, z0] = SPEED_ZOOM_STOPS[i - 1];
      return z0 + ((v - v0) / (v1 - v0)) * (z1 - z0);
    }
  }
  return SPEED_ZOOM_STOPS[0][1];
}
const INCLINACION_PANTALLA_PRINCIPAL = 60;
const POSICION_FLECHA_ABAJO = 0.25;

// MapLibre vector styles with OpenFreeMap (liberty -> bright -> OpenStreetMap raster fallback)
const OPENFREEMAP_LIBERTY_STYLE_URL = 'https://tiles.openfreemap.org/styles/liberty';
const OPENFREEMAP_BRIGHT_STYLE_URL = 'https://tiles.openfreemap.org/styles/bright';
const OSM_RASTER_TILES = ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'];
const OSM_ATTRIBUTION = '© OpenStreetMap contributors';

type OpenFreeMapFallbackStage = 'liberty' | 'bright' | 'osm_raster';

const OSM_RASTER_DAY_STYLE: StyleSpecification = {
  version: 8,
  sources: {
    osm_tiles: {
      type: 'raster',
      tiles: OSM_RASTER_TILES,
      tileSize: 256,
      maxzoom: 19,
      attribution: OSM_ATTRIBUTION,
    },
  },
  layers: [
    {
      id: 'osm-day-background-layer',
      type: 'background',
      paint: {
        'background-color': '#f3f4f6',
      },
    },
    {
      id: 'osm-day-raster-layer',
      type: 'raster',
      source: 'osm_tiles',
    },
  ],
};

const OSM_RASTER_NIGHT_STYLE: StyleSpecification = {
  version: 8,
  sources: {
    osm_tiles: {
      type: 'raster',
      tiles: OSM_RASTER_TILES,
      tileSize: 256,
      maxzoom: 19,
      attribution: OSM_ATTRIBUTION,
    },
  },
  layers: [
    {
      id: 'osm-night-background-layer',
      type: 'background',
      paint: {
        'background-color': '#1e293b',
      },
    },
    {
      id: 'osm-night-raster-layer',
      type: 'raster',
      source: 'osm_tiles',
      paint: {
        'raster-brightness-min': 0.04,
        'raster-brightness-max': 0.56,
        'raster-saturation': -0.35,
        'raster-contrast': 0.24,
        'raster-opacity': 0.96,
      },
    },
  ],
};

const SATELLITE_STYLE: StyleSpecification = {
  version: 8,
  sources: {
    esri_imagery: {
      type: 'raster',
      tiles: [
        'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      ],
      tileSize: 256,
      maxzoom: 18,
      attribution: '&copy; Esri, Maxar, Earthstar Geographics',
    },
  },
  layers: [
    {
      id: 'esri-imagery-layer',
      type: 'raster',
      source: 'esri_imagery',
    },
  ],
};

function normalizeHeadingDeg(deg: number): number {
  if (!Number.isFinite(deg)) return 0;
  return ((deg % 360) + 360) % 360;
}

function shortestAngleDiffDeg(fromDeg: number, toDeg: number): number {
  return ((toDeg - fromDeg + 540) % 360) - 180;
}

function offsetCoordByMeters(
  lat: number,
  lng: number,
  distMeters: number,
  bearingDeg: number
): [number, number] {
  if (!Number.isFinite(distMeters) || distMeters <= 0) return [lat, lng];
  const rad = (bearingDeg * Math.PI) / 180;
  const latRad = (lat * Math.PI) / 180;
  const metersPerDegLng = Math.max(1e-5, 111320 * Math.cos(latRad));
  const dLat = (distMeters * Math.cos(rad)) / 110540;
  const dLng = (distMeters * Math.sin(rad)) / metersPerDegLng;
  return [lat + dLat, lng + dLng];
}

function projectPointOntoRoutePolyline(
  lat: number,
  lng: number,
  coords: [number, number][],
  hintSegIdx = 0
): { point: [number, number]; segmentIndex: number; segmentBearing: number; distanceMeters: number } {
  const lastSegIdx = Math.max(0, coords.length - 2);
  const clampedHint = Math.max(0, Math.min(lastSegIdx, hintSegIdx));
  const searchStart = Math.max(0, clampedHint - 8);
  const searchEnd = Math.min(lastSegIdx, clampedHint + 28);

  let minDistance = Infinity;
  let bestSegment = clampedHint;
  let bestPoint: [number, number] = [lat, lng];

  for (let i = searchStart; i <= searchEnd; i++) {
    const a = coords[i];
    const b = coords[i + 1];
    const proj = projectPointOnSegment(lat, lng, a[0], a[1], b[0], b[1]);
    if (proj.distanceMeters < minDistance) {
      minDistance = proj.distanceMeters;
      bestSegment = i;
      bestPoint = proj.point;
    }
  }

  // Fallback full scan if point drifted away from hint window
  if (minDistance > 25 && (searchStart > 0 || searchEnd < lastSegIdx)) {
    for (let i = 0; i <= lastSegIdx; i++) {
      if (i >= searchStart && i <= searchEnd) continue;
      const a = coords[i];
      const b = coords[i + 1];
      const proj = projectPointOnSegment(lat, lng, a[0], a[1], b[0], b[1]);
      if (proj.distanceMeters < minDistance) {
        minDistance = proj.distanceMeters;
        bestSegment = i;
        bestPoint = proj.point;
      }
    }
  }

  const segA = coords[bestSegment];
  const segB = coords[Math.min(bestSegment + 1, coords.length - 1)];
  const segmentBearing = normalizeHeadingDeg(getBearing(segA[0], segA[1], segB[0], segB[1]));

  return {
    point: bestPoint,
    segmentIndex: bestSegment,
    segmentBearing,
    distanceMeters: minDistance,
  };
}

interface IdleRoadSegment {
  a: [number, number];
  b: [number, number];
  halfWidthMeters: number;
}

const DRIVABLE_ROAD_QUERY_LAYERS = [
  'road_motorway',
  'bridge_motorway',
  'tunnel_motorway',
  'highway-motorway',
  'bridge-motorway',
  'road_motorway_link',
  'bridge_motorway_link',
  'tunnel_motorway_link',
  'highway-motorway-link',
  'bridge-motorway-link',
  'road_trunk_primary',
  'bridge_trunk_primary',
  'tunnel_trunk_primary',
  'highway-primary',
  'highway-trunk',
  'bridge-trunk-primary',
  'road_secondary_tertiary',
  'bridge_secondary_tertiary',
  'tunnel_secondary_tertiary',
  'highway-secondary-tertiary',
  'bridge-secondary-tertiary',
  'road_link',
  'bridge_link',
  'tunnel_link',
  'highway-link',
  'bridge-link',
  'road_minor',
  'bridge_street',
  'highway-minor',
  'bridge-minor',
  'road_service_track',
  'bridge_service_track',
];

const NON_DRIVABLE_ROAD_CLASSES = new Set([
  'path',
  'pedestrian',
  'footway',
  'steps',
  'cycleway',
  'rail',
  'transit',
  'ferry',
  'bridleway',
  'track',
]);

function lerpZoomStops(zoom: number, stops: Array<[number, number]>): number {
  if (zoom <= stops[0][0]) return stops[0][1];
  for (let i = 0; i < stops.length - 1; i++) {
    const [z0, v0] = stops[i];
    const [z1, v1] = stops[i + 1];
    if (zoom <= z1) {
      const t = (zoom - z0) / Math.max(1e-6, z1 - z0);
      return v0 + (v1 - v0) * t;
    }
  }
  return stops[stops.length - 1][1];
}

function getDrivableRoadHalfWidthPx(layerId: string, roadClass: string, zoom: number): number {
  const id = layerId.toLowerCase();
  const cls = roadClass.toLowerCase();

  if ((id.includes('motorway') && id.includes('link')) || cls === 'motorway_link') {
    return lerpZoomStops(zoom, [[12.8, 0.9], [14.8, 2.3], [16, 4.1], [18, 6.2], [19.5, 7.2]]);
  }
  if (id.includes('motorway') || cls === 'motorway') {
    return lerpZoomStops(zoom, [[12, 1.4], [13.4, 1.9], [14.6, 3.8], [16, 6.7], [17, 9.4], [18, 11.8], [19.5, 13.5]]);
  }
  if (id.includes('trunk') || id.includes('primary') || cls === 'trunk' || cls === 'primary') {
    return lerpZoomStops(zoom, [[12, 1.2], [13.4, 1.6], [14.6, 3.2], [16, 5.7], [17, 8.2], [18, 10.4], [19.5, 11.8]]);
  }
  if (
    id.includes('secondary') ||
    id.includes('tertiary') ||
    id.includes('link') ||
    cls === 'secondary' ||
    cls === 'tertiary'
  ) {
    return lerpZoomStops(zoom, [[12.8, 0.8], [14.2, 1.9], [15, 2.8], [16, 4.0], [17, 6.2], [18, 8.0], [19.5, 9.2]]);
  }
  if (id.includes('minor') || id.includes('street') || cls === 'minor' || cls === 'residential' || cls === 'unclassified') {
    return lerpZoomStops(zoom, [[13.8, 0.7], [15, 1.7], [16, 2.6], [17, 4.6], [18, 6.1], [19.5, 7.0]]);
  }
  return lerpZoomStops(zoom, [[14.6, 0.6], [15.5, 1.4], [16, 2.1], [17, 3.5], [18, 4.7], [19.5, 5.5]]);
}

function clampPointToRoadSegment(
  lat: number,
  lng: number,
  segment: IdleRoadSegment
): [number, number] {
  const midLat = ((segment.a[0] + segment.b[0]) / 2) * (Math.PI / 180);
  const kx = Math.cos(midLat) * 111320;
  const ky = 110540;
  const dx = (segment.b[1] - segment.a[1]) * kx;
  const dy = (segment.b[0] - segment.a[0]) * ky;
  const segLenSq = dx * dx + dy * dy;
  if (segLenSq < 1e-6) return [lat, lng];

  const px = (lng - segment.a[1]) * kx;
  const py = (lat - segment.a[0]) * ky;
  const tLine = (px * dx + py * dy) / segLenSq;
  const lineLat = segment.a[0] + tLine * (segment.b[0] - segment.a[0]);
  const lineLng = segment.a[1] + tLine * (segment.b[1] - segment.a[1]);

  const perpDist = getDistanceMeters(lat, lng, lineLat, lineLng);
  if (perpDist <= segment.halfWidthMeters || perpDist <= 0.05) {
    return [lat, lng];
  }
  const ratio = segment.halfWidthMeters / perpDist;
  return [
    lineLat + (lat - lineLat) * ratio,
    lineLng + (lng - lineLng) * ratio,
  ];
}

function snapReportPointToRenderedCarriageway(
  map: maplibregl.Map,
  lat: number,
  lng: number,
  targetHeadingDeg: number,
  maxDistMeters: number = 38
): CarriagewaySnapResult | null {
  try {
    if (!Number.isFinite(targetHeadingDeg)) return null;
    const activeLayers = DRIVABLE_ROAD_QUERY_LAYERS.filter((id) => Boolean(map.getLayer(id)));
    if (activeLayers.length === 0) return null;

    const canvas = map.getCanvas();
    const cw = canvas?.clientWidth || map.getContainer()?.clientWidth || 0;
    const ch = canvas?.clientHeight || map.getContainer()?.clientHeight || 0;
    if (cw === 0 || ch === 0) return null;

    const pt = map.project([lng, lat]);
    if (
      !Number.isFinite(pt.x) ||
      !Number.isFinite(pt.y) ||
      pt.x < -160 ||
      pt.x > cw + 160 ||
      pt.y < -160 ||
      pt.y > ch + 160
    ) {
      return null;
    }

    const zoom = map.getZoom();
    const metersPerPx = Math.max(
      0.05,
      (78271.51696 * Math.cos((lat * Math.PI) / 180)) / Math.pow(2, zoom)
    );
    const searchPx = Math.max(40, Math.min(180, Math.round((maxDistMeters + 12) / metersPerPx)));

    const features = map.queryRenderedFeatures(
      [
        [pt.x - searchPx, pt.y - searchPx],
        [pt.x + searchPx, pt.y + searchPx],
      ],
      { layers: activeLayers }
    );
    if (!features || features.length === 0) return null;

    let bestScore = Infinity;
    let bestResult: CarriagewaySnapResult | null = null;

    for (const feat of features) {
      const geom = feat?.geometry;
      if (!geom) continue;
      const roadClass = String(feat.properties?.class || '').toLowerCase();
      if (roadClass && NON_DRIVABLE_ROAD_CLASSES.has(roadClass)) continue;

      const onewayRaw = feat.properties?.oneway;
      const onewayStr = String(onewayRaw ?? '').toLowerCase();
      const mode: 'forward' | 'reverse' | 'both' =
        onewayRaw === -1 || onewayStr === '-1' || onewayStr === 'reverse'
          ? 'reverse'
          : onewayRaw === 1 ||
            onewayStr === '1' ||
            onewayRaw === true ||
            onewayStr === 'yes' ||
            roadClass === 'motorway'
          ? 'forward'
          : 'both';
      const isOneway = mode !== 'both';

      const lineStrings: number[][][] =
        geom.type === 'LineString'
          ? [geom.coordinates as number[][]]
          : geom.type === 'MultiLineString'
          ? (geom.coordinates as number[][][])
          : [];

      const rawRoadName =
        typeof feat.properties?.name === 'string' && feat.properties.name.trim()
          ? feat.properties.name.trim()
          : undefined;
      const featIdPart =
        feat.id !== undefined && feat.id !== null
          ? String(feat.id)
          : `${feat.layer?.id || 'road'}:${rawRoadName || roadClass || 'way'}`;

      for (const coords of lineStrings) {
        if (!coords || coords.length < 2) continue;
        for (let i = 0; i < coords.length - 1; i++) {
          const cA = coords[i];
          const cB = coords[i + 1];
          if (!cA || !cB || cA.length < 2 || cB.length < 2) continue;
          const proj = projectPointOnSegment(lat, lng, cA[1], cA[0], cB[1], cB[0]);
          if (proj.distanceMeters > maxDistMeters) continue;

          const fwdBearing = getBearing(cA[1], cA[0], cB[1], cB[0]);
          const revBearing = getOppositeHeading(fwdBearing);
          const allowed: Array<{ bearing: number; dirSuffix: 'fwd' | 'rev' }> =
            mode === 'forward'
              ? [{ bearing: fwdBearing, dirSuffix: 'fwd' }]
              : mode === 'reverse'
              ? [{ bearing: revBearing, dirSuffix: 'rev' }]
              : [
                  { bearing: fwdBearing, dirSuffix: 'fwd' },
                  { bearing: revBearing, dirSuffix: 'rev' },
                ];

          for (const dir of allowed) {
            const angleDiff = shortestAngularDiffDeg(targetHeadingDeg, dir.bearing);
            if (angleDiff > 45) continue;

            const score = proj.distanceMeters + angleDiff * 0.22 + (isOneway ? -1.5 : 0);
            if (score < bestScore) {
              bestScore = score;
              const isUndividedOrSingleLane = !isOneway;
              bestResult = {
                matched: true,
                coords: { lat: proj.point[0], lng: proj.point[1] },
                roadId: `vt:${featIdPart}`,
                carriagewayId: `vt:${featIdPart}:${dir.dirSuffix}`,
                roadName: rawRoadName,
                isOneway,
                isUndividedOrSingleLane,
                headingDeg: dir.bearing,
                distanceMeters: proj.distanceMeters,
              };
            }
          }
        }
      }
    }

    return bestResult;
  } catch {
    return null;
  }
}

function projectArrowOntoRoadSurface(
  map: maplibregl.Map,
  lat: number,
  lng: number,
  headingDeg: number,
  hasReliableHeading: boolean
): { point: [number, number]; segment: IdleRoadSegment | null; projected: boolean } {
  const fallback = { point: [lat, lng] as [number, number], segment: null, projected: false };
  try {
    const activeLayers = DRIVABLE_ROAD_QUERY_LAYERS.filter((id) => Boolean(map.getLayer(id)));
    if (activeLayers.length === 0) return fallback;

    const canvas = map.getCanvas();
    const cw = canvas?.clientWidth || map.getContainer()?.clientWidth || 0;
    const ch = canvas?.clientHeight || map.getContainer()?.clientHeight || 0;
    if (cw === 0 || ch === 0) return fallback;

    const pt = map.project([lng, lat]);
    if (
      !Number.isFinite(pt.x) ||
      !Number.isFinite(pt.y) ||
      pt.x < -120 ||
      pt.x > cw + 120 ||
      pt.y < -120 ||
      pt.y > ch + 120
    ) {
      return fallback;
    }

    const zoom = map.getZoom();
    const metersPerPx = Math.max(
      0.05,
      (78271.51696 * Math.cos((lat * Math.PI) / 180)) / Math.pow(2, zoom)
    );
    const searchPx = Math.max(32, Math.min(110, Math.round(28 / metersPerPx)));

    const features = map.queryRenderedFeatures(
      [
        [pt.x - searchPx, pt.y - searchPx],
        [pt.x + searchPx, pt.y + searchPx],
      ],
      { layers: activeLayers }
    );
    if (!features || features.length === 0) return fallback;

    const MAX_CAPTURE_METERS = 22;
    let bestScore = Infinity;
    let bestDist = Infinity;
    let bestPoint: [number, number] = [lat, lng];
    let bestA: [number, number] | null = null;
    let bestB: [number, number] | null = null;
    let bestLayerId = '';
    let bestClass = '';

    for (const feat of features) {
      const geom = feat?.geometry;
      if (!geom) continue;
      const roadClass = String(feat.properties?.class || '').toLowerCase();
      if (roadClass && NON_DRIVABLE_ROAD_CLASSES.has(roadClass)) continue;

      const onewayRaw = feat.properties?.oneway;
      const isOneway = onewayRaw === 1 || onewayRaw === '1' || onewayRaw === true || onewayRaw === 'yes';

      const lineStrings: number[][][] =
        geom.type === 'LineString'
          ? [geom.coordinates as number[][]]
          : geom.type === 'MultiLineString'
          ? (geom.coordinates as number[][][])
          : [];

      const layerId = feat.layer?.id || '';
      for (const coords of lineStrings) {
        if (!coords || coords.length < 2) continue;
        for (let i = 0; i < coords.length - 1; i++) {
          const cA = coords[i];
          const cB = coords[i + 1];
          if (!cA || !cB || cA.length < 2 || cB.length < 2) continue;
          const aLat = cA[1];
          const aLng = cA[0];
          const bLat = cB[1];
          const bLng = cB[0];

          const proj = projectPointOnSegment(lat, lng, aLat, aLng, bLat, bLng);
          if (proj.distanceMeters > MAX_CAPTURE_METERS) continue;

          let headingPenalty = 0;
          if (hasReliableHeading) {
            const segBearing = normalizeHeadingDeg(getBearing(aLat, aLng, bLat, bLng));
            const angleDiff = isOneway
              ? Math.abs(shortestAngleDiffDeg(headingDeg, segBearing))
              : Math.min(
                  Math.abs(shortestAngleDiffDeg(headingDeg, segBearing)),
                  Math.abs(shortestAngleDiffDeg(headingDeg, (segBearing + 180) % 360))
                );
            headingPenalty = angleDiff > 55 ? 14 : angleDiff * 0.08;
          }

          const score = proj.distanceMeters + headingPenalty;
          if (score < bestScore) {
            bestScore = score;
            bestDist = proj.distanceMeters;
            bestPoint = proj.point;
            bestA = [aLat, aLng];
            bestB = [bLat, bLng];
            bestLayerId = layerId;
            bestClass = roadClass;
          }
        }
      }
    }

    if (!bestA || !bestB || !Number.isFinite(bestDist)) return fallback;

    const halfWidthPx = getDrivableRoadHalfWidthPx(bestLayerId, bestClass, zoom);
    const halfWidthMeters = Math.min(12, Math.max(1.4, halfWidthPx * 0.88 * metersPerPx));

    // Preserva desplazamiento lateral real (izquierda/derecha) dentro de la calzada; solo recorta el exceso fuera del borde vial
    let visualPoint: [number, number] = [lat, lng];
    if (bestDist > halfWidthMeters && bestDist > 0.05) {
      const ratio = halfWidthMeters / bestDist;
      visualPoint = [
        bestPoint[0] + (lat - bestPoint[0]) * ratio,
        bestPoint[1] + (lng - bestPoint[1]) * ratio,
      ];
    }

    return {
      point: visualPoint,
      segment: { a: bestA, b: bestB, halfWidthMeters },
      projected: true,
    };
  } catch {
    return fallback;
  }
}

function getStyleForTileMode(
  mode: MapTileMode,
  stage: OpenFreeMapFallbackStage = 'liberty'
): string | StyleSpecification {
  if (mode === 'satellite') return SATELLITE_STYLE;
  if (stage === 'osm_raster') {
    return mode === 'night' ? OSM_RASTER_NIGHT_STYLE : OSM_RASTER_DAY_STYLE;
  }
  if (stage === 'bright') return OPENFREEMAP_BRIGHT_STYLE_URL;
  return OPENFREEMAP_LIBERTY_STYLE_URL;
}

const SEC_ROADNAME_LAYER_ID = 'ruta-roadname-sec';

// Prefiere nombre español/local (name:es / name_es / name) y traduce sufijos en inglés
// únicamente en nombres de calles/avenidas ("... Avenue" -> "Avenida ...", "... Street" -> "Calle ...", "... Road" -> "Carretera ...")
const SPANISH_ROAD_NAME_TEXT_FIELD: any = [
  'let',
  'n',
  ['coalesce', ['get', 'name:es'], ['get', 'name_es'], ['get', 'name'], ['get', 'name:latin'], ['get', 'name_en'], ['get', 'name:en'], ''],
  [
    'let',
    'len',
    ['length', ['var', 'n']],
    [
      'case',
      ['all', ['>', ['var', 'len'], 7], ['==', ['slice', ['var', 'n'], ['-', ['var', 'len'], 7]], ' Avenue']],
      ['concat', 'Avenida ', ['slice', ['var', 'n'], 0, ['-', ['var', 'len'], 7]]],
      ['all', ['>', ['var', 'len'], 7], ['==', ['slice', ['var', 'n'], ['-', ['var', 'len'], 7]], ' Street']],
      ['concat', 'Calle ', ['slice', ['var', 'n'], 0, ['-', ['var', 'len'], 7]]],
      ['all', ['>', ['var', 'len'], 5], ['==', ['slice', ['var', 'n'], ['-', ['var', 'len'], 5]], ' Road']],
      ['concat', 'Carretera ', ['slice', ['var', 'n'], 0, ['-', ['var', 'len'], 5]]],
      ['var', 'n'],
    ],
  ],
];

function applySpanishRoadNameFormatting(map: maplibregl.Map): void {
  try {
    const layers = map.getStyle()?.layers || [];
    for (const layer of layers) {
      if (layer.type !== 'symbol') continue;
      const sourceLayer = (layer as any)['source-layer'];
      const isRoadNameLayer =
        layer.id === SEC_ROADNAME_LAYER_ID ||
        (sourceLayer === 'transportation_name' && !layer.id.includes('shield'));
      if (isRoadNameLayer) {
        try {
          map.setLayoutProperty(layer.id, 'text-field', SPANISH_ROAD_NAME_TEXT_FIELD);
        } catch {}
      }
    }
  } catch {}
}

function ensureOpenFreeMapSecRoadNameLayer(map: maplibregl.Map): void {
  try {
    if (!map.getSource('openmaptiles')) return;
    if (map.getLayer('highway-name-major')) {
      map.setFilter('highway-name-major', [
        'match',
        ['get', 'class'],
        ['primary', 'trunk'],
        true,
        false,
      ]);
    }
    if (!map.getLayer(SEC_ROADNAME_LAYER_ID)) {
      const majorLayer = map.getLayer('highway-name-major') as any;
      const sourceTextFont = majorLayer?.getLayoutProperty?.('text-font') || ['Noto Sans Regular'];
      const beforeId = map.getLayer('highway-name-major') ? 'highway-name-major' : undefined;
      map.addLayer(
        {
          id: SEC_ROADNAME_LAYER_ID,
          type: 'symbol',
          source: 'openmaptiles',
          'source-layer': 'transportation_name',
          minzoom: 12.8,
          filter: ['match', ['get', 'class'], ['secondary', 'tertiary'], true, false],
          layout: {
            'symbol-placement': 'line',
            'text-field': SPANISH_ROAD_NAME_TEXT_FIELD,
            'text-font': sourceTextFont,
            'text-rotation-alignment': 'map',
            'text-pitch-alignment': 'viewport',
            'text-keep-upright': true,
            'symbol-spacing': 260,
            'text-size': ['interpolate', ['linear'], ['zoom'], 13.2, 11.2, 15.5, 12.4, 17.5, 13.6, 19, 14.2],
          },
          paint: {
            'text-color': '#0f172a',
            'text-halo-color': '#ffffff',
            'text-halo-width': 2.5,
            'text-halo-blur': 0.4,
          },
        },
        beforeId
      );
    }
    applySpanishRoadNameFormatting(map);
  } catch {}
}

function isMapStyleReadyForSources(map: maplibregl.Map): boolean {
  try {
    const internalStyle = (map as any).style;
    if (!internalStyle) return false;
    if (typeof internalStyle._loaded === 'boolean') {
      return internalStyle._loaded;
    }
    return Boolean(map.isStyleLoaded());
  } catch {
    return false;
  }
}

// Darken OpenFreeMap (liberty / bright) vector style programmatically for Night mode
function applyGoogleMapsNightStyle(map: maplibregl.Map): void {
  ensureOpenFreeMapSecRoadNameLayer(map);

  const safeSetPaint = (layerId: string, prop: string, value: any) => {
    try {
      if (map.getLayer(layerId)) {
        map.setPaintProperty(layerId, prop as any, value);
      }
    } catch {}
  };

  const safeSetLayout = (layerId: string, prop: string, value: any) => {
    try {
      if (map.getLayer(layerId)) {
        map.setLayoutProperty(layerId, prop as any, value);
      }
    } catch {}
  };

  const safeSetZoomRange = (layerId: string, minzoom: number, maxzoom: number) => {
    try {
      if (map.getLayer(layerId)) {
        map.setLayerZoomRange(layerId, minzoom, maxzoom);
      }
    } catch {}
  };

  // Ocultar capas POI nativas de OpenFreeMap (usamos nuestros íconos anclados a coordenadas sin texto)
  for (const basePoiId of ['poi_r20', 'poi_r7', 'poi_r1', 'poi_transit']) {
    safeSetLayout(basePoiId, 'visibility', 'none');
  }

  // Fondo azul grisáceo oscuro (sin deslumbrar) y contraste mejorado para edificios y vías
  safeSetPaint('background', 'background-color', '#1e293b');
  safeSetPaint('natural_earth', 'raster-opacity', 0.14);
  safeSetPaint('landuse_residential', 'fill-color', '#243146');
  safeSetPaint('landuse_residential', 'fill-opacity', 0.52);
  safeSetPaint('landuse-residential', 'fill-color', '#243146');
  safeSetPaint('landuse-residential', 'fill-opacity', 0.52);
  safeSetPaint('landuse-suburb', 'fill-color', '#212d40');
  safeSetPaint('landuse-commercial', 'fill-color', '#2f2d3d');
  safeSetPaint('landuse-industrial', 'fill-color', '#253042');
  safeSetPaint('landuse-railway', 'fill-color', '#232c3d');
  safeSetPaint('landuse_cemetery', 'fill-color', '#20362f');
  safeSetPaint('landuse-cemetery', 'fill-color', '#20362f');
  safeSetPaint('landuse_hospital', 'fill-color', '#362735');
  safeSetPaint('landuse-hospital', 'fill-color', '#362735');
  safeSetPaint('landuse_school', 'fill-color', '#2e3127');
  safeSetPaint('landuse-school', 'fill-color', '#2e3127');
  safeSetPaint('landuse_pitch', 'fill-color', '#214537');
  safeSetPaint('landuse_track', 'fill-color', '#214537');
  safeSetPaint('landcover_sand', 'fill-color', '#2e313b');
  safeSetPaint('landcover-sand', 'fill-color', '#2e313b');
  safeSetPaint('landcover_ice', 'fill-color', '#28394f');
  safeSetPaint('landcover-glacier', 'fill-color', '#28394f');
  safeSetPaint('landcover-ice-shelf', 'fill-color', '#28394f');
  safeSetPaint('landcover_wetland', 'fill-opacity', 0.32);

  safeSetPaint('park', 'fill-color', '#1d4335');
  safeSetPaint('park', 'fill-opacity', 0.88);
  safeSetPaint('park', 'fill-outline-color', '#2a5e4b');
  safeSetPaint('park_outline', 'line-color', '#2a5e4b');
  safeSetPaint('landcover_wood', 'fill-color', '#1f4939');
  safeSetPaint('landcover_wood', 'fill-opacity', 0.72);
  safeSetPaint('landcover-wood', 'fill-color', '#1f4939');
  safeSetPaint('landcover-wood', 'fill-opacity', 0.72);
  for (const grassId of ['landcover_grass', 'landcover-grass', 'landcover-grass-park']) {
    safeSetPaint(grassId, 'fill-color', '#1c3e30');
    safeSetPaint(grassId, 'fill-opacity', 0.76);
  }

  // Aeropuertos
  safeSetPaint('aeroway_fill', 'fill-color', '#263247');
  safeSetPaint('aeroway-area', 'fill-color', '#263247');
  safeSetPaint('aeroway_runway', 'line-color', '#384863');
  safeSetPaint('aeroway_taxiway', 'line-color', '#313f57');
  safeSetPaint('aeroway-runway', 'line-color', '#384863');
  safeSetPaint('aeroway-taxiway', 'line-color', '#313f57');
  safeSetPaint('aeroway-runway-casing', 'line-color', '#182233');
  safeSetPaint('aeroway-taxiway-casing', 'line-color', '#182233');

  // Edificios 2D y 3D claramente diferenciables del fondo
  safeSetZoomRange('building', 15, 24);
  safeSetPaint('building', 'fill-color', '#2c3b52');
  safeSetPaint('building', 'fill-outline-color', '#475c7d');
  safeSetPaint('building', 'fill-opacity', ['interpolate', ['linear'], ['zoom'], 15, 0, 15.8, 0.85]);
  safeSetZoomRange('building-top', 15, 24);
  safeSetPaint('building-top', 'fill-color', '#33445e');
  safeSetPaint('building-top', 'fill-outline-color', '#1c2636');
  safeSetPaint('building-top', 'fill-opacity', ['interpolate', ['linear'], ['zoom'], 15, 0, 15.8, 0.9]);
  safeSetPaint('building-3d', 'fill-extrusion-color', '#394c6b');
  safeSetPaint('building-3d', 'fill-extrusion-opacity', 0.88);

  // Agua en azul marino claro distinguible
  safeSetPaint('water', 'fill-color', '#112647');
  safeSetPaint('water-intermittent', 'fill-color', '#152e54');
  for (const waterwayId of [
    'waterway_tunnel',
    'waterway_river',
    'waterway_other',
    'waterway-river',
    'waterway-river-intermittent',
    'waterway-stream-canal',
    'waterway-stream-canal-intermittent',
    'waterway-other',
    'waterway-other-intermittent',
  ]) {
    safeSetPaint(waterwayId, 'line-color', '#1b3b6b');
  }

  for (const railId of [
    'road_major_rail',
    'road_major_rail_hatching',
    'road_transit_rail',
    'road_transit_rail_hatching',
    'tunnel_major_rail',
    'tunnel_major_rail_hatching',
    'tunnel_transit_rail',
    'tunnel_transit_rail_hatching',
    'bridge_major_rail',
    'bridge_major_rail_hatching',
    'bridge_transit_rail',
    'bridge_transit_rail_hatching',
    'railway',
    'railway-hatching',
    'railway-service',
    'railway-service-hatching',
    'railway-transit',
    'railway-transit-hatching',
    'tunnel-railway',
    'bridge-railway',
    'bridge-railway-hatching',
    'cablecar',
    'cablecar-dash',
  ]) {
    safeSetPaint(railId, 'line-color', '#263144');
  }
  for (const boundaryId of ['boundary_2', 'boundary_3', 'boundary_disputed']) {
    safeSetPaint(boundaryId, 'line-color', '#334155');
  }

  const applyNightRoadGroup = (
    layerIds: string[],
    fillWidth: any,
    caseWidth: any,
    fillColor: any,
    caseColor: any,
    fillOpacityExpr?: any,
    caseOpacityExpr?: any,
    zoomRange?: [number, number]
  ) => {
    for (const id of layerIds) {
      const isCasing = id.includes('_case') || id.includes('_casing') || id.includes('-casing');
      const isRamp = id.includes('_ramp') || id.includes('_link') || id.includes('-link');
      if (zoomRange && !isRamp) {
        safeSetZoomRange(id, zoomRange[0], zoomRange[1]);
      }
      if (isCasing) {
        safeSetPaint(id, 'line-width', caseWidth);
        safeSetPaint(id, 'line-color', caseColor);
        if (caseOpacityExpr !== undefined) {
          safeSetPaint(id, 'line-opacity', caseOpacityExpr);
        }
      } else {
        safeSetPaint(id, 'line-width', fillWidth);
        safeSetPaint(id, 'line-color', fillColor);
        if (fillOpacityExpr !== undefined) {
          safeSetPaint(id, 'line-opacity', fillOpacityExpr);
        }
      }
    }
  };

  const localFillWidth = ['interpolate', ['linear'], ['zoom'], 14.4, 0.8, 15, 2.1, 16, 4.5, 17, 8.8, 18, 11.8];
  const localCaseWidth = ['interpolate', ['linear'], ['zoom'], 14.4, 1.1, 15, 2.9, 16, 5.7, 17, 11.4, 18, 15.0];
  const minorFillOpacity = ['interpolate', ['linear'], ['zoom'], 14.4, 0, 15.0, 0.6, 15.5, 0.9, 16.5, 1];
  const minorCaseOpacity = ['interpolate', ['linear'], ['zoom'], 14.4, 0, 15.2, 0.58, 16, 0.88, 17, 0.95];
  const serviceFillOpacity = ['interpolate', ['linear'], ['zoom'], 14.9, 0, 15.4, 0.55, 16, 0.88, 17, 0.95];
  const serviceCaseOpacity = ['interpolate', ['linear'], ['zoom'], 14.9, 0, 15.5, 0.5, 16.2, 0.85];

  // 1. Calles de servicio, pasajes y senderos: ocultos en zoom lejano, visibles al acercar
  applyNightRoadGroup(
    [
      'road_service_track_casing',
      'road_service_track',
      'bridge_service_track_casing',
      'bridge_service_track',
      'tunnel_service_track_casing',
      'tunnel_service_track',
      'road_path_pedestrian',
      'bridge_path_pedestrian_casing',
      'bridge_path_pedestrian',
      'tunnel_path_pedestrian',
      'tunnel-service-track-casing',
      'tunnel-service-track',
      'highway-path',
      'bridge-path-casing',
      'bridge-path',
      'tunnel-path',
    ],
    localFillWidth,
    localCaseWidth,
    ['interpolate', ['linear'], ['zoom'], 14.9, '#3e506e', 16, '#4f658a', 18, '#5c759e'],
    '#162030',
    serviceFillOpacity,
    serviceCaseOpacity,
    [14.9, 24]
  );
  safeSetZoomRange('road_area_pattern', 15.2, 24);
  safeSetPaint('road_area_pattern', 'fill-opacity', 0.35);

  // Calles locales y residenciales: ocultas en zoom lejano, contraste claro al acercar
  applyNightRoadGroup(
    [
      'road_minor_casing',
      'road_minor',
      'bridge_street_casing',
      'bridge_street',
      'tunnel_street_casing',
      'tunnel_minor',
      'highway-minor-casing',
      'highway-minor',
      'bridge-minor-casing',
      'bridge-minor',
      'tunnel-minor-casing',
      'tunnel-minor',
    ],
    localFillWidth,
    localCaseWidth,
    ['interpolate', ['linear'], ['zoom'], 14.4, '#435675', 15.2, '#50678c', 16, '#5d769e', 18, '#6c89b5'],
    '#162030',
    minorFillOpacity,
    minorCaseOpacity,
    [14.4, 24]
  );

  // 2. Avenidas secundarias y terciarias: ocultas en zoom lejano (< 13.4), mayor contraste sin deslumbrar
  const secFillOpacity = ['interpolate', ['linear'], ['zoom'], 13.4, 0, 14.0, 0.72, 14.6, 0.92, 16, 1];
  const secCaseOpacity = ['interpolate', ['linear'], ['zoom'], 13.4, 0, 14.2, 0.65, 15.5, 0.9, 16.5, 0.95];

  applyNightRoadGroup(
    [
      'road_secondary_tertiary_casing',
      'road_secondary_tertiary',
      'bridge_secondary_tertiary_casing',
      'bridge_secondary_tertiary',
      'tunnel_secondary_tertiary_casing',
      'tunnel_secondary_tertiary',
      'highway-secondary-tertiary-casing',
      'highway-secondary-tertiary',
      'bridge-secondary-tertiary-casing',
      'bridge-secondary-tertiary',
      'tunnel-secondary-tertiary-casing',
      'tunnel-secondary-tertiary',
    ],
    ['interpolate', ['linear'], ['zoom'], 13.4, 1.0, 14.2, 2.2, 15, 4.0, 16, 6.6, 17, 11.8, 18, 15.4],
    ['interpolate', ['linear'], ['zoom'], 13.4, 1.4, 14.2, 2.9, 15, 5.2, 16, 8.2, 17, 14.8, 18, 19.0],
    ['interpolate', ['linear'], ['zoom'], 13.4, '#546b8f', 14.5, '#627ca6', 16, '#718eb8', 18, '#81a0cf'],
    '#172233',
    secFillOpacity,
    secCaseOpacity,
    [13.4, 24]
  );

  // Enlaces / rampas no autopista: ocultos en zoom lejano
  for (const linkId of [
    'road_link_casing',
    'road_link',
    'bridge_link_casing',
    'bridge_link',
    'tunnel_link_casing',
    'tunnel_link',
    'highway-link-casing',
    'highway-link',
    'bridge-link-casing',
    'bridge-link',
    'tunnel-link-casing',
    'tunnel-link',
  ]) {
    safeSetZoomRange(linkId, 13.4, 24);
  }
  applyNightRoadGroup(
    [
      'road_link_casing',
      'road_link',
      'bridge_link_casing',
      'bridge_link',
      'tunnel_link_casing',
      'tunnel_link',
      'highway-link-casing',
      'highway-link',
      'bridge-link-casing',
      'bridge-link',
      'tunnel-link-casing',
      'tunnel-link',
    ],
    ['interpolate', ['linear'], ['zoom'], 13.4, 1.1, 14.8, 3.0, 16, 5.4, 18, 9.0],
    ['interpolate', ['linear'], ['zoom'], 13.4, 1.6, 14.8, 4.0, 16, 6.8, 18, 11.0],
    ['interpolate', ['linear'], ['zoom'], 13.4, '#9c925e', 14.8, '#6a86b3', 17, '#7c9bc9'],
    ['interpolate', ['linear'], ['zoom'], 13.4, '#3a3622', 14.8, '#172233'],
    ['interpolate', ['linear'], ['zoom'], 13.4, 0, 14.2, 0.78, 15.5, 0.96],
    ['interpolate', ['linear'], ['zoom'], 13.4, 0, 14.4, 0.7, 15.5, 0.88]
  );

  // 3. Vías principales y troncales (primary, trunk): en zoom lejano amarillo suave apagado, línea fina y ~60% opacidad
  applyNightRoadGroup(
    [
      'road_trunk_primary_casing',
      'road_trunk_primary',
      'bridge_trunk_primary_casing',
      'bridge_trunk_primary',
      'tunnel_trunk_primary_casing',
      'tunnel_trunk_primary',
      'highway-primary-casing',
      'highway-primary',
      'highway-trunk-casing',
      'highway-trunk',
      'bridge-trunk-primary-casing',
      'bridge-trunk-primary',
      'tunnel-trunk-primary-casing',
      'tunnel-trunk-primary',
    ],
    ['interpolate', ['linear'], ['zoom'], 5, 0.9, 11, 1.2, 13.4, 2.0, 14.8, 5.6, 16, 10.0, 17, 15.4, 18, 19.6],
    ['interpolate', ['linear'], ['zoom'], 5, 1.3, 11, 1.7, 13.4, 2.7, 14.8, 7.2, 16, 12.2, 17, 18.8, 18, 23.6],
    ['interpolate', ['linear'], ['zoom'], 5, '#968c59', 13.4, '#9c925e', 14.8, '#6a7f9e', 16, '#7794c2', 18, '#87a6d6'],
    ['interpolate', ['linear'], ['zoom'], 5, '#3e3a24', 13.4, '#423d26', 15, '#172133'],
    ['interpolate', ['linear'], ['zoom'], 5, 0.58, 11, 0.59, 13.4, 0.63, 14.8, 0.92, 16, 1],
    ['interpolate', ['linear'], ['zoom'], 5, 0.25, 13.4, 0.32, 15, 0.74, 16, 0.86],
    [5, 24]
  );

  // 4. Autopistas y vías expresas (motorway): en zoom lejano amarillo suave apagado, línea fina y ~60% opacidad
  applyNightRoadGroup(
    [
      'road_motorway_casing',
      'road_motorway',
      'bridge_motorway_casing',
      'bridge_motorway',
      'tunnel_motorway_casing',
      'tunnel_motorway',
      'highway-motorway-casing',
      'highway-motorway',
      'bridge-motorway-casing',
      'bridge-motorway',
      'tunnel-motorway-casing',
      'tunnel-motorway',
    ],
    ['interpolate', ['linear'], ['zoom'], 5, 1.1, 11, 1.5, 13.4, 2.4, 14.8, 6.8, 16, 11.8, 17, 17.6, 18, 22.2],
    ['interpolate', ['linear'], ['zoom'], 5, 1.5, 11, 2.0, 13.4, 3.2, 14.8, 8.4, 16, 14.2, 17, 21.2, 18, 26.4],
    ['interpolate', ['linear'], ['zoom'], 5, '#9e935e', 13.4, '#a39863', 14.8, '#7288ab', 16, '#82a0cf', 18, '#93b2e3'],
    ['interpolate', ['linear'], ['zoom'], 5, '#423d26', 13.4, '#474229', 15, '#182338'],
    ['interpolate', ['linear'], ['zoom'], 5, 0.6, 11, 0.62, 13.4, 0.66, 14.8, 0.94, 16, 1],
    ['interpolate', ['linear'], ['zoom'], 5, 0.28, 13.4, 0.34, 15, 0.76, 16, 0.88],
    [5, 24]
  );

  for (const motLinkId of [
    'road_motorway_link_casing',
    'road_motorway_link',
    'bridge_motorway_link_casing',
    'bridge_motorway_link',
    'tunnel_motorway_link_casing',
    'tunnel_motorway_link',
    'highway-motorway-link-casing',
    'highway-motorway-link',
    'bridge-motorway-link-casing',
    'bridge-motorway-link',
    'tunnel-motorway-link-casing',
    'tunnel-motorway-link',
  ]) {
    safeSetZoomRange(motLinkId, 13.0, 24);
  }
  applyNightRoadGroup(
    [
      'road_motorway_link_casing',
      'road_motorway_link',
      'bridge_motorway_link_casing',
      'bridge_motorway_link',
      'tunnel_motorway_link_casing',
      'tunnel_motorway_link',
      'highway-motorway-link-casing',
      'highway-motorway-link',
      'bridge-motorway-link-casing',
      'bridge-motorway-link',
      'tunnel-motorway-link-casing',
      'tunnel-motorway-link',
    ],
    ['interpolate', ['linear'], ['zoom'], 13.0, 1.1, 14.8, 3.8, 16, 7.0, 18, 11.2],
    ['interpolate', ['linear'], ['zoom'], 13.0, 1.5, 14.8, 5.0, 16, 8.8, 18, 13.8],
    ['interpolate', ['linear'], ['zoom'], 13.0, '#9e935e', 14.8, '#6e8ab5', 17, '#82a0cf'],
    ['interpolate', ['linear'], ['zoom'], 13.0, '#423d26', 14.8, '#182338'],
    ['interpolate', ['linear'], ['zoom'], 13.0, 0, 13.8, 0.72, 15, 0.94],
    ['interpolate', ['linear'], ['zoom'], 13.0, 0, 14.0, 0.65, 15, 0.85]
  );

  // Flechas de sentido único discretas en modo noche
  for (const arrowId of [
    'road_one_way_arrow',
    'road_one_way_arrow_opposite',
    'road_oneway',
    'road_oneway_opposite',
  ]) {
    safeSetPaint(arrowId, 'icon-opacity', 0.55);
  }

  // 5. Nombres de calles nítidos con halo oscuro legible
  const nightRoadLabels: Array<{
    id: string;
    size: any;
    color: string;
    haloWidth: number;
    zoomRange: [number, number];
    opacity: any;
    spacing?: number;
  }> = [
    {
      id: 'highway-name-path',
      size: ['interpolate', ['linear'], ['zoom'], 15.5, 10.5, 17, 12.5, 18, 13.5],
      color: '#cbd5e1',
      haloWidth: 2.0,
      zoomRange: [15.5, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 15.5, 0, 16.2, 0.92],
    },
    {
      id: 'highway-name-minor',
      size: ['interpolate', ['linear'], ['zoom'], 15, 10.6, 16, 12.2, 17, 13.8, 18, 15.4],
      color: '#e2e8f0',
      haloWidth: 2.4,
      zoomRange: [14.7, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 14.7, 0, 15.5, 0.98],
      spacing: 210,
    },
    {
      id: SEC_ROADNAME_LAYER_ID,
      size: ['interpolate', ['linear'], ['zoom'], 14, 10.8, 16, 12.6, 17, 14.4, 18, 16.0],
      color: '#f1f5f9',
      haloWidth: 2.5,
      zoomRange: [13.8, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 13.8, 0, 14.6, 0.99],
      spacing: 210,
    },
    {
      id: 'highway-name-major',
      size: ['interpolate', ['linear'], ['zoom'], 12, 11.0, 14, 12.2, 16, 13.6, 17, 15.2, 18, 16.8],
      color: '#ffffff',
      haloWidth: 2.6,
      zoomRange: [11.5, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 11.5, 0.85, 13.5, 1],
    },
  ];

  for (const spec of nightRoadLabels) {
    safeSetZoomRange(spec.id, spec.zoomRange[0], spec.zoomRange[1]);
    safeSetLayout(spec.id, 'text-size', spec.size);
    safeSetLayout(spec.id, 'text-keep-upright', true);
    safeSetLayout(spec.id, 'text-rotation-alignment', 'map');
    safeSetLayout(spec.id, 'text-pitch-alignment', 'viewport');
    if (spec.spacing !== undefined) {
      safeSetLayout(spec.id, 'symbol-spacing', spec.spacing);
    }
    safeSetPaint(spec.id, 'text-color', spec.color);
    safeSetPaint(spec.id, 'text-halo-color', '#131c2b');
    safeSetPaint(spec.id, 'text-halo-width', spec.haloWidth);
    safeSetPaint(spec.id, 'text-opacity', spec.opacity);
  }

  // Etiquetas de lugares, distritos, ciudades y cuerpos de agua en modo noche
  for (const labelId of [
    'label_other',
    'label_village',
    'label_town',
    'label_state',
    'label_city',
    'label_city_capital',
    'label_country_1',
    'label_country_2',
    'label_country_3',
    'airport',
  ]) {
    safeSetLayout(labelId, 'text-keep-upright', true);
    safeSetPaint(labelId, 'text-color', '#ffffff');
    safeSetPaint(labelId, 'text-halo-color', '#111927');
    safeSetPaint(labelId, 'text-halo-width', 2.2);
  }

  for (const waterLabelId of [
    'waterway_line_label',
    'water_name_point_label',
    'water_name_line_label',
  ]) {
    safeSetPaint(waterLabelId, 'text-color', '#8fb3db');
    safeSetPaint(waterLabelId, 'text-halo-color', '#111927');
    safeSetPaint(waterLabelId, 'text-halo-width', 1.6);
  }

  for (const shieldId of [
    'highway-shield-non-us',
    'highway-shield-us-interstate',
    'road_shield_us',
  ]) {
    safeSetLayout(shieldId, 'visibility', 'visible');
    safeSetLayout(shieldId, 'text-keep-upright', true);
    safeSetPaint(shieldId, 'text-color', '#f1f5f9');
    safeSetPaint(shieldId, 'icon-opacity', 0.9);
    safeSetPaint(shieldId, 'text-opacity', 1);
  }
}

// Style OpenFreeMap (liberty / bright) for Day mode with far-zoom soft yellow primary roads & gradual street reveal
function applyWazeStyleEnhancements(map: maplibregl.Map, mode: MapTileMode): void {
  if (mode === 'satellite') return;
  if (mode === 'night') {
    applyGoogleMapsNightStyle(map);
    return;
  }

  ensureOpenFreeMapSecRoadNameLayer(map);

  const safeSetPaint = (layerId: string, prop: string, value: any) => {
    try {
      if (map.getLayer(layerId)) {
        map.setPaintProperty(layerId, prop as any, value);
      }
    } catch {}
  };

  const safeSetLayout = (layerId: string, prop: string, value: any) => {
    try {
      if (map.getLayer(layerId)) {
        map.setLayoutProperty(layerId, prop as any, value);
      }
    } catch {}
  };

  const safeSetZoomRange = (layerId: string, minzoom: number, maxzoom: number) => {
    try {
      if (map.getLayer(layerId)) {
        map.setLayerZoomRange(layerId, minzoom, maxzoom);
      }
    } catch {}
  };

  // Ocultar POIs base de OpenFreeMap (se muestran únicamente nuestros íconos anclados a coordenadas)
  for (const basePoiId of ['poi_r20', 'poi_r7', 'poi_r1', 'poi_transit']) {
    safeSetLayout(basePoiId, 'visibility', 'none');
  }

  // Fondo claro cálido y equilibrado (sin exceso de blanco) para resaltar vías, edificios y áreas verdes
  safeSetPaint('background', 'background-color', '#e8e5dc');
  safeSetPaint('natural_earth', 'raster-opacity', ['interpolate', ['exponential', 1.5], ['zoom'], 0, 0.5, 6, 0.1]);
  safeSetPaint('landuse_residential', 'fill-color', '#e1ddd3');
  safeSetPaint('landuse_residential', 'fill-opacity', 0.65);
  safeSetPaint('landuse-residential', 'fill-color', '#e1ddd3');
  safeSetPaint('landuse-residential', 'fill-opacity', 0.65);
  safeSetPaint('landuse-suburb', 'fill-color', '#e4e0d6');
  safeSetPaint('landuse-commercial', 'fill-color', '#eadcc7');
  safeSetPaint('landuse-industrial', 'fill-color', '#dcdad3');
  safeSetPaint('landuse-railway', 'fill-color', '#d9dbe0');
  safeSetPaint('landuse_cemetery', 'fill-color', '#cedbc1');
  safeSetPaint('landuse-cemetery', 'fill-color', '#cedbc1');
  safeSetPaint('landuse_hospital', 'fill-color', '#f3dde2');
  safeSetPaint('landuse-hospital', 'fill-color', '#f3dde2');
  safeSetPaint('landuse_school', 'fill-color', '#e4e5c3');
  safeSetPaint('landuse-school', 'fill-color', '#e4e5c3');
  safeSetPaint('landuse_pitch', 'fill-color', '#cfe0be');
  safeSetPaint('landuse_track', 'fill-color', '#cfe0be');
  safeSetPaint('landcover_sand', 'fill-color', '#ede3b9');
  safeSetPaint('landcover-sand', 'fill-color', '#ede3b9');
  safeSetPaint('landcover_ice', 'fill-color', '#d6e4e4');
  safeSetPaint('landcover-glacier', 'fill-color', '#d6e4e4');
  safeSetPaint('landcover-ice-shelf', 'fill-color', '#d6e4e4');
  safeSetPaint('landcover_wetland', 'fill-opacity', 0.8);

  safeSetPaint('park', 'fill-color', '#bfe0bb');
  safeSetPaint('park', 'fill-opacity', 0.85);
  safeSetPaint('park', 'fill-outline-color', '#8cc487');
  safeSetPaint('park_outline', 'line-color', '#a3d49e');
  safeSetPaint('landcover_wood', 'fill-color', '#b5dbb0');
  safeSetPaint('landcover_wood', 'fill-opacity', 0.55);
  safeSetPaint('landcover-wood', 'fill-color', '#b5dbb0');
  safeSetPaint('landcover-wood', 'fill-opacity', 0.55);
  for (const grassId of ['landcover_grass', 'landcover-grass', 'landcover-grass-park']) {
    safeSetPaint(grassId, 'fill-color', '#c2e3be');
    safeSetPaint(grassId, 'fill-opacity', 0.55);
  }

  safeSetPaint('aeroway_fill', 'fill-color', '#dcd9d1');
  safeSetPaint('aeroway-area', 'fill-color', '#dcd9d1');
  safeSetPaint('aeroway_runway', 'line-color', '#c9c6be');
  safeSetPaint('aeroway_taxiway', 'line-color', '#d1cec6');
  safeSetPaint('aeroway-runway', 'line-color', '#c9c6be');
  safeSetPaint('aeroway-taxiway', 'line-color', '#d1cec6');

  safeSetZoomRange('building', 15, 24);
  safeSetPaint('building', 'fill-color', '#dad6cc');
  safeSetPaint('building', 'fill-outline-color', '#c4bfb4');
  safeSetPaint('building', 'fill-opacity', ['interpolate', ['linear'], ['zoom'], 15, 0, 15.8, 0.78]);
  safeSetZoomRange('building-top', 15, 24);
  safeSetPaint('building-top', 'fill-color', '#e1ddd4');
  safeSetPaint('building-top', 'fill-outline-color', '#cac5ba');
  safeSetPaint('building-top', 'fill-opacity', ['interpolate', ['linear'], ['zoom'], 15, 0, 15.8, 0.85]);
  safeSetPaint('building-3d', 'fill-extrusion-color', '#d6d2c8');
  safeSetPaint('building-3d', 'fill-extrusion-opacity', 0.82);

  safeSetPaint('water', 'fill-color', '#9acae8');
  safeSetPaint('water-intermittent', 'fill-color', '#afd7f0');
  for (const waterwayId of [
    'waterway_tunnel',
    'waterway_river',
    'waterway_other',
    'waterway-river',
    'waterway-river-intermittent',
    'waterway-stream-canal',
    'waterway-stream-canal-intermittent',
    'waterway-other',
    'waterway-other-intermittent',
  ]) {
    safeSetPaint(waterwayId, 'line-color', '#9ecfe8');
  }

  for (const railId of [
    'road_major_rail',
    'road_major_rail_hatching',
    'road_transit_rail',
    'road_transit_rail_hatching',
    'tunnel_major_rail',
    'tunnel_major_rail_hatching',
    'tunnel_transit_rail',
    'tunnel_transit_rail_hatching',
    'bridge_major_rail',
    'bridge_major_rail_hatching',
    'bridge_transit_rail',
    'bridge_transit_rail_hatching',
    'railway',
    'railway-hatching',
    'railway-service',
    'railway-service-hatching',
    'railway-transit',
    'railway-transit-hatching',
    'tunnel-railway',
    'bridge-railway',
    'bridge-railway-hatching',
    'cablecar',
    'cablecar-dash',
  ]) {
    safeSetPaint(railId, 'line-color', '#bbbbbb');
  }
  for (const boundaryId of ['boundary_2', 'boundary_3', 'boundary_disputed']) {
    safeSetPaint(boundaryId, 'line-color', '#cbd5e1');
  }

  const applyRoadGroup = (
    layerIds: string[],
    fillWidth: any,
    caseWidth: any,
    fillColor: any,
    caseColor: any,
    minZoom?: number,
    fillOpacityExpr?: any,
    caseOpacityExpr?: any
  ) => {
    for (const id of layerIds) {
      const isCasing = id.includes('_case') || id.includes('_casing') || id.includes('-casing');
      const isRamp = id.includes('_ramp') || id.includes('_link') || id.includes('-link');
      if (minZoom !== undefined && !isRamp) {
        safeSetZoomRange(id, minZoom, 24);
      }
      // Cruces e intersecciones nítidas sin puntas ni solapamientos irregulares
      safeSetLayout(id, 'line-join', 'round');
      if (!id.includes('tunnel') && !id.includes('bridge')) {
        safeSetLayout(id, 'line-cap', 'round');
      }
      if (isCasing) {
        safeSetPaint(id, 'line-width', caseWidth);
        safeSetPaint(id, 'line-color', caseColor);
        if (caseOpacityExpr !== undefined) {
          safeSetPaint(id, 'line-opacity', caseOpacityExpr);
        }
      } else {
        safeSetPaint(id, 'line-width', fillWidth);
        safeSetPaint(id, 'line-color', fillColor);
        if (fillOpacityExpr !== undefined) {
          safeSetPaint(id, 'line-opacity', fillOpacityExpr);
        }
      }
    }
  };

  // 1. Calles pequeñas de servicio, pasajes y senderos: gris suave pero claramente visible frente al fondo
  applyRoadGroup(
    [
      'road_service_track_casing',
      'road_service_track',
      'bridge_service_track_casing',
      'bridge_service_track',
      'tunnel_service_track_casing',
      'tunnel_service_track',
      'road_path_pedestrian',
      'bridge_path_pedestrian_casing',
      'bridge_path_pedestrian',
      'tunnel_path_pedestrian',
      'tunnel-service-track-casing',
      'tunnel-service-track',
      'highway-path',
      'bridge-path-casing',
      'bridge-path',
      'tunnel-path',
    ],
    ['interpolate', ['linear'], ['zoom'], 14.6, 1.2, 15.5, 2.8, 16, 4.2, 17, 7.0, 18, 9.4],
    ['interpolate', ['linear'], ['zoom'], 14.6, 1.9, 15.5, 4.0, 16, 5.7, 17, 9.2, 18, 12.0],
    '#bcc5d3',
    '#8795a8',
    14.6,
    ['interpolate', ['linear'], ['zoom'], 14.6, 0, 15.4, 0.92],
    ['interpolate', ['linear'], ['zoom'], 14.6, 0, 15.5, 0.86]
  );
  safeSetZoomRange('road_area_pattern', 15.0, 24);
  safeSetPaint('road_area_pattern', 'fill-opacity', 0.72);

  // Calles pequeñas locales y residenciales: gris suave definido que no se pierde con el fondo ni edificios
  applyRoadGroup(
    [
      'road_minor_casing',
      'road_minor',
      'bridge_street_casing',
      'bridge_street',
      'tunnel_street_casing',
      'tunnel_minor',
      'highway-minor-casing',
      'highway-minor',
      'bridge-minor-casing',
      'bridge-minor',
      'tunnel-minor-casing',
      'tunnel-minor',
    ],
    ['interpolate', ['linear'], ['zoom'], 13.8, 1.3, 15, 3.4, 16, 5.2, 17, 9.2, 18, 12.2],
    ['interpolate', ['linear'], ['zoom'], 13.8, 2.0, 15, 4.7, 16, 7.0, 17, 12.0, 18, 15.6],
    ['interpolate', ['linear'], ['zoom'], 13.8, '#b4becd', 15.5, '#aab5c6', 17, '#a3afbf'],
    ['interpolate', ['linear'], ['zoom'], 13.8, '#7e8ca1', 15.5, '#6f7e94'],
    13.8,
    ['interpolate', ['linear'], ['zoom'], 13.8, 0, 14.6, 0.92, 15.4, 0.98],
    ['interpolate', ['linear'], ['zoom'], 13.8, 0, 14.7, 0.84, 15.5, 0.94]
  );

  // 2. Calles secundarias y terciarias: gris medio con contraste claro y jerarquía debajo de avenidas principales
  applyRoadGroup(
    [
      'road_secondary_tertiary_casing',
      'road_secondary_tertiary',
      'bridge_secondary_tertiary_casing',
      'bridge_secondary_tertiary',
      'tunnel_secondary_tertiary_casing',
      'tunnel_secondary_tertiary',
      'highway-secondary-tertiary-casing',
      'highway-secondary-tertiary',
      'bridge-secondary-tertiary-casing',
      'bridge-secondary-tertiary',
      'tunnel-secondary-tertiary-casing',
      'tunnel-secondary-tertiary',
    ],
    ['interpolate', ['linear'], ['zoom'], 12.8, 1.4, 14.2, 3.8, 15, 5.6, 16, 8.0, 17, 12.4, 18, 16.0],
    ['interpolate', ['linear'], ['zoom'], 12.8, 2.2, 14.2, 5.2, 15, 7.4, 16, 10.2, 17, 15.6, 18, 19.8],
    ['interpolate', ['linear'], ['zoom'], 12.8, '#95a3b6', 14.5, '#8c9bb0', 16, '#8493a8'],
    ['interpolate', ['linear'], ['zoom'], 12.8, '#66758a', 14.5, '#59687d', 16, '#526075'],
    12.8,
    ['interpolate', ['linear'], ['zoom'], 12.8, 0, 13.6, 0.85, 14.4, 0.98],
    ['interpolate', ['linear'], ['zoom'], 12.8, 0, 13.7, 0.78, 14.5, 0.94]
  );

  for (const linkId of [
    'road_link_casing',
    'road_link',
    'bridge_link_casing',
    'bridge_link',
    'tunnel_link_casing',
    'tunnel_link',
    'highway-link-casing',
    'highway-link',
    'bridge-link-casing',
    'bridge-link',
    'tunnel-link-casing',
    'tunnel-link',
  ]) {
    safeSetZoomRange(linkId, 13.0, 24);
  }
  applyRoadGroup(
    [
      'road_link_casing',
      'road_link',
      'bridge_link_casing',
      'bridge_link',
      'tunnel_link_casing',
      'tunnel_link',
      'highway-link-casing',
      'highway-link',
      'bridge-link-casing',
      'bridge-link',
      'tunnel-link-casing',
      'tunnel-link',
    ],
    ['interpolate', ['linear'], ['zoom'], 13.0, 1.3, 14.8, 3.6, 16, 6.4, 18, 10.4],
    ['interpolate', ['linear'], ['zoom'], 13.0, 2.0, 14.8, 4.9, 16, 8.2, 18, 12.8],
    ['interpolate', ['linear'], ['zoom'], 13.0, '#95a3b6', 15.0, '#8a99ae'],
    ['interpolate', ['linear'], ['zoom'], 13.0, '#66758a', 15.0, '#58677c'],
    undefined,
    ['interpolate', ['linear'], ['zoom'], 13.0, 0, 14.0, 0.86, 15.2, 0.98],
    ['interpolate', ['linear'], ['zoom'], 13.0, 0, 14.1, 0.78, 15.2, 0.94]
  );

  // 3. Avenidas principales (primary, trunk): gris más oscuro, notorio y ligeramente más grueso en todos los zooms
  applyRoadGroup(
    [
      'road_trunk_primary_casing',
      'road_trunk_primary',
      'bridge_trunk_primary_casing',
      'bridge_trunk_primary',
      'tunnel_trunk_primary_casing',
      'tunnel_trunk_primary',
      'highway-primary-casing',
      'highway-primary',
      'highway-trunk-casing',
      'highway-trunk',
      'bridge-trunk-primary-casing',
      'bridge-trunk-primary',
      'tunnel-trunk-primary-casing',
      'tunnel-trunk-primary',
    ],
    ['interpolate', ['linear'], ['zoom'], 5, 1.3, 11, 2.0, 13.4, 3.2, 14.6, 6.4, 16, 11.4, 17, 16.4, 18, 20.8],
    ['interpolate', ['linear'], ['zoom'], 5, 1.9, 11, 2.8, 13.4, 4.4, 14.6, 8.4, 16, 14.2, 17, 20.0, 18, 25.0],
    ['interpolate', ['linear'], ['zoom'], 5, '#78869c', 11, '#758399', 13.4, '#6f7e94', 15, '#68778d', 16.5, '#637288'],
    ['interpolate', ['linear'], ['zoom'], 5, '#4c596e', 13.4, '#465368', 15, '#3b475c'],
    5,
    ['interpolate', ['linear'], ['zoom'], 5, 0.78, 11, 0.85, 13.4, 0.92, 14.8, 0.98, 16, 1],
    ['interpolate', ['linear'], ['zoom'], 5, 0.55, 11, 0.68, 13.4, 0.82, 15, 0.95, 16, 1]
  );

  // 4. Autopistas y vías expresas (motorway): gris oscuro principal para máxima jerarquía y lectura en cruces
  applyRoadGroup(
    [
      'road_motorway_casing',
      'road_motorway',
      'bridge_motorway_casing',
      'bridge_motorway',
      'tunnel_motorway_casing',
      'tunnel_motorway',
      'highway-motorway-casing',
      'highway-motorway',
      'bridge-motorway-casing',
      'bridge-motorway',
      'tunnel-motorway-casing',
      'tunnel-motorway',
    ],
    ['interpolate', ['linear'], ['zoom'], 5, 1.5, 11, 2.4, 13.4, 3.8, 14.6, 7.6, 16, 13.4, 17, 18.8, 18, 23.6],
    ['interpolate', ['linear'], ['zoom'], 5, 2.2, 11, 3.4, 13.4, 5.2, 14.6, 9.8, 16, 16.4, 17, 22.8, 18, 28.2],
    ['interpolate', ['linear'], ['zoom'], 5, '#64738a', 13.4, '#5e6d85', 15, '#55647c', 16.5, '#4f5e76'],
    ['interpolate', ['linear'], ['zoom'], 5, '#3b475c', 13.4, '#364154', 15, '#2c3647'],
    5,
    ['interpolate', ['linear'], ['zoom'], 5, 0.82, 11, 0.88, 13.4, 0.94, 14.8, 0.98, 16, 1],
    ['interpolate', ['linear'], ['zoom'], 5, 0.62, 11, 0.72, 13.4, 0.86, 15, 0.96, 16, 1]
  );

  for (const motLinkId of [
    'road_motorway_link_casing',
    'road_motorway_link',
    'bridge_motorway_link_casing',
    'bridge_motorway_link',
    'tunnel_motorway_link_casing',
    'tunnel_motorway_link',
    'highway-motorway-link-casing',
    'highway-motorway-link',
    'bridge-motorway-link-casing',
    'bridge-motorway-link',
    'tunnel-motorway-link-casing',
    'tunnel-motorway-link',
  ]) {
    safeSetZoomRange(motLinkId, 12.8, 24);
  }
  applyRoadGroup(
    [
      'road_motorway_link_casing',
      'road_motorway_link',
      'bridge_motorway_link_casing',
      'bridge_motorway_link',
      'tunnel_motorway_link_casing',
      'tunnel_motorway_link',
      'highway-motorway-link-casing',
      'highway-motorway-link',
      'bridge-motorway-link-casing',
      'bridge-motorway-link',
      'tunnel-motorway-link-casing',
      'tunnel-motorway-link',
    ],
    ['interpolate', ['linear'], ['zoom'], 12.8, 1.8, 14.8, 4.6, 16, 8.2, 18, 12.4],
    ['interpolate', ['linear'], ['zoom'], 12.8, 2.6, 14.8, 6.0, 16, 10.2, 18, 15.0],
    ['interpolate', ['linear'], ['zoom'], 12.8, '#66758c', 15, '#5b6a82', 16.5, '#526179'],
    ['interpolate', ['linear'], ['zoom'], 12.8, '#3d495e', 15, '#354052'],
    undefined,
    ['interpolate', ['linear'], ['zoom'], 12.8, 0, 13.8, 0.88, 15, 0.98],
    ['interpolate', ['linear'], ['zoom'], 12.8, 0, 13.9, 0.8, 15, 0.95]
  );

  for (const arrowId of [
    'road_one_way_arrow',
    'road_one_way_arrow_opposite',
    'road_oneway',
    'road_oneway_opposite',
  ]) {
    safeSetPaint(arrowId, 'icon-opacity', 0.85);
  }

  // 5. Nombres de calles y avenidas uniformes, proporcionados y con buena separación entre etiquetas
  const labelSpecs: Array<{
    id: string;
    size: any;
    color: string;
    haloWidth: number;
    zoomRange?: [number, number];
    opacity?: any;
    spacing?: number;
  }> = [
    {
      id: 'highway-name-path',
      size: ['interpolate', ['linear'], ['zoom'], 15.2, 10.8, 16.5, 11.6, 18, 12.4],
      color: '#334155',
      haloWidth: 2.2,
      zoomRange: [15.2, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 15.2, 0, 16.0, 0.94],
      spacing: 250,
    },
    {
      id: 'highway-name-minor',
      size: ['interpolate', ['linear'], ['zoom'], 14.4, 11.0, 16, 12.0, 17.5, 13.0, 19, 13.8],
      color: '#1e293b',
      haloWidth: 2.4,
      zoomRange: [14.4, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 14.4, 0, 15.2, 0.98],
      spacing: 260,
    },
    {
      id: SEC_ROADNAME_LAYER_ID,
      size: ['interpolate', ['linear'], ['zoom'], 13.2, 11.2, 15.5, 12.4, 17.5, 13.6, 19, 14.2],
      color: '#0f172a',
      haloWidth: 2.5,
      zoomRange: [12.8, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 13.0, 0, 14.0, 0.98],
      spacing: 260,
    },
    {
      id: 'highway-name-major',
      size: ['interpolate', ['linear'], ['zoom'], 11.5, 11.2, 14, 12.2, 16, 13.2, 17.5, 14.2, 19, 14.8],
      color: '#0f172a',
      haloWidth: 2.6,
      zoomRange: [11.2, 24],
      opacity: ['interpolate', ['linear'], ['zoom'], 11.2, 0.9, 13.2, 1],
      spacing: 270,
    },
  ];

  for (const spec of labelSpecs) {
    if (spec.zoomRange) {
      safeSetZoomRange(spec.id, spec.zoomRange[0], spec.zoomRange[1]);
    }
    safeSetLayout(spec.id, 'text-size', spec.size);
    safeSetLayout(spec.id, 'text-keep-upright', true);
    safeSetLayout(spec.id, 'text-rotation-alignment', 'map');
    safeSetLayout(spec.id, 'text-pitch-alignment', 'viewport');
    safeSetLayout(spec.id, 'text-letter-spacing', 0.01);
    safeSetLayout(spec.id, 'text-max-angle', 38);
    if (spec.spacing !== undefined) {
      safeSetLayout(spec.id, 'symbol-spacing', spec.spacing);
    }
    safeSetPaint(spec.id, 'text-color', spec.color);
    safeSetPaint(spec.id, 'text-halo-color', '#ffffff');
    safeSetPaint(spec.id, 'text-halo-width', spec.haloWidth);
    safeSetPaint(spec.id, 'text-halo-blur', 0.4);
    if (spec.opacity !== undefined) {
      safeSetPaint(spec.id, 'text-opacity', spec.opacity);
    }
  }

  // Restaurar etiquetas de lugares, distritos y agua en Día
  for (const labelId of [
    'label_other',
    'label_village',
    'label_town',
    'label_state',
    'label_city',
    'label_city_capital',
    'label_country_1',
    'label_country_2',
    'label_country_3',
    'airport',
  ]) {
    safeSetLayout(labelId, 'text-keep-upright', true);
    safeSetPaint(labelId, 'text-color', '#1e293b');
    safeSetPaint(labelId, 'text-halo-color', '#ffffff');
    safeSetPaint(labelId, 'text-halo-width', 1.8);
  }

  for (const waterLabelId of [
    'waterway_line_label',
    'water_name_point_label',
    'water_name_line_label',
  ]) {
    safeSetPaint(waterLabelId, 'text-color', '#3b82f6');
    safeSetPaint(waterLabelId, 'text-halo-color', '#ffffff');
    safeSetPaint(waterLabelId, 'text-halo-width', 1.5);
  }

  for (const shieldId of [
    'highway-shield-non-us',
    'highway-shield-us-interstate',
    'road_shield_us',
  ]) {
    safeSetLayout(shieldId, 'visibility', 'visible');
    safeSetLayout(shieldId, 'text-keep-upright', true);
    safeSetPaint(shieldId, 'text-color', '#1e293b');
    safeSetPaint(shieldId, 'icon-opacity', 1);
    safeSetPaint(shieldId, 'text-opacity', 1);
  }
}

export const getInitialSettings = (initialTileMode: MapTileMode): MapSettingsData => {
  const defaults: MapSettingsData = {
    tileMode: initialTileMode,
    perspective3D: true,
    buildings3D: false,
    autoRotation: true,
    autoFollowGPS: true,
    smartZoom: true,
    controlsSize: 'normal',
    voiceEnabled: true,
    voiceVolume: 1.0,
    rerouteSoundEnabled: true,
    rerouteSoundVolume: 'high',
    navAlerts: true,
    preRouteAlertsEnabled: true,
    inspectorNavAlertsEnabled: true,
    inspectorAlertDistanceKm: 2,
    schoolZoneAlertEnabled: true,
    poiEnabled: true,
    poiCategories: { ...DEFAULT_POI_CATEGORIES },
    fixedRadarsEnabled: true,
    fixedRadarVoiceEnabled: true,
    fixedRadarRegionFilter: 'auto',
  };

  try {
    const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...defaults,
        ...parsed,
        poiCategories: { ...defaults.poiCategories },
      };
    }
  } catch (err) {
    console.warn('Error loading map settings from localStorage', err);
  }

  return defaults;
};

// GeoJSON source & layer IDs
const ACTIVE_ROUTE_SOURCE_ID = 'ruta-active-route-src';
const PREVIEW_ROUTES_SOURCE_ID = 'ruta-preview-routes-src';
const DEST_COLLISION_SOURCE_ID = 'ruta-dest-collision-src';
const DEST_COLLISION_LAYER_ID = 'ruta-dest-collision-layer';
const DEST_COLLISION_IMAGE_ID = 'ruta-dest-collision-box';
const MANEUVER_ARROW_SOURCE_ID = 'ruta-maneuver-arrow-src';
const MANEUVER_ARROW_OUTLINE_IMAGE_ID = 'ruta-maneuver-arrow-outline-img';
const MANEUVER_ARROW_FILL_IMAGE_ID = 'ruta-maneuver-arrow-fill-img';
const FIXED_RADAR_STRIPS_SOURCE_ID = 'ruta-fixed-radar-strips-src';
const FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID = 'ruta-fixed-radar-strips-outline';
const FIXED_RADAR_STRIPS_FILL_LAYER_ID = 'ruta-fixed-radar-strips-fill';
const POI_SOURCE_ID = 'ruta-pois-src';
const POI_REGULAR_LAYER_ID = 'ruta-pois-regular-layer';
const POI_ESSENTIAL_LAYER_ID = 'ruta-pois-essential-layer';
const ROUTE_LAYER_IDS = [
  'ruta-preview-glow',
  'ruta-preview-outline',
  'ruta-preview-line',
  'ruta-active-glow',
  'ruta-active-outline',
  'ruta-active-line',
  'ruta-maneuver-outline',
  'ruta-maneuver-arrow-outline',
  'ruta-maneuver-line',
  'ruta-maneuver-arrow',
];

// Configuraciones independientes de estilo de ruta para modo Día y modo Noche
const DAY_ROUTE_STYLE = {
  preview: {
    glowColor: '#9333ea',
    glowWidth: ['interpolate', ['linear'], ['zoom'], 10, 14, 13, 17, 16, 21, 18, 25] as any,
    glowOpacity: 0.34,
    glowBlur: 5,
    outlineColor: '#ffffff',
    outlineWidth: [
      'interpolate',
      ['linear'],
      ['zoom'],
      10,
      ['case', ['==', ['get', 'isSelected'], true], 12.0, 8.0],
      13,
      ['case', ['==', ['get', 'isSelected'], true], 14.0, 9.2],
      16,
      ['case', ['==', ['get', 'isSelected'], true], 16.5, 10.6],
      18,
      ['case', ['==', ['get', 'isSelected'], true], 20.0, 12.4],
    ] as any,
    outlineOpacity: ['case', ['==', ['get', 'isSelected'], true], 1.0, 0.96] as any,
    lineWidth: [
      'interpolate',
      ['linear'],
      ['zoom'],
      10,
      ['case', ['==', ['get', 'isSelected'], true], 7.4, 4.4],
      13,
      ['case', ['==', ['get', 'isSelected'], true], 9.0, 5.2],
      16,
      ['case', ['==', ['get', 'isSelected'], true], 11.0, 6.2],
      18,
      ['case', ['==', ['get', 'isSelected'], true], 13.5, 7.6],
    ] as any,
    lineOpacity: ['case', ['==', ['get', 'isSelected'], true], 1.0, 0.95] as any,
  },
  active: {
    glowColor: '#a855f7',
    glowWidth: ['interpolate', ['linear'], ['zoom'], 12, 9.5, 14, 11.5, 15, 13.5, 16, 15.5, 17, 18.0, 18, 20.5] as any,
    glowOpacity: 0.28,
    glowBlur: 3,
    outlineColor: '#6b21a8',
    outlineWidth: ['interpolate', ['linear'], ['zoom'], 12, 6.5, 14, 7.7, 15, 9.4, 16, 11.1, 17, 13.0, 18, 15.0] as any,
    outlineOpacity: 1.0,
    lineColor: '#a855f7',
    lineWidth: ['interpolate', ['linear'], ['zoom'], 12, 4.5, 14, 5.5, 15, 7.0, 16, 8.5, 17, 10.2, 18, 12.0] as any,
    lineOpacity: 0.99,
  },
};

const NIGHT_ROUTE_STYLE = {
  preview: {
    glowColor: '#a855f7',
    glowWidth: ['interpolate', ['linear'], ['zoom'], 10, 14, 13, 17, 16, 21, 18, 25] as any,
    glowOpacity: 0.36,
    glowBlur: 5,
    outlineColor: '#f8fafc',
    outlineWidth: [
      'interpolate',
      ['linear'],
      ['zoom'],
      10,
      ['case', ['==', ['get', 'isSelected'], true], 12.0, 8.0],
      13,
      ['case', ['==', ['get', 'isSelected'], true], 14.0, 9.2],
      16,
      ['case', ['==', ['get', 'isSelected'], true], 16.5, 10.6],
      18,
      ['case', ['==', ['get', 'isSelected'], true], 20.0, 12.4],
    ] as any,
    outlineOpacity: ['case', ['==', ['get', 'isSelected'], true], 1.0, 0.96] as any,
    lineWidth: [
      'interpolate',
      ['linear'],
      ['zoom'],
      10,
      ['case', ['==', ['get', 'isSelected'], true], 7.4, 4.4],
      13,
      ['case', ['==', ['get', 'isSelected'], true], 9.0, 5.2],
      16,
      ['case', ['==', ['get', 'isSelected'], true], 11.0, 6.2],
      18,
      ['case', ['==', ['get', 'isSelected'], true], 13.5, 7.6],
    ] as any,
    lineOpacity: ['case', ['==', ['get', 'isSelected'], true], 1.0, 0.95] as any,
  },
  active: {
    glowColor: '#c084fc',
    glowWidth: ['interpolate', ['linear'], ['zoom'], 12, 9.5, 14, 11.5, 15, 13.5, 16, 15.5, 17, 18.0, 18, 20.5] as any,
    glowOpacity: 0.3,
    glowBlur: 4,
    outlineColor: '#7e22ce',
    outlineWidth: ['interpolate', ['linear'], ['zoom'], 12, 6.5, 14, 7.7, 15, 9.4, 16, 11.1, 17, 13.0, 18, 15.0] as any,
    outlineOpacity: 1.0,
    lineColor: '#b366ff',
    lineWidth: ['interpolate', ['linear'], ['zoom'], 12, 4.5, 14, 5.5, 15, 7.0, 16, 8.5, 17, 10.2, 18, 12.0] as any,
    lineOpacity: 0.99,
  },
};

interface OverviewLayerSnapshot {
  visibility?: any;
  minzoom: number;
  maxzoom: number;
  paint: Record<string, any>;
  layout: Record<string, any>;
}

const OVERVIEW_HIDDEN_LAYER_IDS = [
  // Base map POI labels, arrows & buildings stay hidden in Vista general
  'poi_r20',
  'poi_r7',
  'poi_r1',
  'poi_transit',
  'airport',
  'building',
  'building-top',
  'building-3d',
  'road_one_way_arrow',
  'road_one_way_arrow_opposite',
  'road_oneway',
  'road_oneway_opposite',
  'road_area_pattern',
];

function applyOverviewActiveRouteStyle(map: maplibregl.Map): void {
  const safeSetPaint = (layerId: string, prop: string, value: any) => {
    try {
      if (map.getLayer(layerId)) {
        map.setPaintProperty(layerId, prop as any, value);
      }
    } catch {}
  };

  // Colocar la ruta celeste por encima de todas las capas del mapa base (vías y etiquetas)
  const beforeTopOverlayId = map.getLayer('ruta-maneuver-outline')
    ? 'ruta-maneuver-outline'
    : map.getLayer(DEST_COLLISION_LAYER_ID)
    ? DEST_COLLISION_LAYER_ID
    : undefined;

  for (const id of ['ruta-active-glow', 'ruta-active-outline', 'ruta-active-line']) {
    try {
      if (map.getLayer(id)) {
        map.moveLayer(id, beforeTopOverlayId);
      }
    } catch {}
  }

  // Ruta morada viva más gruesa y con contorno morado de contraste
  safeSetPaint('ruta-active-glow', 'line-color', '#a855f7');
  safeSetPaint('ruta-active-glow', 'line-width', [
    'interpolate',
    ['linear'],
    ['zoom'],
    8,
    15,
    12,
    18,
    15,
    22,
    18,
    26,
  ]);
  safeSetPaint('ruta-active-glow', 'line-opacity', 0.3);
  safeSetPaint('ruta-active-glow', 'line-blur', 3);

  safeSetPaint('ruta-active-outline', 'line-color', '#6b21a8');
  safeSetPaint('ruta-active-outline', 'line-width', [
    'interpolate',
    ['linear'],
    ['zoom'],
    8,
    10.5,
    12,
    12.5,
    15,
    15.0,
    18,
    18.0,
  ]);
  safeSetPaint('ruta-active-outline', 'line-opacity', 0.99);

  safeSetPaint('ruta-active-line', 'line-color', '#a855f7');
  safeSetPaint('ruta-active-line', 'line-width', [
    'interpolate',
    ['linear'],
    ['zoom'],
    8,
    6.2,
    12,
    7.6,
    15,
    9.4,
    18,
    11.6,
  ]);
  safeSetPaint('ruta-active-line', 'line-opacity', 1);
}

function applyOverviewCleanMapStyle(
  map: maplibregl.Map,
  mode: MapTileMode,
  savedMap: Map<string, OverviewLayerSnapshot>,
  overviewZoomAnchor?: number
): void {
  const ensureSnap = (layerId: string): OverviewLayerSnapshot | null => {
    const layer = map.getLayer(layerId);
    if (!layer) return null;
    let snap = savedMap.get(layerId);
    if (!snap) {
      let existingVisibility: any = undefined;
      try {
        existingVisibility = map.getLayoutProperty(layerId, 'visibility');
      } catch {}
      snap = {
        visibility: existingVisibility,
        minzoom: typeof layer.minzoom === 'number' ? layer.minzoom : 0,
        maxzoom: typeof layer.maxzoom === 'number' ? layer.maxzoom : 24,
        paint: {},
        layout: {},
      };
      savedMap.set(layerId, snap);
    }
    return snap;
  };

  const setOverviewLayout = (layerId: string, prop: string, value: any) => {
    const snap = ensureSnap(layerId);
    if (!snap) return;
    if (!(prop in snap.layout)) {
      try {
        snap.layout[prop] = map.getLayoutProperty(layerId, prop as any);
      } catch {
        snap.layout[prop] = undefined;
      }
    }
    try {
      map.setLayoutProperty(layerId, prop as any, value);
    } catch {}
  };

  const setOverviewPaint = (layerId: string, prop: string, value: any) => {
    const snap = ensureSnap(layerId);
    if (!snap) return;
    if (!(prop in snap.paint)) {
      try {
        snap.paint[prop] = map.getPaintProperty(layerId, prop as any);
      } catch {
        snap.paint[prop] = undefined;
      }
    }
    try {
      map.setPaintProperty(layerId, prop as any, value);
    } catch {}
  };

  const setOverviewZoomRange = (layerId: string, minzoom: number, maxzoom: number) => {
    const snap = ensureSnap(layerId);
    if (!snap) return;
    try {
      map.setLayerZoomRange(layerId, minzoom, maxzoom);
    } catch {}
  };

  if (mode !== 'satellite') {
    const isNight = mode === 'night';
    ensureOpenFreeMapSecRoadNameLayer(map);

    // 1. Mantener ocultos edificios, flechas y POIs base durante Vista general
    for (const hiddenId of OVERVIEW_HIDDEN_LAYER_IDS) {
      setOverviewLayout(hiddenId, 'visibility', 'none');
    }

    // 2. Umbrales progresivos según zoom del usuario (al acercar vuelven primero avenidas secundarias y luego calles + nombres)
    const secStart = Math.min(16.0, Math.max(13.6, (overviewZoomAnchor ?? 12.5) + 0.35));
    const secMid = Number((secStart + 0.6).toFixed(2));
    const secFull = Number((secStart + 1.4).toFixed(2));
    const secNameStart = Number((secStart + 0.3).toFixed(2));
    const secNameFull = Number((secNameStart + 0.7).toFixed(2));

    const minorStart = Math.min(16.8, Number((secStart + 1.1).toFixed(2)));
    const minorMid = Number((minorStart + 0.6).toFixed(2));
    const minorFull = Number((minorStart + 1.4).toFixed(2));
    const minorNameStart = Number((minorStart + 0.25).toFixed(2));
    const minorNameFull = Number((minorNameStart + 0.7).toFixed(2));

    const serviceStart = Math.min(17.2, Number((minorStart + 0.45).toFixed(2)));
    const serviceFull = Number((serviceStart + 0.75).toFixed(2));

    // Avenidas secundarias y terciarias: ocultas en el encuadre general, aparecen primero al hacer zoom
    for (const id of [
      'road_secondary_tertiary_casing',
      'bridge_secondary_tertiary_casing',
      'tunnel_secondary_tertiary_casing',
      'highway-secondary-tertiary-casing',
      'bridge-secondary-tertiary-casing',
      'tunnel-secondary-tertiary-casing',
    ]) {
      if (!map.getLayer(id)) continue;
      setOverviewLayout(id, 'visibility', 'visible');
      setOverviewZoomRange(id, secStart, 24);
      setOverviewPaint(id, 'line-color', isNight ? '#141d2b' : '#cbd5e1');
      setOverviewPaint(id, 'line-width', ['interpolate', ['linear'], ['zoom'], secStart, 1.4, 15.5, 4.6, 17, 7.8, 18, 10.5]);
      setOverviewPaint(id, 'line-opacity', ['interpolate', ['linear'], ['zoom'], secStart, 0, secMid, 0.58, secFull, 0.88]);
    }
    for (const id of [
      'road_secondary_tertiary',
      'bridge_secondary_tertiary',
      'tunnel_secondary_tertiary',
      'highway-secondary-tertiary',
      'bridge-secondary-tertiary',
      'tunnel-secondary-tertiary',
      'road_link_casing',
      'road_link',
      'bridge_link_casing',
      'bridge_link',
      'tunnel_link_casing',
      'tunnel_link',
      'highway-link-casing',
      'highway-link',
      'bridge-link-casing',
      'bridge-link',
      'tunnel-link-casing',
      'tunnel-link',
    ]) {
      if (!map.getLayer(id)) continue;
      const isCasing = id.includes('_casing') || id.includes('-casing');
      setOverviewLayout(id, 'visibility', 'visible');
      setOverviewZoomRange(id, secStart, 24);
      setOverviewPaint(id, 'line-color', isCasing ? (isNight ? '#141d2b' : '#cbd5e1') : isNight ? '#394863' : '#f8fafc');
      setOverviewPaint(id, 'line-width', ['interpolate', ['linear'], ['zoom'], secStart, 1.0, 15.5, 3.5, 17, 6.0, 18, 8.4]);
      setOverviewPaint(id, 'line-opacity', ['interpolate', ['linear'], ['zoom'], secStart, 0, secMid, 0.68, secFull, 0.95]);
    }
    if (map.getLayer(SEC_ROADNAME_LAYER_ID)) {
      setOverviewLayout(SEC_ROADNAME_LAYER_ID, 'visibility', 'visible');
      setOverviewZoomRange(SEC_ROADNAME_LAYER_ID, secNameStart, 24);
      setOverviewLayout(SEC_ROADNAME_LAYER_ID, 'text-size', ['interpolate', ['linear'], ['zoom'], 14, 10, 16, 11.8, 18, 13.2]);
      setOverviewLayout(SEC_ROADNAME_LAYER_ID, 'symbol-spacing', 220);
      setOverviewPaint(SEC_ROADNAME_LAYER_ID, 'text-color', isNight ? '#cbd5e1' : '#475569');
      setOverviewPaint(SEC_ROADNAME_LAYER_ID, 'text-halo-color', isNight ? '#0c1320' : '#ffffff');
      setOverviewPaint(SEC_ROADNAME_LAYER_ID, 'text-halo-width', 1.8);
      setOverviewPaint(SEC_ROADNAME_LAYER_ID, 'text-opacity', ['interpolate', ['linear'], ['zoom'], secNameStart, 0, secNameFull, 0.92]);
    }

    // Calles menores / residenciales y sus nombres: aparecen después al acercarse más
    for (const id of [
      'road_minor_casing',
      'bridge_street_casing',
      'tunnel_street_casing',
      'highway-minor-casing',
      'bridge-minor-casing',
      'tunnel-minor-casing',
    ]) {
      if (!map.getLayer(id)) continue;
      setOverviewLayout(id, 'visibility', 'visible');
      setOverviewZoomRange(id, minorStart, 24);
      setOverviewPaint(id, 'line-color', isNight ? '#111722' : '#cbd5e1');
      setOverviewPaint(id, 'line-width', ['interpolate', ['linear'], ['zoom'], minorStart, 1.0, 16, 4.2, 17.5, 7.2, 18, 9.0]);
      setOverviewPaint(id, 'line-opacity', ['interpolate', ['linear'], ['zoom'], minorStart, 0, minorMid, 0.62, minorFull, 0.92]);
    }
    for (const id of [
      'road_minor',
      'bridge_street',
      'tunnel_minor',
      'highway-minor',
      'bridge-minor',
      'tunnel-minor',
    ]) {
      if (!map.getLayer(id)) continue;
      setOverviewLayout(id, 'visibility', 'visible');
      setOverviewZoomRange(id, minorStart, 24);
      setOverviewPaint(id, 'line-color', isNight ? '#2c3950' : '#ffffff');
      setOverviewPaint(id, 'line-width', ['interpolate', ['linear'], ['zoom'], minorStart, 0.7, 16, 3.2, 17.5, 5.6, 18, 7.0]);
      setOverviewPaint(id, 'line-opacity', ['interpolate', ['linear'], ['zoom'], minorStart, 0, minorMid, 0.72, minorFull, 0.96]);
    }
    if (map.getLayer('highway-name-minor')) {
      setOverviewLayout('highway-name-minor', 'visibility', 'visible');
      setOverviewZoomRange('highway-name-minor', minorNameStart, 24);
      setOverviewLayout('highway-name-minor', 'text-size', ['interpolate', ['linear'], ['zoom'], 15, 9.8, 16, 11, 18, 12.5]);
      setOverviewLayout('highway-name-minor', 'symbol-spacing', 210);
      setOverviewPaint('highway-name-minor', 'text-color', isNight ? '#94a3b8' : '#64748b');
      setOverviewPaint('highway-name-minor', 'text-halo-color', isNight ? '#0c1320' : '#ffffff');
      setOverviewPaint('highway-name-minor', 'text-halo-width', 1.7);
      setOverviewPaint('highway-name-minor', 'text-opacity', ['interpolate', ['linear'], ['zoom'], minorNameStart, 0, minorNameFull, 0.92]);
    }

    // Calles de servicio y senderos al hacer zoom cercano
    for (const id of [
      'road_service_track_casing',
      'road_service_track',
      'bridge_service_track_casing',
      'bridge_service_track',
      'tunnel_service_track_casing',
      'tunnel_service_track',
      'road_path_pedestrian',
      'bridge_path_pedestrian_casing',
      'bridge_path_pedestrian',
      'tunnel_path_pedestrian',
      'tunnel-service-track-casing',
      'tunnel-service-track',
      'highway-path',
      'bridge-path-casing',
      'bridge-path',
      'tunnel-path',
      'highway-name-path',
    ]) {
      if (!map.getLayer(id)) continue;
      setOverviewLayout(id, 'visibility', 'visible');
      setOverviewZoomRange(id, serviceStart, 24);
      if (id === 'highway-name-path') {
        setOverviewPaint(id, 'text-opacity', ['interpolate', ['linear'], ['zoom'], serviceStart, 0, serviceFull, 0.85]);
      } else {
        setOverviewPaint(id, 'line-opacity', ['interpolate', ['linear'], ['zoom'], serviceStart, 0, serviceFull, 0.8]);
      }
    }

    // 3. Vías principales (primary, trunk, motorway) en amarillo suave apagado, líneas finas y ~60% opacidad
    const applyOverviewRoadGroup = (
      layerIds: string[],
      fillWidth: any,
      caseWidth: any,
      fillColor: any,
      caseColor: any,
      fillOpacity: any,
      caseOpacity: any,
      zoomRange?: [number, number]
    ) => {
      for (const id of layerIds) {
        if (!map.getLayer(id)) continue;
        const isCasing = id.includes('_casing') || id.includes('-casing');
        const isRamp = id.includes('_link') || id.includes('-link');
        setOverviewLayout(id, 'visibility', 'visible');
        if (zoomRange && !isRamp) {
          setOverviewZoomRange(id, zoomRange[0], zoomRange[1]);
        }
        if (isCasing) {
          setOverviewPaint(id, 'line-width', caseWidth);
          setOverviewPaint(id, 'line-color', caseColor);
          setOverviewPaint(id, 'line-opacity', caseOpacity);
        } else {
          setOverviewPaint(id, 'line-width', fillWidth);
          setOverviewPaint(id, 'line-color', fillColor);
          setOverviewPaint(id, 'line-opacity', fillOpacity);
        }
      }
    };

    // Trunk & Primary roads
    applyOverviewRoadGroup(
      [
        'road_trunk_primary_casing',
        'road_trunk_primary',
        'bridge_trunk_primary_casing',
        'bridge_trunk_primary',
        'tunnel_trunk_primary_casing',
        'tunnel_trunk_primary',
        'highway-primary-casing',
        'highway-primary',
        'highway-trunk-casing',
        'highway-trunk',
        'bridge-trunk-primary-casing',
        'bridge-trunk-primary',
        'tunnel-trunk-primary-casing',
        'tunnel-trunk-primary',
      ],
      ['interpolate', ['linear'], ['zoom'], 5, 0.9, 8, 1.1, 12, 1.5, 14, 2.5, 16, 4.4, 18, 6.0],
      ['interpolate', ['linear'], ['zoom'], 5, 1.3, 8, 1.6, 12, 2.2, 14, 3.4, 16, 5.7, 18, 7.6],
      isNight ? '#968c59' : '#ede3b2',
      isNight ? '#3e3a24' : '#d4ca96',
      ['interpolate', ['linear'], ['zoom'], 5, 0.58, 13.5, 0.63, 15.5, 0.85],
      ['interpolate', ['linear'], ['zoom'], 5, 0.26, 13.5, 0.34, 15.5, 0.65],
      [5, 24]
    );

    // Motorways / Expressways
    applyOverviewRoadGroup(
      [
        'road_motorway_casing',
        'road_motorway',
        'bridge_motorway_casing',
        'bridge_motorway',
        'tunnel_motorway_casing',
        'tunnel_motorway',
        'highway-motorway-casing',
        'highway-motorway',
        'bridge-motorway-casing',
        'bridge-motorway',
        'tunnel-motorway-casing',
        'tunnel-motorway',
        'road_motorway_link_casing',
        'road_motorway_link',
        'bridge_motorway_link_casing',
        'bridge_motorway_link',
        'tunnel_motorway_link_casing',
        'tunnel_motorway_link',
        'highway-motorway-link-casing',
        'highway-motorway-link',
        'bridge-motorway-link-casing',
        'bridge-motorway-link',
        'tunnel-motorway-link-casing',
        'tunnel-motorway-link',
      ],
      ['interpolate', ['linear'], ['zoom'], 5, 1.0, 8, 1.3, 12, 1.9, 14, 3.0, 16, 5.2, 18, 7.0],
      ['interpolate', ['linear'], ['zoom'], 5, 1.4, 8, 1.9, 12, 2.7, 14, 4.0, 16, 6.6, 18, 8.8],
      isNight ? '#9e935e' : '#ebe0aa',
      isNight ? '#423d26' : '#cfc48e',
      ['interpolate', ['linear'], ['zoom'], 5, 0.6, 13.5, 0.66, 15.5, 0.88],
      ['interpolate', ['linear'], ['zoom'], 5, 0.28, 13.5, 0.36, 15.5, 0.68],
      [5, 24]
    );

    // 4. Etiquetas pequeñas y legibles únicamente para las vías principales
    if (map.getLayer('highway-name-major')) {
      setOverviewLayout('highway-name-major', 'visibility', 'visible');
      setOverviewZoomRange('highway-name-major', 9.5, 24);
      setOverviewLayout('highway-name-major', 'text-size', ['interpolate', ['linear'], ['zoom'], 9.5, 9.5, 12, 10.8, 14, 11.8, 16, 12.8]);
      setOverviewLayout('highway-name-major', 'symbol-spacing', 220);
      setOverviewPaint('highway-name-major', 'text-color', isNight ? '#e2e8f0' : '#334155');
      setOverviewPaint('highway-name-major', 'text-halo-color', isNight ? '#0c1320' : '#ffffff');
      setOverviewPaint('highway-name-major', 'text-halo-width', 1.8);
      setOverviewPaint('highway-name-major', 'text-opacity', 0.95);
    }
  }

  // 5. Ruta morada por encima de todo
  applyOverviewActiveRouteStyle(map);
}

function restoreNormalMapStyleFromOverview(
  map: maplibregl.Map,
  mode: MapTileMode,
  savedMap: Map<string, OverviewLayerSnapshot>
): void {
  for (const [layerId, snap] of savedMap.entries()) {
    if (!map.getLayer(layerId)) continue;
    try {
      map.setLayoutProperty(layerId, 'visibility', snap.visibility ?? 'visible');
    } catch {}
    try {
      map.setLayerZoomRange(layerId, snap.minzoom, snap.maxzoom);
    } catch {}
    for (const [prop, val] of Object.entries(snap.layout)) {
      if (prop === 'visibility') continue;
      try {
        map.setLayoutProperty(layerId, prop as any, val);
      } catch {}
    }
    for (const [prop, val] of Object.entries(snap.paint)) {
      try {
        map.setPaintProperty(layerId, prop as any, val);
      } catch {}
    }
  }
  savedMap.clear();

  // Reaplicar estilos propios de Día / Noche de RUTA LIMA
  applyWazeStyleEnhancements(map, mode);

  // Restaurar estilo normal de la ruta activa
  const normalActiveStyle = (mode === 'night' ? NIGHT_ROUTE_STYLE : DAY_ROUTE_STYLE).active;
  const safeSetPaint = (layerId: string, prop: string, value: any) => {
    try {
      if (map.getLayer(layerId)) {
        map.setPaintProperty(layerId, prop as any, value);
      }
    } catch {}
  };
  safeSetPaint('ruta-active-glow', 'line-color', normalActiveStyle.glowColor);
  safeSetPaint('ruta-active-glow', 'line-width', normalActiveStyle.glowWidth);
  safeSetPaint('ruta-active-glow', 'line-opacity', normalActiveStyle.glowOpacity);
  safeSetPaint('ruta-active-glow', 'line-blur', normalActiveStyle.glowBlur);

  safeSetPaint('ruta-active-outline', 'line-color', normalActiveStyle.outlineColor);
  safeSetPaint('ruta-active-outline', 'line-width', normalActiveStyle.outlineWidth);
  safeSetPaint('ruta-active-outline', 'line-opacity', normalActiveStyle.outlineOpacity);

  safeSetPaint('ruta-active-line', 'line-color', normalActiveStyle.lineColor);
  safeSetPaint('ruta-active-line', 'line-width', normalActiveStyle.lineWidth);
  safeSetPaint('ruta-active-line', 'line-opacity', normalActiveStyle.lineOpacity);
}

function createExactDestPinHTML(): string {
  return `
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:flex-end;width:30px;height:38px;margin:0;padding:0;pointer-events:none;">
      <svg width="30" height="38" viewBox="0 0 30 38" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:block;filter:drop-shadow(0 3px 5px rgba(0,0,0,0.55));">
        <path d="M15 1.5C7.544 1.5 1.5 7.544 1.5 15c0 9.6 11.78 19.86 12.92 20.84a.9.9 0 0 0 1.16 0C16.72 34.86 28.5 24.6 28.5 15 28.5 7.544 22.456 1.5 15 1.5Z" fill="#e11d48" stroke="#ffffff" stroke-width="2.2"/>
        <circle cx="15" cy="14.5" r="5.2" fill="#ffffff"/>
      </svg>
    </div>
  `;
}

function coordsToLngLat(coords: [number, number][]): [number, number][] {
  return coords.map(([lat, lng]) => [lng, lat]);
}

function buildRouteCumulativeDistances(coords: [number, number][]): number[] {
  const cum = new Array<number>(coords.length).fill(0);
  for (let i = 1; i < coords.length; i++) {
    cum[i] =
      cum[i - 1] +
      getDistanceMeters(coords[i - 1][0], coords[i - 1][1], coords[i][0], coords[i][1]);
  }
  return cum;
}

function sampleRouteCoordAtDistanceFraction(
  coords: [number, number][],
  cumDist: number[],
  fraction: number
): [number, number] {
  if (!coords || coords.length === 0) return [0, 0];
  if (coords.length === 1) return coords[0];
  const total = cumDist[cumDist.length - 1] || 0;
  if (total <= 1) {
    return coords[Math.min(coords.length - 1, Math.floor(coords.length * fraction))];
  }
  const target = total * Math.max(0.05, Math.min(0.95, fraction));
  for (let i = 0; i < cumDist.length - 1; i++) {
    const d0 = cumDist[i];
    const d1 = cumDist[i + 1];
    if (target <= d1) {
      const segLen = d1 - d0;
      const t = segLen > 0 ? Math.max(0, Math.min(1, (target - d0) / segLen)) : 0;
      return [
        coords[i][0] + (coords[i + 1][0] - coords[i][0]) * t,
        coords[i][1] + (coords[i + 1][1] - coords[i][1]) * t,
      ];
    }
  }
  return coords[Math.floor(coords.length / 2)];
}

function computeNonOverlappingRouteLabelCoords(
  map: maplibregl.Map,
  routesList: RouteData[],
  selectedRouteId: string | undefined,
  fastestRouteId: string | undefined,
  userPos: Coordinates | null | undefined,
  destPos: Coordinates | null | undefined,
  previewPadding: { top: number; bottom: number; left: number; right: number }
): Map<string, [number, number]> {
  const result = new Map<string, [number, number]>();
  const validRoutes = routesList.filter((r) => r.coordinates.length >= 2);
  if (validRoutes.length === 0) return result;

  const bounds = new maplibregl.LngLatBounds();
  for (const r of validRoutes) {
    for (const [lat, lng] of r.coordinates) {
      bounds.extend([lng, lat]);
    }
  }
  const hasValidUser =
    Number.isFinite(userPos?.lat) &&
    Number.isFinite(userPos?.lng) &&
    !(Math.abs(userPos!.lat) < 0.01 && Math.abs(userPos!.lng) < 0.01);
  if (hasValidUser) {
    bounds.extend([userPos!.lng, userPos!.lat]);
  }
  if (destPos && Number.isFinite(destPos.lat) && Number.isFinite(destPos.lng)) {
    bounds.extend([destPos.lng, destPos.lat]);
  }

  let camZoom = map.getZoom();
  try {
    const cam = map.cameraForBounds(bounds, {
      padding: previewPadding,
      bearing: 0,
      pitch: 0,
      maxZoom: 17,
    });
    if (cam && typeof cam.zoom === 'number' && Number.isFinite(cam.zoom)) {
      camZoom = cam.zoom;
    }
  } catch {}

  const worldSize = 512 * Math.pow(2, camZoom);
  const toPx = (lat: number, lng: number): [number, number] => {
    const x = ((lng + 180) / 360) * worldSize;
    const clampedLat = Math.max(-85, Math.min(85, lat));
    const sinLat = Math.sin((clampedLat * Math.PI) / 180);
    const y = (0.5 - Math.log((1 + sinLat) / (1 - sinLat)) / (4 * Math.PI)) * worldSize;
    return [x, y];
  };

  interface PlacedRect {
    x: number;
    y: number;
    w: number;
    h: number;
  }

  const placedRects: PlacedRect[] = [];
  if (hasValidUser) {
    const [ux, uy] = toPx(userPos!.lat, userPos!.lng);
    placedRects.push({ x: ux, y: uy, w: 40, h: 40 });
  }
  if (destPos && Number.isFinite(destPos.lat) && Number.isFinite(destPos.lng)) {
    const [dx, dy] = toPx(destPos.lat, destPos.lng);
    placedRects.push({ x: dx, y: dy - 18, w: 38, h: 46 });
  }

  const cumMap = new Map<string, number[]>();
  const sampledOtherMap = new Map<string, Array<[number, number]>>();
  for (const r of validRoutes) {
    const cum = buildRouteCumulativeDistances(r.coordinates);
    cumMap.set(r.id, cum);
    const pts: Array<[number, number]> = [];
    for (let f = 0.14; f <= 0.86; f += 0.06) {
      const c = sampleRouteCoordAtDistanceFraction(r.coordinates, cum, f);
      pts.push(toPx(c[0], c[1]));
    }
    sampledOtherMap.set(r.id, pts);
  }

  // Place selected route first, then fastest, then others
  const placementOrder = [...validRoutes].sort((a, b) => {
    const aSel = a.id === selectedRouteId ? 0 : a.id === fastestRouteId ? 1 : 2;
    const bSel = b.id === selectedRouteId ? 0 : b.id === fastestRouteId ? 1 : 2;
    return aSel - bSel;
  });

  const candidateFractions = [0.5, 0.43, 0.57, 0.36, 0.64, 0.29, 0.71, 0.22, 0.78, 0.16, 0.84];

  for (const r of placementOrder) {
    const cum = cumMap.get(r.id)!;
    const isSelected = r.id === selectedRouteId;
    const isFastest = r.id === fastestRouteId;
    const w = isSelected ? (isFastest ? 116 : 82) : 68;
    const h = isSelected ? 40 : 32;

    const otherPts: Array<[number, number]> = [];
    for (const other of validRoutes) {
      if (other.id !== r.id) {
        otherPts.push(...(sampledOtherMap.get(other.id) || []));
      }
    }

    let bestCleanScore = Infinity;
    let bestCleanCoord: [number, number] | null = null;
    let bestCleanRect: PlacedRect | null = null;

    let bestFallbackClearance = -Infinity;
    let bestFallbackCoord: [number, number] = sampleRouteCoordAtDistanceFraction(
      r.coordinates,
      cum,
      0.5
    );
    let bestFallbackRect: PlacedRect = {
      x: toPx(bestFallbackCoord[0], bestFallbackCoord[1])[0],
      y: toPx(bestFallbackCoord[0], bestFallbackCoord[1])[1] - h / 2,
      w,
      h,
    };

    for (const frac of candidateFractions) {
      const coord = sampleRouteCoordAtDistanceFraction(r.coordinates, cum, frac);
      const [px, py] = toPx(coord[0], coord[1]);
      const centerY = py - h / 2;

      let overlaps = false;
      let minClearance = Infinity;
      for (const rect of placedRects) {
        const reqDx = (w + rect.w) / 2 + 12;
        const reqDy = (h + rect.h) / 2 + 10;
        const dx = Math.abs(px - rect.x);
        const dy = Math.abs(centerY - rect.y);
        if (dx < reqDx && dy < reqDy) {
          overlaps = true;
        }
        const clearance = Math.max(dx - reqDx, dy - reqDy);
        if (clearance < minClearance) {
          minClearance = clearance;
        }
      }

      let minOtherRoutePx = 30;
      if (otherPts.length > 0) {
        minOtherRoutePx = Infinity;
        for (const [ox, oy] of otherPts) {
          const d = Math.hypot(px - ox, py - oy);
          if (d < minOtherRoutePx) minOtherRoutePx = d;
        }
      }

      if (!overlaps) {
        const score = Math.abs(frac - 0.5) * 115 - Math.min(26, minOtherRoutePx) * 1.4;
        if (score < bestCleanScore) {
          bestCleanScore = score;
          bestCleanCoord = coord;
          bestCleanRect = { x: px, y: centerY, w, h };
        }
      } else if (minClearance > bestFallbackClearance) {
        bestFallbackClearance = minClearance;
        bestFallbackCoord = coord;
        bestFallbackRect = { x: px, y: centerY, w, h };
      }
    }

    if (bestCleanCoord && bestCleanRect) {
      result.set(r.id, bestCleanCoord);
      placedRects.push(bestCleanRect);
    } else {
      result.set(r.id, bestFallbackCoord);
      placedRects.push(bestFallbackRect);
    }
  }

  return result;
}

type ManeuverFeatureCollection = {
  type: 'FeatureCollection';
  features: any[];
};

const EMPTY_MANEUVER_FC: ManeuverFeatureCollection = {
  type: 'FeatureCollection',
  features: [],
};

function createManeuverArrowImageData(
  fillColor: string,
  strokeColor: string | null,
  strokeWidth: number
): { width: number; height: number; data: Uint8Array } {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return { width: size, height: size, data: new Uint8Array(size * size * 4) };
  }

  ctx.clearRect(0, 0, size, size);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  ctx.beginPath();
  ctx.moveTo(32, 11);
  ctx.lineTo(50, 43);
  ctx.lineTo(32, 38);
  ctx.lineTo(14, 43);
  ctx.closePath();

  if (strokeColor && strokeWidth > 0) {
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = strokeWidth;
    ctx.stroke();
  }
  ctx.fillStyle = fillColor;
  ctx.fill();

  const imgData = ctx.getImageData(0, 0, size, size);
  return {
    width: size,
    height: size,
    data: new Uint8Array(imgData.data.buffer),
  };
}

function interpolateLatLng(a: [number, number], b: [number, number], t: number): [number, number] {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
}

function smoothSharpTurnCorners(pts: [number, number][]): [number, number][] {
  if (pts.length < 3) return pts;
  const out: [number, number][] = [pts[0]];

  for (let i = 1; i < pts.length - 1; i++) {
    const prev = pts[i - 1];
    const curr = pts[i];
    const next = pts[i + 1];

    const lenIn = getDistanceMeters(prev[0], prev[1], curr[0], curr[1]);
    const lenOut = getDistanceMeters(curr[0], curr[1], next[0], next[1]);

    if (lenIn < 1.5 || lenOut < 1.5) {
      out.push(curr);
      continue;
    }

    const bIn = getBearing(prev[0], prev[1], curr[0], curr[1]);
    const bOut = getBearing(curr[0], curr[1], next[0], next[1]);
    const turnAngle = Math.abs(((bOut - bIn + 540) % 360) - 180);

    // Subtle fillet on sharp corners (>= 30 deg) keeps white curve smooth inside blue route casing
    if (turnAngle >= 30 && lenIn >= 4 && lenOut >= 4) {
      const filletMeters = Math.min(3.2, lenIn * 0.35, lenOut * 0.35);
      const q0 = interpolateLatLng(curr, prev, filletMeters / lenIn);
      const q2 = interpolateLatLng(curr, next, filletMeters / lenOut);

      out.push(q0);
      for (const t of [0.25, 0.5, 0.75]) {
        const omt = 1 - t;
        out.push([
          omt * omt * q0[0] + 2 * omt * t * curr[0] + t * t * q2[0],
          omt * omt * q0[1] + 2 * omt * t * curr[1] + t * t * q2[1],
        ]);
      }
      out.push(q2);
    } else {
      out.push(curr);
    }
  }

  out.push(pts[pts.length - 1]);
  return out;
}

function buildManeuverArrowGeoJSON(
  coords: [number, number][],
  step: RouteStep
): ManeuverFeatureCollection {
  if (!coords || coords.length < 2) return EMPTY_MANEUVER_FC;

  // Dibuja giros (izquierda/derecha/rotonda/retorno) y también maniobras rectas sobre la ruta morada
  if (step.type === 'depart') return EMPTY_MANEUVER_FC;

  const [stepLat, stepLng] = step.coordinates;
  let turnIdx = 0;
  let bestStepDist = Infinity;
  for (let i = 0; i < coords.length; i++) {
    const d = getDistanceMeters(stepLat, stepLng, coords[i][0], coords[i][1]);
    if (d < bestStepDist) {
      bestStepDist = d;
      turnIdx = i;
      if (d < 2) break;
    }
  }

  if (bestStepDist > 120) {
    return EMPTY_MANEUVER_FC;
  }

  // Extract route geometry from ~24m before the maneuver to ~20m after it
  const BEFORE_METERS = 24;
  const AFTER_METERS = 20;

  const beforePoints: [number, number][] = [];
  let accumBack = 0;
  for (let i = turnIdx; i > 0; i--) {
    const segLen = getDistanceMeters(coords[i][0], coords[i][1], coords[i - 1][0], coords[i - 1][1]);
    if (segLen <= 0.05) continue;
    if (accumBack + segLen >= BEFORE_METERS) {
      const ratio = (BEFORE_METERS - accumBack) / segLen;
      beforePoints.push(interpolateLatLng(coords[i], coords[i - 1], ratio));
      accumBack = BEFORE_METERS;
      break;
    }
    beforePoints.push(coords[i - 1]);
    accumBack += segLen;
  }
  beforePoints.reverse();

  const afterPoints: [number, number][] = [];
  let accumForward = 0;
  for (let i = turnIdx; i < coords.length - 1; i++) {
    const segLen = getDistanceMeters(coords[i][0], coords[i][1], coords[i + 1][0], coords[i + 1][1]);
    if (segLen <= 0.05) continue;
    if (accumForward + segLen >= AFTER_METERS) {
      const ratio = (AFTER_METERS - accumForward) / segLen;
      afterPoints.push(interpolateLatLng(coords[i], coords[i + 1], ratio));
      accumForward = AFTER_METERS;
      break;
    }
    afterPoints.push(coords[i + 1]);
    accumForward += segLen;
  }

  if (accumForward < 3 && accumBack < 6) {
    return EMPTY_MANEUVER_FC;
  }

  const rawSlice: [number, number][] = [...beforePoints, coords[turnIdx], ...afterPoints];
  const cleanSlice: [number, number][] = [];
  for (const pt of rawSlice) {
    if (
      cleanSlice.length === 0 ||
      getDistanceMeters(
        cleanSlice[cleanSlice.length - 1][0],
        cleanSlice[cleanSlice.length - 1][1],
        pt[0],
        pt[1]
      ) >= 0.3
    ) {
      cleanSlice.push(pt);
    }
  }

  if (cleanSlice.length < 2) {
    return EMPTY_MANEUVER_FC;
  }

  const smoothPts = smoothSharpTurnCorners(cleanSlice);
  const endPt = smoothPts[smoothPts.length - 1];

  // Orient arrowhead along the final outgoing segment of the curve
  let tailRef = smoothPts[smoothPts.length - 2];
  for (let i = smoothPts.length - 2; i >= 0; i--) {
    const d = getDistanceMeters(smoothPts[i][0], smoothPts[i][1], endPt[0], endPt[1]);
    tailRef = smoothPts[i];
    if (d >= 2.5) break;
  }

  const arrowBearing = getBearing(tailRef[0], tailRef[1], endPt[0], endPt[1]);
  if (!Number.isFinite(arrowBearing)) {
    return EMPTY_MANEUVER_FC;
  }

  return {
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        properties: { role: 'stem' },
        geometry: {
          type: 'LineString',
          coordinates: coordsToLngLat(smoothPts),
        },
      },
      {
        type: 'Feature',
        properties: { role: 'tip', bearing: ((arrowBearing % 360) + 360) % 360 },
        geometry: {
          type: 'Point',
          coordinates: [endPt[1], endPt[0]],
        },
      },
    ],
  };
}

interface NavigationMapProps {
  userLocation: GPSLocation;
  routes: RouteData[];
  activeRoute: RouteData | null;
  onSelectRoute?: (route: RouteData) => void;
  destinationCoords: Coordinates | null;
  mapTileMode: MapTileMode;
  isFollowing: boolean;
  onToggleFollow: (following: boolean) => void;
  onTileModeChange: (mode: MapTileMode) => void;
  isNavigating: boolean;
  trafficAlerts?: TrafficAlert[];
  onConfirmAlert?: (alertId: string) => void;
  onRemoveAlert?: (alertId: string) => void;
  onToggleAlertBothDirections?: (alertId: string) => void;
  onRegisterCarriagewaySnapper?: (
    snapper:
      | ((
          lat: number,
          lng: number,
          targetHeadingDeg: number,
          maxDistMeters?: number
        ) => CarriagewaySnapResult | null)
      | null
  ) => void;
  onOpenReportIncident?: () => void;
  distanceToNextStep?: number;
  currentStep?: RouteStep;
  nextStep?: RouteStep;
  currentRoadName?: string;
  speedKmh?: number;
  travelMode?: TravelMode;
  onRequestLocation?: () => void;
  overviewTrigger?: number;
  recenterTrigger?: number;
  focusCoordsTrigger?: { lat: number; lng: number; zoom?: number; seq: number } | null;
  onSettingsChange?: (settings: MapSettingsData) => void;
  onSettingsOpenChange?: (isOpen: boolean) => void;
  onAddFixedRadarOpenChange?: (isOpen: boolean) => void;
  onMapInteraction?: () => void;
  onUserExplorationGesture?: () => void;
  onNavigateToPOI?: (poi: MapPOI) => void;
  onPoisUpdated?: (pois: MapPOI[]) => void;
  onFixedRadarsUpdated?: (radars: FixedRadar[]) => void;
  onStartRouteToDestination?: (destination: SearchResult) => void;
  isOverlayModalOpen?: boolean;
  isLoadingRoute?: boolean;
}

export const NavigationMap: React.FC<NavigationMapProps> = ({
  userLocation,
  routes,
  activeRoute,
  onSelectRoute,
  destinationCoords,
  mapTileMode,
  isFollowing,
  onToggleFollow,
  onTileModeChange,
  isNavigating,
  trafficAlerts = [],
  onConfirmAlert,
  onRemoveAlert,
  onToggleAlertBothDirections,
  onRegisterCarriagewaySnapper,
  onOpenReportIncident,
  distanceToNextStep = 9999,
  currentStep,
  nextStep,
  currentRoadName,
  speedKmh = 0,
  onRequestLocation,
  overviewTrigger,
  recenterTrigger,
  focusCoordsTrigger,
  onSettingsChange,
  onSettingsOpenChange,
  onAddFixedRadarOpenChange,
  onMapInteraction,
  onUserExplorationGesture,
  onNavigateToPOI,
  onPoisUpdated,
  onFixedRadarsUpdated,
  onStartRouteToDestination,
  isOverlayModalOpen = false,
  isLoadingRoute = false,
}) => {
  const rootContainerRef = useRef<HTMLDivElement>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<maplibregl.Map | null>(null);
  const isMapStyleReadyRef = useRef<boolean>(false);
  const prevTileModeRef = useRef<MapTileMode>(mapTileMode);
  const mapTileModeRef = useRef<MapTileMode>(mapTileMode);
  mapTileModeRef.current = mapTileMode;

  const userMarkerRef = useRef<maplibregl.Marker | null>(null);
  const destMarkerRef = useRef<maplibregl.Marker | null>(null);
  const routeTimeMarkersRef = useRef<maplibregl.Marker[]>([]);
  const maneuverGeoJsonRef = useRef<ManeuverFeatureCollection>(EMPTY_MANEUVER_FC);
  const nextStreetBubbleMarkerRef = useRef<maplibregl.Marker | null>(null);
  const nextStreetBubbleLabelRef = useRef<string>('');
  const nextStreetBubbleModeRef = useRef<MapTileMode>(mapTileMode);
  const alertMarkersRef = useRef<maplibregl.Marker[]>([]);
  const lastFittedRouteKeyRef = useRef<string | null>(null);
  const lastFittedDestKeyRef = useRef<string | null>(null);
  const lastFittedPanelHeightRef = useRef<number | null>(null);
  const lastSelectedPreviewRouteIdRef = useRef<string | null>(null);
  const userInteractedInPreviewRef = useRef<boolean>(false);
  const previewFitDebounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const previewFitTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const previewFitInitialRafRef = useRef<number | null>(null);
  const isLoadingRouteRef = useRef<boolean>(isLoadingRoute);
  isLoadingRouteRef.current = isLoadingRoute;
  const prevIsLoadingRouteRef = useRef<boolean>(isLoadingRoute);
  const handleUserPreviewRouteTapRef = useRef<(route: RouteData) => void>(() => {});
  const routeLineClickedAtRef = useRef<number>(0);
  const [resolvedCurrentStreet, setResolvedCurrentStreet] = useState<string>('');

  // Smooth marker interpolation & synced follow-camera refs (requestAnimationFrame 60 FPS)
  const currentMarkerPosRef = useRef<[number, number]>([userLocation.lat, userLocation.lng]);
  const targetMarkerPosRef = useRef<[number, number]>([userLocation.lat, userLocation.lng]);
  const currentMarkerAngleRef = useRef<number>(normalizeHeadingDeg(userLocation.heading || 0));
  const targetMarkerAngleRef = useRef<number>(normalizeHeadingDeg(userLocation.heading || 0));
  const animFrameIdRef = useRef<number | null>(null);
  const lastAnimTimeRef = useRef<number>(performance.now());
  const currentIconModeRef = useRef<string | null>(null);

  // Linear position interpolation + dead-reckoning anticipation + route projection state
  const hasInitializedArrowRef = useRef<boolean>(false);
  const posAnimStartRef = useRef<[number, number]>([userLocation.lat, userLocation.lng]);
  const posAnimEndRef = useRef<[number, number]>([userLocation.lat, userLocation.lng]);
  const posAnimStartTimeRef = useRef<number>(performance.now());
  const posAnimDurationRef = useRef<number>(1000);
  const lastGpsFixPerfTimeRef = useRef<number | null>(null);
  const lastProcessedFixSignatureRef = useRef<string>('');
  const velocityMpsRef = useRef<number>(0);
  const velocityBearingRef = useRef<number>(normalizeHeadingDeg(userLocation.heading || 0));
  const isVehicleMovingRef = useRef<boolean>(false);
  const isSnappedToRouteRef = useRef<boolean>(false);
  const snappedSegmentIdxRef = useRef<number>(0);
  const idleRoadSegmentRef = useRef<IdleRoadSegment | null>(null);

  // Smooth shortest-arc rotation (~300 ms, ignoring deltas < 5°)
  const committedTargetAngleRef = useRef<number>(normalizeHeadingDeg(userLocation.heading || 0));
  const rotAnimStartAngleRef = useRef<number>(normalizeHeadingDeg(userLocation.heading || 0));
  const rotAnimDeltaDegRef = useRef<number>(0);
  const rotAnimStartTimeRef = useRef<number>(performance.now());

  // Tab background visibility & direct camera snap tracking
  const wasPageHiddenRef = useRef<boolean>(false);
  const snapOnNextFixRef = useRef<boolean>(false);
  const cameraNeedsImmediateSnapRef = useRef<boolean>(false);

  // Synced follow-camera target parameters & frame guard
  const followCamTargetZoomRef = useRef<number>(ZOOM_PANTALLA_PRINCIPAL);
  // Velocidad suavizada para el zoom dinámico (evita que el zoom "respire" con cada cambio del GPS)
  const smoothedZoomSpeedRef = useRef<{ value: number; at: number }>({ value: 0, at: 0 });
  const followCamTargetBearingRef = useRef<number>(0);
  const followCamTargetPitchRef = useRef<number>(0);
  const followCamTargetPaddingRef = useRef<maplibregl.PaddingOptions>({
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  });
  const isFollowCameraJumpActiveRef = useRef<boolean>(false);
  const lastFollowPoiRefreshTimeRef = useRef<number>(0);

  // Synchronized state refs for callbacks & async map listeners
  const userLocationRef = useRef(userLocation);
  userLocationRef.current = userLocation;
  const routesRef = useRef(routes);
  routesRef.current = routes;
  const activeRouteRef = useRef(activeRoute);
  activeRouteRef.current = activeRoute;
  const destinationCoordsRef = useRef(destinationCoords);
  destinationCoordsRef.current = destinationCoords;
  const distanceToNextStepRef = useRef(distanceToNextStep);
  distanceToNextStepRef.current = distanceToNextStep;
  const speedKmhRef = useRef(speedKmh);
  speedKmhRef.current = speedKmh;
  const onSelectRouteRef = useRef(onSelectRoute);
  onSelectRouteRef.current = onSelectRoute;

  // Programmatic movement guard & pending atomic recenter flag
  const isProgrammaticMoveRef = useRef<boolean>(false);
  const isProgrammaticCameraRef = useRef<boolean>(false);
  const isAtomicRecenterInFlightRef = useRef<boolean>(false);
  const isIdleUserPointerDownRef = useRef<boolean>(false);
  // Dedo apoyado sobre el mapa: la cámara automática se pausa al instante para no pelear con el gesto
  const isUserTouchingMapRef = useRef<boolean>(false);
  const userTouchStartedAtRef = useRef<number>(0);
  const idleGestureStartRef = useRef<{ x: number; y: number; pinchDist?: number; zoom: number } | null>(null);
  const isNavigatingRef = useRef<boolean>(isNavigating);
  isNavigatingRef.current = isNavigating;
  const isFollowingRef = useRef<boolean>(isFollowing);
  isFollowingRef.current = isFollowing;
  const hasAnyRoutesRef = useRef<boolean>(Boolean(activeRoute || routes.length > 0));
  hasAnyRoutesRef.current = Boolean(activeRoute || routes.length > 0);
  const pendingRecenterRef = useRef<boolean>(false);
  const recenterWaitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const programmaticClearTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const programmaticCameraTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const idlePitchLockTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevIdlePerspective3DRef = useRef<boolean>(false);
  const flatFallbackActiveRef = useRef<boolean>(false);
  const [pitchFallbackNotice, setPitchFallbackNotice] = useState<string | null>(null);
  const pitchFallbackTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingStyleCameraRef = useRef<{
    center: maplibregl.LngLat;
    zoom: number;
    bearing: number;
    pitch: number;
    padding: maplibregl.PaddingOptions;
  } | null>(null);
  const styleFallbackStageRef = useRef<OpenFreeMapFallbackStage>('liberty');
  const hasVectorSourceLoadedRef = useRef<boolean>(false);
  const styleLoadFallbackTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [activeAttributionMode, setActiveAttributionMode] = useState<'openfreemap' | 'osm_raster' | 'satellite'>(
    () => (mapTileMode === 'satellite' ? 'satellite' : 'openfreemap')
  );

  // Settings State
  const [mapSettings, setMapSettings] = useState<MapSettingsData>(() =>
    getInitialSettings(mapTileMode)
  );
  const mapSettingsRef = useRef<MapSettingsData>(mapSettings);
  mapSettingsRef.current = mapSettings;
  // Tamaño de los controles laterales (Ajustes → Tamaño de controles laterales)
  const controlSizeClass = mapSettings.controlsSize === 'large' ? 'w-14 h-14' : 'w-11 h-11';
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [alertOpacityTick, setAlertOpacityTick] = useState<number>(0);

  // Rotation State (autoRotation applies strictly during active navigation) and manual rotation tracking
  const [isHeadingUp, setIsHeadingUp] = useState<boolean>(() => mapSettings.autoRotation);
  const isHeadingUpRef = useRef<boolean>(isHeadingUp);
  isHeadingUpRef.current = isHeadingUp;
  const [mapRotation, setMapRotation] = useState<number>(0);
  const [isManuallyRotated, setIsManuallyRotated] = useState<boolean>(false);
  const isManuallyRotatedRef = useRef<boolean>(false);
  const lastValidHeadingRef = useRef<number>(
    userLocation.heading !== null &&
      userLocation.heading !== undefined &&
      Number.isFinite(userLocation.heading)
      ? ((userLocation.heading % 360) + 360) % 360
      : 0
  );
  // Orientación automática en pantalla principal sin ruta activa (CAMBIO 2)
  const isIdleAutoOrientActiveRef = useRef<boolean>(true);
  const idleCommittedHeadingRef = useRef<number | null>(null);
  const idleStopNorthTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevIdleGpsPosRef = useRef<{ lat: number; lng: number } | null>(null);
  const compassHeadingRef = useRef<number | null>(null);
  const idleBearingAnimRef = useRef<{
    active: boolean;
    startBearing: number;
    targetBearing: number;
    startTime: number;
    durationMs: number;
  }>({
    active: false,
    startBearing: 0,
    targetBearing: 0,
    startTime: 0,
    durationMs: 400,
  });

  const lastHandledOverviewTriggerRef = useRef<number>(0);
  const lastHandledRecenterTriggerRef = useRef<number>(0);
  const prevNavigatingRef = useRef<boolean>(isNavigating);
  const prevHasActiveRouteRef = useRef<boolean>(Boolean(activeRoute || routes.length > 0));

  // Overpass Points of Interest (POIs) state & refs
  const [isOverviewActive, setIsOverviewActive] = useState<boolean>(false);
  const isOverviewActiveRef = useRef<boolean>(false);
  isOverviewActiveRef.current = isOverviewActive;
  const justExitedOverviewUntilRef = useRef<number>(0);
  const overviewSavedLayersRef = useRef<Map<string, OverviewLayerSnapshot>>(new Map());
  const overviewZoomAnchorRef = useRef<number | undefined>(undefined);
  const [selectedPoi, setSelectedPoi] = useState<MapPOI | null>(null);
  const cachedPoisByIdRef = useRef<Map<string, MapPOI>>(new Map());
  const lastPoiSourceSignatureRef = useRef<string>('');
  const poiLayerListenersBoundRef = useRef<boolean>(false);
  const poiFeatureClickedAtRef = useRef<number>(0);
  const poiDebounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const poiRetryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const poiAbortControllerRef = useRef<AbortController | null>(null);
  const inFlightPoiBoundsRef = useRef<GeoBounds | null>(null);
  const poiRetryCountRef = useRef<number>(0);

  // Global callbacks for marker popup interactions
  const onConfirmAlertRef = useRef(onConfirmAlert);
  onConfirmAlertRef.current = onConfirmAlert;
  const onRemoveAlertRef = useRef(onRemoveAlert);
  onRemoveAlertRef.current = onRemoveAlert;
  const onToggleAlertBothDirectionsRef = useRef(onToggleAlertBothDirections);
  onToggleAlertBothDirectionsRef.current = onToggleAlertBothDirections;

  useEffect(() => {
    if (!onRegisterCarriagewaySnapper) return;
    onRegisterCarriagewaySnapper((lat, lng, targetHeadingDeg, maxDistMeters = 38) => {
      const map = mapInstanceRef.current;
      if (!map) return null;
      return snapReportPointToRenderedCarriageway(map, lat, lng, targetHeadingDeg, maxDistMeters);
    });
    return () => {
      onRegisterCarriagewaySnapper(null);
    };
  }, [onRegisterCarriagewaySnapper]);
  const onSettingsChangeRef = useRef(onSettingsChange);
  onSettingsChangeRef.current = onSettingsChange;
  const onSettingsOpenChangeRef = useRef(onSettingsOpenChange);
  onSettingsOpenChangeRef.current = onSettingsOpenChange;
  const onAddFixedRadarOpenChangeRef = useRef(onAddFixedRadarOpenChange);
  onAddFixedRadarOpenChangeRef.current = onAddFixedRadarOpenChange;
  const trafficAlertsRef = useRef(trafficAlerts);
  trafficAlertsRef.current = trafficAlerts;
  const onUserExplorationGestureRef = useRef(onUserExplorationGesture || onMapInteraction);
  onUserExplorationGestureRef.current = onUserExplorationGesture || onMapInteraction;
  const onToggleFollowRef = useRef(onToggleFollow);
  onToggleFollowRef.current = onToggleFollow;
  const onRequestLocationRef = useRef(onRequestLocation);
  onRequestLocationRef.current = onRequestLocation;
  const onNavigateToPOIRef = useRef(onNavigateToPOI);
  onNavigateToPOIRef.current = onNavigateToPOI;
  const onPoisUpdatedRef = useRef(onPoisUpdated);
  onPoisUpdatedRef.current = onPoisUpdated;
  const onFixedRadarsUpdatedRef = useRef(onFixedRadarsUpdated);
  onFixedRadarsUpdatedRef.current = onFixedRadarsUpdated;
  const onStartRouteToDestinationRef = useRef(onStartRouteToDestination);
  onStartRouteToDestinationRef.current = onStartRouteToDestination;

  // Radares fijos referenciales & tramos Sutran (state & refs)
  const [fixedRadarsList, setFixedRadarsList] = useState<FixedRadar[]>([]);
  const fixedRadarsListRef = useRef<FixedRadar[]>([]);
  fixedRadarsListRef.current = fixedRadarsList;
  const [selectedFixedRadar, setSelectedFixedRadar] = useState<FixedRadar | null>(null);
  const [selectedCommunityAlert, setSelectedCommunityAlert] = useState<TrafficAlert | null>(null);
  const [isCommunityAlertClosing, setIsCommunityAlertClosing] = useState<boolean>(false);
  const isCommunityAlertClosingRef = useRef<boolean>(false);
  const communityAlertCloseTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [draggingRadarId, setDraggingRadarId] = useState<string | null>(null);
  const draggingRadarIdRef = useRef<string | null>(null);
  draggingRadarIdRef.current = draggingRadarId;
  const [draggedRadarCoords, setDraggedRadarCoords] = useState<Coordinates | null>(null);
  const [isAddFixedRadarOpen, setIsAddFixedRadarOpen] = useState<boolean>(false);
  const [isPickingRadarLocation, setIsPickingRadarLocation] = useState<boolean>(false);
  const isPickingRadarLocationRef = useRef<boolean>(false);
  isPickingRadarLocationRef.current = isPickingRadarLocation;
  const [pickedRadarCoords, setPickedRadarCoords] = useState<{
    lat: number;
    lng: number;
    seq: number;
  } | null>(null);
  const confirmRadarPickAtCoords = useCallback((lat: number, lng: number) => {
    setPickedRadarCoords((prev) => ({
      lat,
      lng,
      seq: (prev?.seq ?? 0) + 1,
    }));
    setIsPickingRadarLocation(false);
  }, []);
  const confirmRadarPickAtCoordsRef = useRef(confirmRadarPickAtCoords);
  confirmRadarPickAtCoordsRef.current = confirmRadarPickAtCoords;
  const [radarActionFeedback, setRadarActionFeedback] = useState<string | null>(null);
  const fixedRadarMarkersRef = useRef<maplibregl.Marker[]>([]);
  const fixedRadarStripListenersBoundRef = useRef<boolean>(false);

  useEffect(() => {
    onAddFixedRadarOpenChangeRef.current?.(isAddFixedRadarOpen);
    if (!isAddFixedRadarOpen) {
      setIsPickingRadarLocation(false);
    }
  }, [isAddFixedRadarOpen]);

  // Presión larga sobre el mapa (marcador temporal + ventanita "Ruta" / "Compartir")
  const [longPressPoint, setLongPressPoint] = useState<{
    lat: number;
    lng: number;
    label: string;
    address: string | null;
    district?: string;
    isLoadingLabel: boolean;
    addressFound: boolean;
  } | null>(null);
  const [longPressScreenPos, setLongPressScreenPos] = useState<{ x: number; y: number } | null>(null);
  const [shareCopiedToast, setShareCopiedToast] = useState<boolean>(false);
  const longPressMarkerRef = useRef<maplibregl.Marker | null>(null);
  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressReverseAbortRef = useRef<AbortController | null>(null);
  const justTriggeredLongPressRef = useRef<boolean>(false);
  const hasPushedLongPressHistoryRef = useRef<boolean>(false);
  const ignoringLongPressPopstateRef = useRef<boolean>(false);
  const isAnyOverlayOpenRef = useRef<boolean>(false);
  isAnyOverlayOpenRef.current = Boolean(
    isOverlayModalOpen || isSettingsOpen || isAddFixedRadarOpen
  );

  // Mantener una sola ventanita abierta a la vez y cerrarla al tocar fuera sobre el mapa
  useEffect(() => {
    if (selectedPoi && !isOverviewActive) {
      notifySmallOverlayOpen('poi_card', () => setSelectedPoi(null));
    } else {
      notifySmallOverlayClose('poi_card');
    }
    return () => {
      notifySmallOverlayClose('poi_card');
    };
  }, [selectedPoi, isOverviewActive]);

  useEffect(() => {
    if (selectedFixedRadar) {
      notifySmallOverlayOpen('radar_card', () => {
        setDraggingRadarId(null);
        setDraggedRadarCoords(null);
        setRadarActionFeedback(null);
        setSelectedFixedRadar(null);
      });
    } else {
      notifySmallOverlayClose('radar_card');
    }
    return () => {
      notifySmallOverlayClose('radar_card');
    };
  }, [selectedFixedRadar]);

  const closeCommunityAlertImmediate = useCallback(() => {
    if (communityAlertCloseTimerRef.current) {
      clearTimeout(communityAlertCloseTimerRef.current);
      communityAlertCloseTimerRef.current = null;
    }
    isCommunityAlertClosingRef.current = false;
    setIsCommunityAlertClosing(false);
    setSelectedCommunityAlert(null);
  }, []);

  const closeCommunityAlertSmooth = useCallback(() => {
    if (communityAlertCloseTimerRef.current) {
      clearTimeout(communityAlertCloseTimerRef.current);
    }
    isCommunityAlertClosingRef.current = true;
    setIsCommunityAlertClosing(true);
    communityAlertCloseTimerRef.current = setTimeout(() => {
      communityAlertCloseTimerRef.current = null;
      isCommunityAlertClosingRef.current = false;
      setIsCommunityAlertClosing(false);
      setSelectedCommunityAlert(null);
    }, 150);
  }, []);

  const openCommunityAlertCard = useCallback((alert: TrafficAlert) => {
    if (communityAlertCloseTimerRef.current) {
      clearTimeout(communityAlertCloseTimerRef.current);
      communityAlertCloseTimerRef.current = null;
    }
    isCommunityAlertClosingRef.current = false;
    setIsCommunityAlertClosing(false);
    setSelectedCommunityAlert(alert);
  }, []);

  useEffect(() => {
    return () => {
      if (communityAlertCloseTimerRef.current) {
        clearTimeout(communityAlertCloseTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (selectedCommunityAlert) {
      notifySmallOverlayOpen('alert_popup', closeCommunityAlertImmediate);
    } else {
      notifySmallOverlayClose('alert_popup');
    }
    return () => {
      notifySmallOverlayClose('alert_popup');
    };
  }, [selectedCommunityAlert, closeCommunityAlertImmediate]);

  useEffect(() => {
    if (longPressPoint && !isNavigating) {
      notifySmallOverlayOpen('long_press', () => dismissLongPressRef.current());
    } else {
      notifySmallOverlayClose('long_press');
    }
    return () => {
      notifySmallOverlayClose('long_press');
    };
  }, [longPressPoint, isNavigating]);

  const beginProgrammaticCameraLock = useCallback((map: maplibregl.Map, durationMs = 400) => {
    if (programmaticCameraTimerRef.current) {
      clearTimeout(programmaticCameraTimerRef.current);
      programmaticCameraTimerRef.current = null;
    }
    isProgrammaticCameraRef.current = true;
    const clearCamLock = () => {
      map.off('moveend', clearCamLock);
      if (programmaticCameraTimerRef.current) {
        clearTimeout(programmaticCameraTimerRef.current);
        programmaticCameraTimerRef.current = null;
      }
      isProgrammaticCameraRef.current = false;
    };
    map.once('moveend', clearCamLock);
    programmaticCameraTimerRef.current = setTimeout(clearCamLock, Math.max(250, durationMs + 120));
  }, []);

  useEffect(() => {
    onSettingsChangeRef.current?.(mapSettings);
  }, [mapSettings]);

  useEffect(() => {
    onSettingsOpenChangeRef.current?.(isSettingsOpen);
  }, [isSettingsOpen]);

  // Refrescar opacidad de marcadores de inspectores cada 60 segundos
  useEffect(() => {
    const hasInspectors = trafficAlerts.some((a) => a.type === 'inspectors');
    if (!hasInspectors) return;
    const interval = setInterval(() => {
      setAlertOpacityTick((t) => t + 1);
    }, 60000);
    return () => clearInterval(interval);
  }, [trafficAlerts]);

  // Center map on specific coordinates (e.g. tapping an inspector item in LiveInspectorsModal)
  const lastHandledFocusSeqRef = useRef<number>(0);
  useEffect(() => {
    if (
      !focusCoordsTrigger ||
      focusCoordsTrigger.seq === lastHandledFocusSeqRef.current ||
      !mapInstanceRef.current ||
      (!isNavigatingRef.current && hasAnyRoutesRef.current)
    ) {
      return;
    }
    lastHandledFocusSeqRef.current = focusCoordsTrigger.seq;
    const map = mapInstanceRef.current;

    onToggleFollowRef.current(false);
    isManuallyRotatedRef.current = false;
    setIsManuallyRotated(false);
    setMapRotation(0);
    isProgrammaticMoveRef.current = true;
    map.stop();
    beginProgrammaticCameraLock(map, 750);

    const targetPitch =
      !isNavigatingRef.current &&
      !hasAnyRoutesRef.current &&
      mapSettingsRef.current.perspective3D &&
      !flatFallbackActiveRef.current
        ? getEffectiveIdlePitch()
        : 0;

    try {
      map.flyTo({
        center: [focusCoordsTrigger.lng, focusCoordsTrigger.lat],
        zoom: focusCoordsTrigger.zoom ?? 17,
        pitch: targetPitch,
        bearing: 0,
        padding: { top: 0, bottom: 0, left: 0, right: 0 },
        duration: 700,
      });
    } catch {}

    const timer = setTimeout(() => {
      isProgrammaticMoveRef.current = false;
    }, 800);
    return () => clearTimeout(timer);
  }, [focusCoordsTrigger, beginProgrammaticCameraLock]);

  // Update settings callback
  const handleUpdateSettings = useCallback(
    (partial: Partial<MapSettingsData>) => {
      setMapSettings((prev) => {
        const updated = { ...prev, ...partial };
        try {
          localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(updated));
        } catch (err) {
          console.warn('Error saving map settings to localStorage', err);
        }
        return updated;
      });

      if (partial.tileMode !== undefined && partial.tileMode !== mapTileMode) {
        onTileModeChange(partial.tileMode);
      }
      if (partial.autoRotation !== undefined) {
        setIsHeadingUp(partial.autoRotation);
      }
      if (partial.autoFollowGPS !== undefined) {
        onToggleFollow(partial.autoFollowGPS);
      }
      if (partial.voiceEnabled !== undefined) {
        voiceGuidance.setMuted(!partial.voiceEnabled);
      }
      if (partial.voiceVolume !== undefined) {
        voiceGuidance.setVolume(partial.voiceVolume);
      }
      if (partial.rerouteSoundEnabled !== undefined) {
        voiceGuidance.setRerouteSoundEnabled(partial.rerouteSoundEnabled);
      }
    },
    [mapTileMode, onTileModeChange, onToggleFollow]
  );

  const getEffectiveNavPitch = useCallback((): number => {
    if (flatFallbackActiveRef.current || !mapSettingsRef.current.perspective3D) return 0;
    return NAV_PITCH_DEGREES;
  }, []);

  const getEffectiveIdlePitch = useCallback((): number => {
    if (flatFallbackActiveRef.current || !mapSettingsRef.current.perspective3D) return 0;
    return INCLINACION_PANTALLA_PRINCIPAL;
  }, []);

  const applyPitchGesturePolicy = useCallback(
    (map: maplibregl.Map, opts?: { unlockingForTransition?: boolean }) => {
      const isNav = isNavigatingRef.current;
      const isOverview = isOverviewActiveRef.current;
      const hasRoutes = hasAnyRoutesRef.current;
      const flatFallback = flatFallbackActiveRef.current;
      const p3d = mapSettingsRef.current.perspective3D;

      try {
        if (isNav && p3d && !flatFallback && !isOverview) {
          map.touchPitch.enable();
        } else {
          map.touchPitch.disable();
        }
        const dragRotateAny = map.dragRotate as any;
        if (dragRotateAny) {
          dragRotateAny._pitchWithRotate = Boolean(isNav && p3d && !flatFallback && !isOverview);
          if (dragRotateAny._mousePitch) {
            if (dragRotateAny._pitchWithRotate && map.dragRotate.isEnabled()) {
              dragRotateAny._mousePitch.enable();
            } else {
              dragRotateAny._mousePitch.disable();
            }
          }
        }
        if (!isNav && hasRoutes && !isOverview) {
          map.dragRotate.disable();
          map.touchZoomRotate.disableRotation();
        } else {
          map.dragRotate.enable();
          map.touchZoomRotate.enableRotation();
        }
      } catch {}

      try {
        if (!isNav && !hasRoutes && !isOverview) {
          map.setMinZoom(12);
          map.setMaxZoom(19.5);
        } else if (!isNav && hasRoutes && !isOverview) {
          map.setMinZoom(8);
          map.setMaxZoom(19);
        } else {
          map.setMinZoom(11);
          map.setMaxZoom(19);
        }
      } catch {}

      try {
        if (opts?.unlockingForTransition || isNav || isOverview) {
          map.setMinPitch(0);
          map.setMaxPitch(flatFallback ? 0 : 60);
        } else if (hasRoutes) {
          map.setMinPitch(0);
          map.setMaxPitch(0);
        } else if (p3d && !flatFallback) {
          const targetIdlePitch = getEffectiveIdlePitch();
          map.setMinPitch(targetIdlePitch);
          map.setMaxPitch(targetIdlePitch);
        } else {
          map.setMinPitch(0);
          map.setMaxPitch(0);
        }
      } catch {}
    },
    [getEffectiveIdlePitch]
  );

  const activateFlatFallback = useCallback((map?: maplibregl.Map | null) => {
    const wasAlreadyFlat = flatFallbackActiveRef.current;
    flatFallbackActiveRef.current = true;

    if (map) {
      try {
        map.setMinPitch(0);
        map.setMaxPitch(0);
        map.touchPitch.disable();
        map.jumpTo({
          center: map.getCenter(),
          zoom: map.getZoom(),
          bearing: map.getBearing(),
          pitch: 0,
          padding: { top: 0, bottom: 0, left: 0, right: 0 },
        });
        map.resize();
        map.triggerRepaint();
      } catch {}
    }

    if (!wasAlreadyFlat) {
      const noticeText = 'Vista 3D no disponible; usando mapa plano.';
      logSystemNotice(noticeText, 'Respaldo a mapa plano 2D (pitchFallbackNotice)');
      setPitchFallbackNotice(noticeText);
      if (pitchFallbackTimerRef.current) {
        clearTimeout(pitchFallbackTimerRef.current);
      }
      pitchFallbackTimerRef.current = setTimeout(() => {
        pitchFallbackTimerRef.current = null;
        setPitchFallbackNotice(null);
      }, 4000);
    }
  }, []);

  const verifyPitchedRender = useCallback(
    (map: maplibregl.Map) => {
      requestAnimationFrame(() => {
        if (!mapInstanceRef.current || flatFallbackActiveRef.current) return;
        try {
          const canvas = map.getCanvas();
          if (!canvas || canvas.width === 0 || canvas.height === 0) return;
          const gl =
            (canvas.getContext('webgl2') as WebGL2RenderingContext | null) ||
            (canvas.getContext('webgl') as WebGLRenderingContext | null);
          if (gl?.isContextLost?.() || !Number.isFinite(map.getPitch())) {
            activateFlatFallback(map);
          }
        } catch {
          activateFlatFallback(map);
        }
      });
    },
    [activateFlatFallback]
  );

  const getSmoothedZoomSpeed = useCallback((speedKmh: number): number => {
    const now = performance.now();
    const st = smoothedZoomSpeedRef.current;
    const v = Number.isFinite(speedKmh) ? Math.max(0, speedKmh) : 0;
    if (st.at === 0 || now - st.at > 15000) {
      smoothedZoomSpeedRef.current = { value: v, at: now };
      return v;
    }
    const dtSec = Math.max(0, (now - st.at) / 1000);
    const alpha = 1 - Math.exp(-dtSec / 4);
    const next = st.value + (v - st.value) * alpha;
    smoothedZoomSpeedRef.current = { value: next, at: now };
    return next;
  }, []);

  // Zoom dinámico durante la navegación: según velocidad (18.0 detenido → 15.0 a 100 km/h)
  // y acercamiento a 18.0 al estar a menos de 200 m del giro (pleno a ≤150 m).
  const calculateSmartZoom = useCallback(
    (distToTurn: number, currentSpeed: number): number => {
      if (!isNavigatingRef.current) return 16;
      if (!mapSettingsRef.current.smartZoom) return 16;
      const speedZoom = speedToZoom(getSmoothedZoomSpeed(currentSpeed));
      if (distToTurn > 0 && distToTurn < MANEUVER_ZOOM_START_M) {
        const t = Math.min(
          1,
          (MANEUVER_ZOOM_START_M - distToTurn) / (MANEUVER_ZOOM_START_M - MANEUVER_ZOOM_FULL_M)
        );
        return Math.max(speedZoom, speedZoom + t * (MANEUVER_ZOOM - speedZoom));
      }
      return speedZoom;
    },
    [getSmoothedZoomSpeed]
  );

  // Zoom dinámico antes de navegar (pantalla principal siguiendo tu ubicación): solo por velocidad
  const calculateIdleZoom = useCallback(
    (currentSpeed: number): number => {
      if (!mapSettingsRef.current.smartZoom) return ZOOM_PANTALLA_PRINCIPAL;
      return speedToZoom(getSmoothedZoomSpeed(currentSpeed));
    },
    [getSmoothedZoomSpeed]
  );

  // Resolve a guaranteed valid bearing (0..360), preserving last valid heading when stopped
  const resolveValidBearing = useCallback(
    (loc: GPSLocation, route: RouteData | null, currentSpeedKmh: number): number => {
      const isMoving = currentSpeedKmh >= 2.5;

      // 1. If actively navigating and snapped to route, align with road segment ahead
      if (isNavigatingRef.current && route && route.coordinates.length >= 2) {
        const match = matchUserToRoute(loc.lat, loc.lng, loc.heading, route.coordinates);
        if (match.isSnapped && Number.isFinite(match.arrowBearing)) {
          const norm = ((match.arrowBearing % 360) + 360) % 360;
          lastValidHeadingRef.current = norm;
          return norm;
        }
      }

      // 2. Use GPS heading when moving (or when no prior non-zero heading exists)
      if (loc.heading !== null && loc.heading !== undefined && Number.isFinite(loc.heading)) {
        const norm = ((loc.heading % 360) + 360) % 360;
        if (isMoving || (lastValidHeadingRef.current === 0 && norm !== 0)) {
          lastValidHeadingRef.current = norm;
          return norm;
        }
      }

      // 3. If user is stopped and heading hasn't been set yet, derive from route's first segment
      if (lastValidHeadingRef.current === 0 && route && route.coordinates.length >= 2) {
        const b = getBearing(
          route.coordinates[0][0],
          route.coordinates[0][1],
          route.coordinates[1][0],
          route.coordinates[1][1]
        );
        if (Number.isFinite(b)) {
          const norm = ((b % 360) + 360) % 360;
          lastValidHeadingRef.current = norm;
          return norm;
        }
      }

      // 4. Fallback to last valid heading (never empty/null/NaN)
      return Number.isFinite(lastValidHeadingRef.current) ? lastValidHeadingRef.current : 0;
    },
    []
  );

  // Con Perspectiva 3D activada, posiciona al vehículo más abajo para ver mayor tramo de calle por delante
  const computeLowerThirdPadding = useCallback(
    (containerHeight?: number): maplibregl.PaddingOptions => {
      const viewportHeight =
        containerHeight || (typeof window !== 'undefined' ? window.innerHeight : 700) || 700;
      const ratio = mapSettingsRef.current.perspective3D ? 0.45 : 0.36;
      const topPad = Math.round(
        Math.min(viewportHeight * (ratio + 0.03), Math.max(125, viewportHeight * ratio))
      );
      return {
        top: topPad,
        bottom: 0,
        left: 0,
        right: 0,
      };
    },
    []
  );

  // En pantalla principal sin ruta activa, ubica la flecha en POSICION_FLECHA_ABAJO (1/4 desde abajo)
  const computeIdleArrowPadding = useCallback(
    (containerHeight?: number): maplibregl.PaddingOptions => {
      const viewportHeight =
        containerHeight || (typeof window !== 'undefined' ? window.innerHeight : 700) || 700;
      const topRatio = Math.max(0, Math.min(0.65, 1 - 2 * POSICION_FLECHA_ABAJO));
      const topPad = Math.round(viewportHeight * topRatio);
      return {
        top: topPad,
        bottom: 0,
        left: 0,
        right: 0,
      };
    },
    []
  );

  const getLowerThirdPadding = useCallback(
    (map: maplibregl.Map): maplibregl.PaddingOptions => {
      if (isNavigatingRef.current) {
        return computeLowerThirdPadding(map.getContainer().clientHeight);
      }
      const isTiltedIdleTracking =
        !hasAnyRoutesRef.current &&
        isFollowingRef.current &&
        mapSettingsRef.current.perspective3D &&
        !flatFallbackActiveRef.current;
      if (!isTiltedIdleTracking) {
        return { top: 0, bottom: 0, left: 0, right: 0 };
      }
      return computeIdleArrowPadding(map.getContainer().clientHeight);
    },
    [computeLowerThirdPadding, computeIdleArrowPadding]
  );

  // Ensure route GeoJSON sources & layers exist on the current style
  const ensureRouteLayers = useCallback((map: maplibregl.Map) => {
    if (!isMapStyleReadyForSources(map)) return false;

    if (!map.getSource(FIXED_RADAR_STRIPS_SOURCE_ID)) {
      map.addSource(FIXED_RADAR_STRIPS_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });
    }

    if (!map.getSource(PREVIEW_ROUTES_SOURCE_ID)) {
      map.addSource(PREVIEW_ROUTES_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });
    }

    if (!map.getSource(ACTIVE_ROUTE_SOURCE_ID)) {
      map.addSource(ACTIVE_ROUTE_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });
    }

    if (!map.getLayer(FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID)) {
      map.addLayer({
        id: FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID,
        type: 'line',
        source: FIXED_RADAR_STRIPS_SOURCE_ID,
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': '#ffffff',
          'line-width': ['interpolate', ['linear'], ['zoom'], 8, 7, 13, 10, 16, 13],
          'line-opacity': isOverviewActiveRef.current ? 0 : 0.88,
          'line-opacity-transition': { duration: 200, delay: 0 },
        },
      });
    }

    if (!map.getLayer(FIXED_RADAR_STRIPS_FILL_LAYER_ID)) {
      map.addLayer({
        id: FIXED_RADAR_STRIPS_FILL_LAYER_ID,
        type: 'line',
        source: FIXED_RADAR_STRIPS_SOURCE_ID,
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': '#db2777',
          'line-width': ['interpolate', ['linear'], ['zoom'], 8, 4.2, 13, 6.2, 16, 8.5],
          'line-opacity': isOverviewActiveRef.current ? 0 : 0.92,
          'line-opacity-transition': { duration: 200, delay: 0 },
          'line-dasharray': [2.2, 1.2],
        },
      });

      if (!fixedRadarStripListenersBoundRef.current) {
        fixedRadarStripListenersBoundRef.current = true;
        map.on('click', FIXED_RADAR_STRIPS_FILL_LAYER_ID, (e: maplibregl.MapLayerMouseEvent) => {
          if (isOverviewActiveRef.current) return;
          if (isPickingRadarLocationRef.current) return;
          if (shouldSuppressMapClick()) return;
          const radarId = e.features?.[0]?.properties?.radarId;
          if (!radarId) return;
          const found = fixedRadarsListRef.current.find((r) => r.id === radarId);
          if (found) {
            dismissLongPressRef.current();
            setSelectedPoi(null);
            setDraggingRadarId(null);
            setDraggedRadarCoords(null);
            setRadarActionFeedback(null);
            setSelectedFixedRadar(found);
          }
        });
        map.on('mouseenter', FIXED_RADAR_STRIPS_FILL_LAYER_ID, () => {
          if (isOverviewActiveRef.current) return;
          map.getCanvas().style.cursor = 'pointer';
        });
        map.on('mouseleave', FIXED_RADAR_STRIPS_FILL_LAYER_ID, () => {
          map.getCanvas().style.cursor = '';
        });
      }
    }

    const routeStyle = mapTileModeRef.current === 'night' ? NIGHT_ROUTE_STYLE : DAY_ROUTE_STYLE;

    if (!map.getLayer('ruta-preview-glow')) {
      map.addLayer({
        id: 'ruta-preview-glow',
        type: 'line',
        source: PREVIEW_ROUTES_SOURCE_ID,
        filter: ['==', ['get', 'isSelected'], true],
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': routeStyle.preview.glowColor,
          'line-width': routeStyle.preview.glowWidth,
          'line-opacity': routeStyle.preview.glowOpacity,
          'line-blur': routeStyle.preview.glowBlur,
        },
      });
    }

    if (!map.getLayer('ruta-preview-outline')) {
      map.addLayer({
        id: 'ruta-preview-outline',
        type: 'line',
        source: PREVIEW_ROUTES_SOURCE_ID,
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': routeStyle.preview.outlineColor,
          'line-width': routeStyle.preview.outlineWidth,
          'line-opacity': routeStyle.preview.outlineOpacity,
        },
      });
    }

    if (!map.getLayer('ruta-preview-line')) {
      map.addLayer({
        id: 'ruta-preview-line',
        type: 'line',
        source: PREVIEW_ROUTES_SOURCE_ID,
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': ['get', 'color'],
          'line-width': routeStyle.preview.lineWidth,
          'line-opacity': routeStyle.preview.lineOpacity,
        },
      });

      map.on('click', 'ruta-preview-line', (e: maplibregl.MapLayerMouseEvent) => {
        if (isNavigatingRef.current) return;
        routeLineClickedAtRef.current = performance.now();
        const currActiveId = activeRouteRef.current?.id;
        const features = e.features || [];
        const targetFeature =
          features.find((f) => f.properties?.routeId && f.properties.routeId !== currActiveId) ||
          features[0];
        const routeId = targetFeature?.properties?.routeId;
        if (routeId) {
          const found = routesRef.current.find((r) => r.id === routeId);
          if (found) handleUserPreviewRouteTapRef.current(found);
        }
      });

      map.on('mouseenter', 'ruta-preview-line', () => {
        if (!isNavigatingRef.current) map.getCanvas().style.cursor = 'pointer';
      });
      map.on('mouseleave', 'ruta-preview-line', () => {
        map.getCanvas().style.cursor = '';
      });
    }

    if (!map.getLayer('ruta-active-glow')) {
      map.addLayer({
        id: 'ruta-active-glow',
        type: 'line',
        source: ACTIVE_ROUTE_SOURCE_ID,
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': routeStyle.active.glowColor,
          'line-width': routeStyle.active.glowWidth,
          'line-opacity': routeStyle.active.glowOpacity,
          'line-blur': routeStyle.active.glowBlur,
        },
      });
    }

    if (!map.getLayer('ruta-active-outline')) {
      map.addLayer({
        id: 'ruta-active-outline',
        type: 'line',
        source: ACTIVE_ROUTE_SOURCE_ID,
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': routeStyle.active.outlineColor,
          'line-width': routeStyle.active.outlineWidth,
          'line-opacity': routeStyle.active.outlineOpacity,
        },
      });
    }

    if (!map.getLayer('ruta-active-line')) {
      map.addLayer({
        id: 'ruta-active-line',
        type: 'line',
        source: ACTIVE_ROUTE_SOURCE_ID,
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: {
          'line-color': routeStyle.active.lineColor,
          'line-width': routeStyle.active.lineWidth,
          'line-opacity': routeStyle.active.lineOpacity,
        },
      });
    }

    // Flecha blanca de maniobra con contorno oscuro nítido directamente sobre la ruta morada
    const isDay = mapTileModeRef.current === 'day';
    const maneuverOutlineColor = '#111827';
    const beforeCollisionId = map.getLayer(DEST_COLLISION_LAYER_ID)
      ? DEST_COLLISION_LAYER_ID
      : undefined;

    if (!map.hasImage(MANEUVER_ARROW_OUTLINE_IMAGE_ID)) {
      try {
        map.addImage(
          MANEUVER_ARROW_OUTLINE_IMAGE_ID,
          createManeuverArrowImageData(maneuverOutlineColor, maneuverOutlineColor, 9),
          { pixelRatio: 2 }
        );
      } catch {}
    }

    if (!map.hasImage(MANEUVER_ARROW_FILL_IMAGE_ID)) {
      try {
        map.addImage(
          MANEUVER_ARROW_FILL_IMAGE_ID,
          createManeuverArrowImageData('#ffffff', '#ffffff', 3),
          { pixelRatio: 2 }
        );
      } catch {}
    }

    if (!map.getSource(MANEUVER_ARROW_SOURCE_ID)) {
      map.addSource(MANEUVER_ARROW_SOURCE_ID, {
        type: 'geojson',
        data: maneuverGeoJsonRef.current,
      });
    }

    const maneuverStemWidthExpr: any = [
      'interpolate',
      ['linear'],
      ['zoom'],
      12, 2.6,
      14, 3.6,
      15, 4.6,
      16, 5.4,
      17, 5.8,
      18, 6.2,
    ];
    const maneuverOutlineWidthExpr: any = [
      'interpolate',
      ['linear'],
      ['zoom'],
      12, 4.4,
      14, 5.8,
      15, 7.2,
      16, 8.2,
      17, 8.8,
      18, 9.4,
    ];
    const maneuverArrowSizeExpr: any = [
      'interpolate',
      ['linear'],
      ['zoom'],
      12, 0.50,
      14, 0.68,
      15, 0.84,
      16, 0.94,
      17, 1.02,
      18, 1.10,
    ];

    if (!map.getLayer('ruta-maneuver-outline')) {
      map.addLayer(
        {
          id: 'ruta-maneuver-outline',
          type: 'line',
          source: MANEUVER_ARROW_SOURCE_ID,
          filter: ['==', ['get', 'role'], 'stem'],
          layout: { 'line-cap': 'round', 'line-join': 'round' },
          paint: {
            'line-color': maneuverOutlineColor,
            'line-width': maneuverOutlineWidthExpr,
            'line-opacity': isDay ? 0.94 : 0.96,
          },
        },
        beforeCollisionId
      );
    }

    if (!map.getLayer('ruta-maneuver-arrow-outline')) {
      map.addLayer(
        {
          id: 'ruta-maneuver-arrow-outline',
          type: 'symbol',
          source: MANEUVER_ARROW_SOURCE_ID,
          filter: ['==', ['get', 'role'], 'tip'],
          layout: {
            'icon-image': MANEUVER_ARROW_OUTLINE_IMAGE_ID,
            'icon-size': maneuverArrowSizeExpr,
            'icon-rotate': ['get', 'bearing'],
            'icon-rotation-alignment': 'map',
            'icon-pitch-alignment': 'map',
            'icon-allow-overlap': true,
            'icon-ignore-placement': true,
            'icon-anchor': 'center',
          },
          paint: {
            'icon-opacity': isDay ? 0.94 : 0.96,
          },
        },
        beforeCollisionId
      );
    }

    if (!map.getLayer('ruta-maneuver-line')) {
      map.addLayer(
        {
          id: 'ruta-maneuver-line',
          type: 'line',
          source: MANEUVER_ARROW_SOURCE_ID,
          filter: ['==', ['get', 'role'], 'stem'],
          layout: { 'line-cap': 'round', 'line-join': 'round' },
          paint: {
            'line-color': '#ffffff',
            'line-width': maneuverStemWidthExpr,
            'line-opacity': 1,
          },
        },
        beforeCollisionId
      );
    }

    if (!map.getLayer('ruta-maneuver-arrow')) {
      map.addLayer(
        {
          id: 'ruta-maneuver-arrow',
          type: 'symbol',
          source: MANEUVER_ARROW_SOURCE_ID,
          filter: ['==', ['get', 'role'], 'tip'],
          layout: {
            'icon-image': MANEUVER_ARROW_FILL_IMAGE_ID,
            'icon-size': maneuverArrowSizeExpr,
            'icon-rotate': ['get', 'bearing'],
            'icon-rotation-alignment': 'map',
            'icon-pitch-alignment': 'map',
            'icon-allow-overlap': true,
            'icon-ignore-placement': true,
            'icon-anchor': 'center',
          },
          paint: {
            'icon-opacity': 1,
          },
        },
        beforeCollisionId
      );
    }

    // Transparent collision-blocker symbol above map labels so text underneath the red destination pin hides instead of cutting off (e.g. "IMA")
    if (!map.hasImage(DEST_COLLISION_IMAGE_ID)) {
      try {
        map.addImage(DEST_COLLISION_IMAGE_ID, {
          width: 44,
          height: 50,
          data: new Uint8Array(44 * 50 * 4),
        });
      } catch {}
    }

    if (!map.getSource(DEST_COLLISION_SOURCE_ID)) {
      map.addSource(DEST_COLLISION_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });
    }

    if (!map.getLayer(DEST_COLLISION_LAYER_ID)) {
      map.addLayer({
        id: DEST_COLLISION_LAYER_ID,
        type: 'symbol',
        source: DEST_COLLISION_SOURCE_ID,
        layout: {
          'icon-image': DEST_COLLISION_IMAGE_ID,
          'icon-size': 1,
          'icon-anchor': 'bottom',
          'icon-allow-overlap': true,
          'icon-ignore-placement': false,
          'icon-padding': 6,
        },
      });
    }

    // Garantizar que las capas de POIs queden siempre por debajo de franjas de radar, rutas y pin de destino
    const beforeFixedOrRouteId = map.getLayer(FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID)
      ? FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID
      : map.getLayer('ruta-preview-glow')
      ? 'ruta-preview-glow'
      : map.getLayer('ruta-active-glow')
      ? 'ruta-active-glow'
      : map.getLayer('ruta-maneuver-outline')
      ? 'ruta-maneuver-outline'
      : map.getLayer(DEST_COLLISION_LAYER_ID)
      ? DEST_COLLISION_LAYER_ID
      : undefined;
    for (const poiLayerId of [POI_REGULAR_LAYER_ID, POI_ESSENTIAL_LAYER_ID]) {
      try {
        if (map.getLayer(poiLayerId) && beforeFixedOrRouteId) {
          map.moveLayer(poiLayerId, beforeFixedOrRouteId);
        }
      } catch {}
    }

    // Garantizar que el bloqueador de colisión de destino y las rutas queden por encima de todas las calles y edificios 2D/3D
    try {
      if (map.getLayer(DEST_COLLISION_LAYER_ID)) {
        map.moveLayer(DEST_COLLISION_LAYER_ID);
      }
    } catch {}
    for (const mId of [
      'ruta-maneuver-outline',
      'ruta-maneuver-arrow-outline',
      'ruta-maneuver-line',
      'ruta-maneuver-arrow',
    ]) {
      try {
        if (map.getLayer(mId) && map.getLayer(DEST_COLLISION_LAYER_ID)) {
          map.moveLayer(mId, DEST_COLLISION_LAYER_ID);
        }
      } catch {}
    }

    const beforeManeuverOrCollisionId = map.getLayer('ruta-maneuver-outline')
      ? 'ruta-maneuver-outline'
      : map.getLayer(DEST_COLLISION_LAYER_ID)
      ? DEST_COLLISION_LAYER_ID
      : undefined;
    for (const id of [
      'ruta-preview-glow',
      'ruta-preview-outline',
      'ruta-preview-line',
      'ruta-active-glow',
      'ruta-active-outline',
      'ruta-active-line',
    ]) {
      try {
        if (map.getLayer(id)) {
          map.moveLayer(id, beforeManeuverOrCollisionId);
        }
      } catch {}
    }

    return true;
  }, []);

  const syncDestCollisionBlocker = useCallback((map: maplibregl.Map, coords: Coordinates | null) => {
    try {
      if (!isMapStyleReadyForSources(map)) return;
      const src = map.getSource(DEST_COLLISION_SOURCE_ID) as maplibregl.GeoJSONSource | undefined;
      if (!src) return;
      if (coords) {
        src.setData({
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              properties: {},
              geometry: {
                type: 'Point',
                coordinates: [coords.lng, coords.lat],
              },
            },
          ],
        });
      } else {
        src.setData({ type: 'FeatureCollection', features: [] });
      }
    } catch {}
  }, []);

  // Push active or preview route geometry into MapLibre GeoJSON sources
  const syncRouteDataToMap = useCallback(
    (map: maplibregl.Map) => {
      if (!ensureRouteLayers(map)) return;
      if (isOverviewActiveRef.current) {
        applyOverviewActiveRouteStyle(map);
      }

      const targetDestForBlocker =
        destinationCoordsRef.current ||
        activeRouteRef.current?.destinationCoords ||
        routesRef.current[0]?.destinationCoords ||
        null;
      syncDestCollisionBlocker(map, targetDestForBlocker);

      const activeSrc = map.getSource(ACTIVE_ROUTE_SOURCE_ID) as maplibregl.GeoJSONSource | undefined;
      const previewSrc = map.getSource(PREVIEW_ROUTES_SOURCE_ID) as maplibregl.GeoJSONSource | undefined;
      if (!activeSrc || !previewSrc) return;

      const currActive = activeRouteRef.current;
      const currRoutes = routesRef.current;
      const currLoc = userLocationRef.current;

      if (isNavigatingRef.current && currActive && currActive.coordinates.length >= 2) {
        const match = matchUserToRoute(
          currLoc.lat,
          currLoc.lng,
          currLoc.heading,
          currActive.coordinates
        );

        const coordsToDraw =
          match.remainingCoords.length >= 2 ? match.remainingCoords : currActive.coordinates;

        activeSrc.setData({
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              properties: {},
              geometry: {
                type: 'LineString',
                coordinates: coordsToLngLat(coordsToDraw),
              },
            },
          ],
        });
        previewSrc.setData({ type: 'FeatureCollection', features: [] });
        return;
      }

      // Clear active route & maneuver arrow sources when not navigating
      activeSrc.setData({ type: 'FeatureCollection', features: [] });
      if (!isNavigatingRef.current) {
        maneuverGeoJsonRef.current = EMPTY_MANEUVER_FC;
        try {
          const maneuverSrc = map.getSource(MANEUVER_ARROW_SOURCE_ID) as
            | maplibregl.GeoJSONSource
            | undefined;
          maneuverSrc?.setData(EMPTY_MANEUVER_FC);
        } catch {}
      }

      const routesToDraw =
        currRoutes.length > 0 ? currRoutes : currActive ? [currActive] : [];

      if (routesToDraw.length === 0) {
        previewSrc.setData({ type: 'FeatureCollection', features: [] });
        return;
      }

      const isNight = mapTileModeRef.current === 'night';
      const previewStyle = (isNight ? NIGHT_ROUTE_STYLE : DAY_ROUTE_STYLE).preview;
      try {
        if (map.getLayer('ruta-preview-glow')) {
          map.setPaintProperty('ruta-preview-glow', 'line-color', previewStyle.glowColor);
          map.setPaintProperty('ruta-preview-glow', 'line-width', previewStyle.glowWidth);
          map.setPaintProperty('ruta-preview-glow', 'line-opacity', previewStyle.glowOpacity);
        }
        if (map.getLayer('ruta-preview-outline')) {
          map.setPaintProperty('ruta-preview-outline', 'line-color', previewStyle.outlineColor);
          map.setPaintProperty('ruta-preview-outline', 'line-width', previewStyle.outlineWidth);
          map.setPaintProperty('ruta-preview-outline', 'line-opacity', previewStyle.outlineOpacity);
        }
        if (map.getLayer('ruta-preview-line')) {
          map.setPaintProperty('ruta-preview-line', 'line-width', previewStyle.lineWidth);
          map.setPaintProperty('ruta-preview-line', 'line-opacity', previewStyle.lineOpacity);
        }
      } catch {}

      const sortedByDuration = [...routesToDraw].sort((a, b) => a.duration - b.duration);
      const fastestId = sortedByDuration[0]?.id;

      // Non-selected routes first, selected route rendered on top
      const sortedRoutes = [...routesToDraw].sort((a, b) => {
        const isASelected = currActive ? a.id === currActive.id : a.id === fastestId;
        const isBSelected = currActive ? b.id === currActive.id : b.id === fastestId;
        return isASelected ? 1 : isBSelected ? -1 : 0;
      });

      const features = sortedRoutes
        .filter((r) => r.coordinates.length >= 2)
        .map((r) => {
          const isSelected = currActive ? r.id === currActive.id : r.id === fastestId;
          const isFastest = r.id === fastestId;
          const color = isSelected
            ? isNight
              ? '#a855f7'
              : '#9333ea'
            : isNight
            ? '#c4b5fd'
            : '#d8b4fe';
          return {
            type: 'Feature' as const,
            properties: {
              routeId: r.id,
              isSelected,
              isFastest,
              color,
            },
            geometry: {
              type: 'LineString' as const,
              coordinates: coordsToLngLat(r.coordinates),
            },
          };
        });

      previewSrc.setData({
        type: 'FeatureCollection',
        features,
      });
    },
    [ensureRouteLayers, syncDestCollisionBlocker]
  );

  // Perform the single atomic camera placement for "Volver a centrar"
  const performAtomicJump = useCallback(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    pendingRecenterRef.current = false;
    if (recenterWaitTimerRef.current) {
      clearTimeout(recenterWaitTimerRef.current);
      recenterWaitTimerRef.current = null;
    }
    if (programmaticClearTimerRef.current) {
      clearTimeout(programmaticClearTimerRef.current);
      programmaticClearTimerRef.current = null;
    }

    const loc = userLocationRef.current;
    const route = activeRouteRef.current;
    const speed = speedKmhRef.current;
    const distTurn = distanceToNextStepRef.current;

    const validBearing = resolveValidBearing(loc, route, speed);
    const navZoom = isNavigatingRef.current
      ? calculateSmartZoom(distTurn, speed)
      : calculateIdleZoom(speed);
    let idleRecenterBearing = 0;
    if (!isNavigatingRef.current && !route && isIdleAutoOrientActiveRef.current && speed > 5) {
      let cand: number | null = null;
      if (loc.heading !== null && loc.heading !== undefined && Number.isFinite(loc.heading) && loc.heading !== 0) {
        cand = ((loc.heading % 360) + 360) % 360;
      } else if (compassHeadingRef.current !== null) {
        cand = compassHeadingRef.current;
      }
      if (cand !== null) {
        idleCommittedHeadingRef.current = cand;
        idleRecenterBearing = cand;
      } else if (idleCommittedHeadingRef.current !== null) {
        idleRecenterBearing = idleCommittedHeadingRef.current;
      }
    }
    const navBearing = isNavigatingRef.current
      ? mapSettingsRef.current.autoRotation
        ? validBearing
        : 0
      : idleRecenterBearing;
    const navPitch = isNavigatingRef.current
      ? getEffectiveNavPitch()
      : !route
      ? getEffectiveIdlePitch()
      : 0;
    const navPadding = getLowerThirdPadding(map);

    if (isNavigatingRef.current) {
      map.setMinZoom(11);
      map.setMaxZoom(19);
      map.setMaxPitch(60);
      try {
        map.touchPitch.enable();
      } catch {}
    }

    let targetLat = loc.lat;
    let targetLng = loc.lng;
    let targetArrowBearing =
      !isNavigatingRef.current && !route && idleRecenterBearing !== 0
        ? idleRecenterBearing
        : validBearing;

    if (isNavigatingRef.current && route && route.coordinates.length >= 2) {
      const match = matchUserToRoute(loc.lat, loc.lng, loc.heading, route.coordinates);
      targetLat = match.arrowPoint[0];
      targetLng = match.arrowPoint[1];
      targetArrowBearing = Number.isFinite(match.arrowBearing)
        ? ((match.arrowBearing % 360) + 360) % 360
        : validBearing;
    }

    isProgrammaticMoveRef.current = true;
    isAtomicRecenterInFlightRef.current = true;
    beginProgrammaticCameraLock(map, 200);
    map.stop();

    let flagsCleared = false;
    const clearFlags = () => {
      if (flagsCleared) return;
      flagsCleared = true;
      if (programmaticClearTimerRef.current) {
        clearTimeout(programmaticClearTimerRef.current);
        programmaticClearTimerRef.current = null;
      }
      map.off('moveend', onMoveEnd);
      isProgrammaticMoveRef.current = false;
      isAtomicRecenterInFlightRef.current = false;
    };
    const onMoveEnd = () => {
      setTimeout(clearFlags, 80);
    };

    map.once('moveend', onMoveEnd);
    programmaticClearTimerRef.current = setTimeout(clearFlags, 1000);

    // Single atomic operation: center + zoom (nav 300-500m / 16 idle) + bearing + 55° pitch + lower-third offset
    map.resize();
    try {
      map.jumpTo({
        center: [targetLng, targetLat],
        zoom: navZoom,
        bearing: navBearing,
        pitch: navPitch,
        padding: navPadding,
      });
      if (!isNavigatingRef.current) {
        const roadProj = projectArrowOntoRoadSurface(
          map,
          loc.lat,
          loc.lng,
          targetArrowBearing,
          speed > 2 || targetArrowBearing !== 0
        );
        idleRoadSegmentRef.current = roadProj.segment;
        if (roadProj.projected) {
          targetLat = roadProj.point[0];
          targetLng = roadProj.point[1];
          if (getDistanceMeters(loc.lat, loc.lng, targetLat, targetLng) > 0.5) {
            map.jumpTo({
              center: [targetLng, targetLat],
              zoom: navZoom,
              bearing: navBearing,
              pitch: navPitch,
              padding: navPadding,
            });
          }
        }
      }
      if (navPitch > 0) {
        verifyPitchedRender(map);
      }
    } catch {
      activateFlatFallback(map);
    }
    map.resize();

    isManuallyRotatedRef.current = false;
    setIsManuallyRotated(false);
    setMapRotation(navBearing);

    // Synchronize arrow marker position, animation origins and rotation in the exact same frame
    currentMarkerPosRef.current = [targetLat, targetLng];
    targetMarkerPosRef.current = [targetLat, targetLng];
    posAnimStartRef.current = [targetLat, targetLng];
    posAnimEndRef.current = [targetLat, targetLng];
    posAnimStartTimeRef.current = performance.now();
    lastGpsFixPerfTimeRef.current = null;
    currentMarkerAngleRef.current = targetArrowBearing;
    targetMarkerAngleRef.current = targetArrowBearing;
    committedTargetAngleRef.current = targetArrowBearing;
    rotAnimStartAngleRef.current = targetArrowBearing;
    rotAnimDeltaDegRef.current = 0;
    followCamTargetZoomRef.current = navZoom;
    followCamTargetBearingRef.current = navBearing;
    followCamTargetPitchRef.current = navPitch;
    followCamTargetPaddingRef.current = navPadding;

    if (userMarkerRef.current) {
      userMarkerRef.current.setLngLat([targetLng, targetLat]);
      userMarkerRef.current.setRotation(targetArrowBearing);
    }
  }, [
    calculateSmartZoom,
    calculateIdleZoom,
    getLowerThirdPadding,
    resolveValidBearing,
    beginProgrammaticCameraLock,
    getEffectiveNavPitch,
    getEffectiveIdlePitch,
    activateFlatFallback,
    verifyPitchedRender,
  ]);

  // Execute atomic recenter immediately once initial style is ready (never stall on isStyleLoaded/areTilesLoaded)
  const executeAtomicRecenter = useCallback(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (recenterWaitTimerRef.current) {
      clearTimeout(recenterWaitTimerRef.current);
      recenterWaitTimerRef.current = null;
    }

    // Only defer if initial style hasn't finished its first load yet, with a 1s max safety cap
    if (!isMapStyleReadyRef.current) {
      pendingRecenterRef.current = true;
      isProgrammaticMoveRef.current = true;
      isAtomicRecenterInFlightRef.current = true;

      recenterWaitTimerRef.current = setTimeout(() => {
        recenterWaitTimerRef.current = null;
        if (pendingRecenterRef.current) {
          pendingRecenterRef.current = false;
          performAtomicJump();
        } else {
          isProgrammaticMoveRef.current = false;
          isAtomicRecenterInFlightRef.current = false;
        }
      }, 1000);
      return;
    }

    performAtomicJump();
  }, [performAtomicJump]);

  // Resolver rumbo en pantalla principal sin ruta: mantiene último rumbo si detenido/< 5 km/h y gira suave al avanzar
  const resolveIdleTrackingBearing = useCallback(
    (loc: GPSLocation, currentSpeedKmh: number): number => {
      if (
        !mapSettingsRef.current.perspective3D ||
        flatFallbackActiveRef.current ||
        !mapSettingsRef.current.autoRotation
      ) {
        return 0;
      }
      if (currentSpeedKmh > 5) {
        let candidateHeading: number | null = null;
        if (
          loc.heading !== null &&
          loc.heading !== undefined &&
          Number.isFinite(loc.heading) &&
          loc.heading !== 0
        ) {
          candidateHeading = normalizeHeadingDeg(loc.heading);
        } else if (compassHeadingRef.current !== null) {
          candidateHeading = compassHeadingRef.current;
        }
        if (candidateHeading !== null) {
          if (
            idleCommittedHeadingRef.current === null ||
            Math.abs(shortestAngleDiffDeg(idleCommittedHeadingRef.current, candidateHeading)) >= 10
          ) {
            idleCommittedHeadingRef.current = candidateHeading;
          }
        }
      }
      return idleCommittedHeadingRef.current ?? 0;
    },
    []
  );

  // Vuelve suavemente (~500 ms) a la vista inclinada de seguimiento en pantalla principal y reactiva seguimiento automático
  const returnToIdleTrackingView = useCallback(
    (durationMs: number = 500) => {
      const map = mapInstanceRef.current;
      if (!map || isNavigatingRef.current || hasAnyRoutesRef.current) return;

      if (idlePitchLockTimerRef.current) {
        clearTimeout(idlePitchLockTimerRef.current);
        idlePitchLockTimerRef.current = null;
      }

      onToggleFollowRef.current(true);
      isManuallyRotatedRef.current = false;
      setIsManuallyRotated(false);
      isIdleAutoOrientActiveRef.current = true;
      idleBearingAnimRef.current.active = false;

      const loc = userLocationRef.current;
      const speed = speedKmhRef.current;
      const useTiltedIdle =
        !hasAnyRoutesRef.current &&
        mapSettingsRef.current.perspective3D &&
        !flatFallbackActiveRef.current;

      const targetZoom = calculateIdleZoom(speed);
      const targetPitch = useTiltedIdle ? getEffectiveIdlePitch() : 0;
      const targetPadding = useTiltedIdle
        ? computeIdleArrowPadding(map.getContainer().clientHeight)
        : { top: 0, bottom: 0, left: 0, right: 0 };
      const targetBearing = useTiltedIdle ? resolveIdleTrackingBearing(loc, speed) : 0;

      let currentPitch = 0;
      try {
        currentPitch = map.getPitch();
      } catch {}
      const needsPitchTransition = Math.abs(currentPitch - targetPitch) > 0.5;
      if (needsPitchTransition) {
        applyPitchGesturePolicy(map, { unlockingForTransition: true });
      } else {
        applyPitchGesturePolicy(map);
      }

      isProgrammaticMoveRef.current = true;
      isAtomicRecenterInFlightRef.current = true;
      beginProgrammaticCameraLock(map, durationMs + 70);
      map.stop();

      let flagsCleared = false;
      const clearFlags = () => {
        if (flagsCleared) return;
        flagsCleared = true;
        map.off('moveend', onMoveEnd);
        if (programmaticClearTimerRef.current) {
          clearTimeout(programmaticClearTimerRef.current);
          programmaticClearTimerRef.current = null;
        }
        isProgrammaticMoveRef.current = false;
        isAtomicRecenterInFlightRef.current = false;
        applyPitchGesturePolicy(map);
      };
      const onMoveEnd = () => clearFlags();
      map.once('moveend', onMoveEnd);
      if (programmaticClearTimerRef.current) {
        clearTimeout(programmaticClearTimerRef.current);
      }
      programmaticClearTimerRef.current = setTimeout(clearFlags, durationMs + 100);

      followCamTargetZoomRef.current = targetZoom;
      followCamTargetBearingRef.current = targetBearing;
      followCamTargetPitchRef.current = targetPitch;
      followCamTargetPaddingRef.current = targetPadding;
      setMapRotation(targetBearing);

      const idleRoadProj = projectArrowOntoRoadSurface(
        map,
        loc.lat,
        loc.lng,
        targetBearing,
        speed > 2 || targetBearing !== 0
      );
      idleRoadSegmentRef.current = idleRoadProj.segment;
      const [idleLat, idleLng] = idleRoadProj.point;

      currentMarkerPosRef.current = [idleLat, idleLng];
      targetMarkerPosRef.current = [idleLat, idleLng];
      posAnimStartRef.current = [idleLat, idleLng];
      posAnimEndRef.current = [idleLat, idleLng];
      posAnimStartTimeRef.current = performance.now();
      lastGpsFixPerfTimeRef.current = null;
      if (userMarkerRef.current) {
        userMarkerRef.current.setLngLat([idleLng, idleLat]);
      }

      try {
        map.easeTo({
          center: [idleLng, idleLat],
          zoom: targetZoom,
          bearing: targetBearing,
          pitch: targetPitch,
          padding: targetPadding,
          duration: durationMs,
          essential: true,
        });
        if (targetPitch > 0) {
          verifyPitchedRender(map);
        }
      } catch {
        activateFlatFallback(map);
        clearFlags();
      }
    },
    [
      activateFlatFallback,
      applyPitchGesturePolicy,
      beginProgrammaticCameraLock,
      computeIdleArrowPadding,
      getEffectiveIdlePitch,
      resolveIdleTrackingBearing,
      verifyPitchedRender,
    ]
  );

  const syncBuildings3DLayer = useCallback((map: maplibregl.Map) => {
    if (!isMapStyleReadyForSources(map)) return;
    const show3D = Boolean(mapSettingsRef.current.buildings3D && !isOverviewActiveRef.current);
    try {
      if (map.getLayer('building-3d')) {
        map.setLayoutProperty('building-3d', 'visibility', show3D ? 'visible' : 'none');
      }
    } catch {}
  }, []);

  const syncBuildings3DLayerRef = useRef(syncBuildings3DLayer);
  syncBuildings3DLayerRef.current = syncBuildings3DLayer;

  // 1. Initialize MapLibre GL Map (Full viewport WebGL canvas, zero dark corners, upright street labels)
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const initialZoom = isNavigating ? 16 : ZOOM_PANTALLA_PRINCIPAL;
    const initialLat = userLocation.lat || -12.0464;
    const initialLng = userLocation.lng || -77.0428;
    const canIdleTiltInit =
      !isNavigating &&
      !hasAnyRoutesRef.current &&
      mapSettingsRef.current.perspective3D &&
      !flatFallbackActiveRef.current;
    const initialPitch = isNavigating
      ? getEffectiveNavPitch()
      : canIdleTiltInit
      ? getEffectiveIdlePitch()
      : 0;
    const initialPadding = isNavigating
      ? computeLowerThirdPadding(mapContainerRef.current.clientHeight)
      : canIdleTiltInit && isFollowing
      ? computeIdleArrowPadding(mapContainerRef.current.clientHeight)
      : { top: 0, bottom: 0, left: 0, right: 0 };

    followCamTargetZoomRef.current = initialZoom;
    followCamTargetBearingRef.current = 0;
    followCamTargetPitchRef.current = initialPitch;
    followCamTargetPaddingRef.current = initialPadding;
    prevIdlePerspective3DRef.current = mapSettingsRef.current.perspective3D;

    styleFallbackStageRef.current = 'liberty';
    hasVectorSourceLoadedRef.current = false;

    const map = new maplibregl.Map({
      container: mapContainerRef.current,
      style: getStyleForTileMode(mapTileMode, 'liberty'),
      center: [initialLng, initialLat],
      zoom: initialZoom,
      minZoom: isNavigating ? 11 : 12,
      maxZoom: isNavigating ? 19 : 19.5,
      maxPitch: 60,
      pitch: initialPitch,
      bearing: 0,
      attributionControl: false,
      // Limita la densidad de píxeles a 2 para aliviar la GPU en teléfonos de pantalla muy densa
      pixelRatio: Math.min(typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1, 2),
      // Arrastre con inercia más fluida (estilo Waze)
      dragPan: { linearity: 0.3, deceleration: 2200, maxSpeed: 1800 },
      dragRotate: true,
      touchZoomRotate: true,
      touchPitch: isNavigating,
      pitchWithRotate: isNavigating,
    });

    if ((initialPadding.top ?? 0) > 0) {
      try {
        map.setPadding(initialPadding);
      } catch {}
    }

    applyPitchGesturePolicy(map);

    if (initialPitch > 0) {
      verifyPitchedRender(map);
    }

    const triggerOpenFreeMapFallback = () => {
      if (mapTileModeRef.current === 'satellite') return;
      const stage = styleFallbackStageRef.current;
      if (stage === 'osm_raster') return;

      const nextStage: OpenFreeMapFallbackStage = stage === 'liberty' ? 'bright' : 'osm_raster';
      styleFallbackStageRef.current = nextStage;
      hasVectorSourceLoadedRef.current = false;
      isMapStyleReadyRef.current = false;

      if (styleLoadFallbackTimerRef.current) {
        clearTimeout(styleLoadFallbackTimerRef.current);
        styleLoadFallbackTimerRef.current = null;
      }

      try {
        pendingStyleCameraRef.current = {
          center: map.getCenter(),
          zoom: map.getZoom(),
          bearing: map.getBearing(),
          pitch: flatFallbackActiveRef.current ? 0 : map.getPitch(),
          padding: map.getPadding(),
        };
      } catch {}

      if (nextStage === 'osm_raster') {
        setActiveAttributionMode('osm_raster');
      } else {
        setActiveAttributionMode('openfreemap');
        styleLoadFallbackTimerRef.current = setTimeout(() => {
          styleLoadFallbackTimerRef.current = null;
          if (!isMapStyleReadyRef.current || !hasVectorSourceLoadedRef.current) {
            triggerOpenFreeMapFallback();
          }
        }, 6500);
      }

      try {
        map.setStyle(getStyleForTileMode(mapTileModeRef.current, nextStage));
      } catch {
        if (nextStage !== 'osm_raster') {
          styleFallbackStageRef.current = 'osm_raster';
          setActiveAttributionMode('osm_raster');
          try {
            map.setStyle(getStyleForTileMode(mapTileModeRef.current, 'osm_raster'));
          } catch {}
        }
      }
    };

    if (mapTileMode !== 'satellite') {
      styleLoadFallbackTimerRef.current = setTimeout(() => {
        styleLoadFallbackTimerRef.current = null;
        if (!isMapStyleReadyRef.current || !hasVectorSourceLoadedRef.current) {
          triggerOpenFreeMapFallback();
        }
      }, 6500);
    }

    const handleWebGLContextLost = (ev: Event) => {
      ev.preventDefault();
      if (map.getPitch() > 0 || isNavigatingRef.current) {
        activateFlatFallback(map);
      }
    };
    const mapCanvas = map.getCanvas();
    mapCanvas?.addEventListener('webglcontextlost', handleWebGLContextLost);

    map.on('error', (e: any) => {
      const errMsg = e?.error?.message || '';
      const status = e?.error?.status;
      const isStyleOrOpenFreeMapSourceFailure =
        mapTileModeRef.current !== 'satellite' &&
        styleFallbackStageRef.current !== 'osm_raster' &&
        (!isMapStyleReadyRef.current ||
          (e?.sourceId === 'openmaptiles' && !hasVectorSourceLoadedRef.current) ||
          errMsg.includes('openfreemap') ||
          (typeof status === 'number' && status >= 400 && !hasVectorSourceLoadedRef.current));

      if (isStyleOrOpenFreeMapSourceFailure) {
        triggerOpenFreeMapFallback();
        return;
      }

      const isTileOrNetworkAbort =
        e?.sourceId !== undefined ||
        errMsg.includes('Failed to fetch') ||
        errMsg.includes('AJAXError') ||
        errMsg.includes('AbortError');
      if (isTileOrNetworkAbort) {
        // Swallow transient tile network/rate-limit fetch failures so MapLibre does not throw unhandled errors
        return;
      }
      if (map.getPitch() > 0) {
        activateFlatFallback(map);
      }
      console.warn('MapLibre warning:', e?.error || e);
    });

    map.on('sourcedata', (e: any) => {
      if (e?.sourceId === 'openmaptiles' && e?.isSourceLoaded) {
        const wasLoaded = hasVectorSourceLoadedRef.current;
        hasVectorSourceLoadedRef.current = true;
        if (styleLoadFallbackTimerRef.current) {
          clearTimeout(styleLoadFallbackTimerRef.current);
          styleLoadFallbackTimerRef.current = null;
        }
        if (!wasLoaded && !isNavigatingRef.current && userMarkerRef.current) {
          const loc = userLocationRef.current;
          const roadProj = projectArrowOntoRoadSurface(
            map,
            loc.lat,
            loc.lng,
            currentMarkerAngleRef.current,
            speedKmhRef.current >= 2 || currentMarkerAngleRef.current !== 0
          );
          idleRoadSegmentRef.current = roadProj.segment;
          if (roadProj.projected) {
            const [pLat, pLng] = roadProj.point;
            currentMarkerPosRef.current = [pLat, pLng];
            targetMarkerPosRef.current = [pLat, pLng];
            posAnimStartRef.current = [pLat, pLng];
            posAnimEndRef.current = [pLat, pLng];
            userMarkerRef.current.setLngLat([pLng, pLat]);
          }
        }
      }
    });

    map.on('style.load', () => {
      isMapStyleReadyRef.current = true;
      if (mapTileModeRef.current === 'satellite') {
        setActiveAttributionMode('satellite');
        if (styleLoadFallbackTimerRef.current) {
          clearTimeout(styleLoadFallbackTimerRef.current);
          styleLoadFallbackTimerRef.current = null;
        }
      } else if (styleFallbackStageRef.current === 'osm_raster') {
        setActiveAttributionMode('osm_raster');
        if (styleLoadFallbackTimerRef.current) {
          clearTimeout(styleLoadFallbackTimerRef.current);
          styleLoadFallbackTimerRef.current = null;
        }
      } else {
        setActiveAttributionMode('openfreemap');
        if (styleLoadFallbackTimerRef.current) {
          clearTimeout(styleLoadFallbackTimerRef.current);
          styleLoadFallbackTimerRef.current = null;
        }
        // Asegurar respaldo si el estilo JSON cargó pero el origen openmaptiles no entrega datos
        if (!hasVectorSourceLoadedRef.current) {
          styleLoadFallbackTimerRef.current = setTimeout(() => {
            styleLoadFallbackTimerRef.current = null;
            if (!hasVectorSourceLoadedRef.current && mapTileModeRef.current !== 'satellite') {
              triggerOpenFreeMapFallback();
            }
          }, 6500);
        }
      }

      if (pendingStyleCameraRef.current) {
        const preserved = pendingStyleCameraRef.current;
        pendingStyleCameraRef.current = null;
        try {
          beginProgrammaticCameraLock(map, 200);
          map.jumpTo({
            center: preserved.center,
            zoom: preserved.zoom,
            bearing: preserved.bearing,
            pitch: flatFallbackActiveRef.current ? 0 : preserved.pitch,
            padding: preserved.padding,
          });
        } catch {
          activateFlatFallback(map);
        }
      }
      applyWazeStyleEnhancements(map, mapTileModeRef.current);
      syncBuildings3DLayerRef.current(map);
      fixedRadarStripListenersBoundRef.current = false;
      syncRouteDataToMap(map);
      syncPoiGeoJsonSourceRef.current?.(map, true);
      syncFixedRadarsOnMapRef.current?.(map);
      overviewSavedLayersRef.current.clear();
      if (isOverviewActiveRef.current) {
        applyOverviewCleanMapStyle(
          map,
          mapTileModeRef.current,
          overviewSavedLayersRef.current,
          overviewZoomAnchorRef.current
        );
      }

      if (pendingRecenterRef.current) {
        pendingRecenterRef.current = false;
        if (recenterWaitTimerRef.current) {
          clearTimeout(recenterWaitTimerRef.current);
          recenterWaitTimerRef.current = null;
        }
        performAtomicJump();
      }
    });

    map.on('rotate', (e: any) => {
      const currBearing = map.getBearing();
      const signed = (((currBearing % 360) + 540) % 360) - 180;
      const isUserRotate = Boolean(e?.originalEvent);
      if (isUserRotate || isManuallyRotatedRef.current || !isFollowCameraJumpActiveRef.current) {
        setMapRotation(currBearing);
      }
      if (
        isUserRotate ||
        (!isNavigatingRef.current &&
          !isProgrammaticCameraRef.current &&
          !isProgrammaticMoveRef.current)
      ) {
        const rotated = Math.abs(signed) > 1.5;
        if (rotated !== isManuallyRotatedRef.current) {
          isManuallyRotatedRef.current = rotated;
          setIsManuallyRotated(rotated);
        }
      }
    });

    const extractGestureMetrics = (orig: any): { x: number; y: number; pinchDist?: number } | null => {
      if (!orig) return null;
      if (orig.touches && orig.touches.length >= 2) {
        const t0 = orig.touches[0];
        const t1 = orig.touches[1];
        return {
          x: (t0.clientX + t1.clientX) / 2,
          y: (t0.clientY + t1.clientY) / 2,
          pinchDist: Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY),
        };
      }
      if (orig.touches && orig.touches.length === 1) {
        return { x: orig.touches[0].clientX, y: orig.touches[0].clientY };
      }
      if (orig.changedTouches && orig.changedTouches.length >= 1) {
        return { x: orig.changedTouches[0].clientX, y: orig.changedTouches[0].clientY };
      }
      if (typeof orig.clientX === 'number' && typeof orig.clientY === 'number') {
        return { x: orig.clientX, y: orig.clientY };
      }
      return null;
    };

    const cancelIdleFollowImmediately = () => {
      idleGestureStartRef.current = null;
      isIdleAutoOrientActiveRef.current = false;
      idleBearingAnimRef.current.active = false;
      if (idleStopNorthTimerRef.current) {
        clearTimeout(idleStopNorthTimerRef.current);
        idleStopNorthTimerRef.current = null;
      }
      isProgrammaticCameraRef.current = false;
      isProgrammaticMoveRef.current = false;
      pendingRecenterRef.current = false;
      if (programmaticCameraTimerRef.current) {
        clearTimeout(programmaticCameraTimerRef.current);
        programmaticCameraTimerRef.current = null;
      }
      if (programmaticClearTimerRef.current) {
        clearTimeout(programmaticClearTimerRef.current);
        programmaticClearTimerRef.current = null;
      }
      if (recenterWaitTimerRef.current) {
        clearTimeout(recenterWaitTimerRef.current);
        recenterWaitTimerRef.current = null;
      }
      if (isFollowingRef.current) {
        onToggleFollowRef.current(false);
      }
    };

    // Real user input gestures (originalEvent present):
    // - During active navigation: preserved exact behavior (immediate exploration pause)
    // - Before route starts (idle): ignore micro-movements < 10px; upon drag/zoom/rotate disable auto-follow & auto-rotation while keeping 55° pitch untouched
    const handleUserGestureStart = (e: any) => {
      if (!e?.originalEvent) return;

      if (isNavigatingRef.current) {
        if (e.type === 'rotatestart') {
          isManuallyRotatedRef.current = true;
          setIsManuallyRotated(true);
        }
        isProgrammaticMoveRef.current = false;
        isAtomicRecenterInFlightRef.current = false;
        pendingRecenterRef.current = false;
        if (programmaticClearTimerRef.current) {
          clearTimeout(programmaticClearTimerRef.current);
          programmaticClearTimerRef.current = null;
        }
        if (recenterWaitTimerRef.current) {
          clearTimeout(recenterWaitTimerRef.current);
          recenterWaitTimerRef.current = null;
        }
        onUserExplorationGestureRef.current?.();
        return;
      }

      if (isAtomicRecenterInFlightRef.current) return;

      // En selección de ruta, cualquier gesto manual de desplazamiento o zoom bloquea futuros reencuadres automáticos
      if (hasAnyRoutesRef.current) {
        if (e.type === 'rotatestart') {
          return;
        }
        if (e.type === 'zoomstart' && e.originalEvent.type === 'wheel') {
          userInteractedInPreviewRef.current = true;
          if (previewFitDebounceTimerRef.current) {
            clearTimeout(previewFitDebounceTimerRef.current);
            previewFitDebounceTimerRef.current = null;
          }
          if (previewFitInitialRafRef.current !== null) {
            cancelAnimationFrame(previewFitInitialRafRef.current);
            previewFitInitialRafRef.current = null;
          }
          return;
        }
        isIdleUserPointerDownRef.current = true;
        const metrics = extractGestureMetrics(e.originalEvent);
        if (metrics) {
          idleGestureStartRef.current = { ...metrics, zoom: map.getZoom() };
        }
        return;
      }

      if (e.type === 'rotatestart') {
        isManuallyRotatedRef.current = true;
        setIsManuallyRotated(true);
        cancelIdleFollowImmediately();
        return;
      }

      if (e.type === 'zoomstart' && e.originalEvent.type === 'wheel') {
        cancelIdleFollowImmediately();
        return;
      }

      isIdleUserPointerDownRef.current = true;
      const metrics = extractGestureMetrics(e.originalEvent);
      if (metrics) {
        idleGestureStartRef.current = { ...metrics, zoom: map.getZoom() };
      }
    };

    const handleIdleGestureMove = (e: any) => {
      if (isNavigatingRef.current || !e?.originalEvent) return;
      if (isAtomicRecenterInFlightRef.current) return;

      if (hasAnyRoutesRef.current) {
        if (e.type === 'rotate') return;
        if (e.originalEvent.type === 'wheel') {
          userInteractedInPreviewRef.current = true;
          if (previewFitDebounceTimerRef.current) {
            clearTimeout(previewFitDebounceTimerRef.current);
            previewFitDebounceTimerRef.current = null;
          }
          if (previewFitInitialRafRef.current !== null) {
            cancelAnimationFrame(previewFitInitialRafRef.current);
            previewFitInitialRafRef.current = null;
          }
          return;
        }
        const metrics = extractGestureMetrics(e.originalEvent);
        const start = idleGestureStartRef.current;
        if (!start) {
          if (metrics) {
            idleGestureStartRef.current = { ...metrics, zoom: map.getZoom() };
          }
          return;
        }
        const movedPx = metrics ? Math.hypot(metrics.x - start.x, metrics.y - start.y) : 0;
        const pinchDeltaPx =
          metrics?.pinchDist !== undefined && start.pinchDist !== undefined
            ? Math.abs(metrics.pinchDist - start.pinchDist)
            : 0;
        const zoomDelta = Math.abs(map.getZoom() - start.zoom);
        if (movedPx >= 6 || pinchDeltaPx >= 6 || zoomDelta >= 0.03) {
          userInteractedInPreviewRef.current = true;
          if (previewFitDebounceTimerRef.current) {
            clearTimeout(previewFitDebounceTimerRef.current);
            previewFitDebounceTimerRef.current = null;
          }
          if (previewFitInitialRafRef.current !== null) {
            cancelAnimationFrame(previewFitInitialRafRef.current);
            previewFitInitialRafRef.current = null;
          }
        }
        return;
      }

      if (e.originalEvent.type === 'wheel') {
        cancelIdleFollowImmediately();
        return;
      }

      const metrics = extractGestureMetrics(e.originalEvent);
      const start = idleGestureStartRef.current;
      if (!start) {
        if (metrics) {
          idleGestureStartRef.current = { ...metrics, zoom: map.getZoom() };
        }
        return;
      }

      const movedPx = metrics ? Math.hypot(metrics.x - start.x, metrics.y - start.y) : 0;
      const pinchDeltaPx =
        metrics?.pinchDist !== undefined && start.pinchDist !== undefined
          ? Math.abs(metrics.pinchDist - start.pinchDist)
          : 0;
      const zoomDelta = Math.abs(map.getZoom() - start.zoom);

      const signedBearing = (((map.getBearing() % 360) + 540) % 360) - 180;
      if (e.type === 'rotate' && Math.abs(signedBearing) > 1.5) {
        isManuallyRotatedRef.current = true;
        setIsManuallyRotated(true);
        cancelIdleFollowImmediately();
        return;
      }

      if (movedPx >= 10 || pinchDeltaPx >= 10 || zoomDelta >= 0.05) {
        cancelIdleFollowImmediately();
      }
    };

    const handleIdleGestureEnd = (e: any) => {
      if (isNavigatingRef.current) return;
      const remainingTouches = e?.originalEvent?.touches?.length ?? 0;
      if (remainingTouches > 0) return;

      isIdleUserPointerDownRef.current = false;
      idleGestureStartRef.current = null;
    };

    const handleCanvasPointerRelease = (e: TouchEvent | PointerEvent) => {
      if (isNavigatingRef.current) return;
      const touchesRemaining = 'touches' in e ? e.touches.length : 0;
      if (touchesRemaining === 0) {
        isIdleUserPointerDownRef.current = false;
        idleGestureStartRef.current = null;
      }
    };

    map.on('dragstart', handleUserGestureStart);
    map.on('zoomstart', handleUserGestureStart);
    map.on('rotatestart', handleUserGestureStart);

    map.on('drag', handleIdleGestureMove);
    map.on('zoom', handleIdleGestureMove);
    map.on('rotate', handleIdleGestureMove);

    map.on('dragend', handleIdleGestureEnd);
    map.on('zoomend', handleIdleGestureEnd);
    map.on('rotateend', handleIdleGestureEnd);

    // Pausa inmediata de la cámara automática mientras hay un dedo sobre el mapa (todos los modos)
    const handleCanvasTouchStart = () => {
      isUserTouchingMapRef.current = true;
      userTouchStartedAtRef.current = performance.now();
    };
    const handleCanvasTouchEndAny = (e: TouchEvent | PointerEvent) => {
      const touchesRemaining = 'touches' in e ? e.touches.length : 0;
      if (touchesRemaining === 0) {
        isUserTouchingMapRef.current = false;
      }
    };
    const handleWindowBlurTouch = () => {
      isUserTouchingMapRef.current = false;
    };
    mapCanvas?.addEventListener('touchstart', handleCanvasTouchStart, { passive: true });
    mapCanvas?.addEventListener('pointerdown', handleCanvasTouchStart, { passive: true });
    mapCanvas?.addEventListener('touchend', handleCanvasTouchEndAny, { passive: true });
    mapCanvas?.addEventListener('touchcancel', handleCanvasTouchEndAny, { passive: true });
    mapCanvas?.addEventListener('pointerup', handleCanvasTouchEndAny, { passive: true });
    mapCanvas?.addEventListener('pointercancel', handleCanvasTouchEndAny, { passive: true });
    window.addEventListener('blur', handleWindowBlurTouch);
    mapCanvas?.addEventListener('touchend', handleCanvasPointerRelease, { passive: true });
    mapCanvas?.addEventListener('touchcancel', handleCanvasPointerRelease, { passive: true });
    mapCanvas?.addEventListener('pointerup', handleCanvasPointerRelease, { passive: true });
    mapCanvas?.addEventListener('pointercancel', handleCanvasPointerRelease, { passive: true });

    mapInstanceRef.current = map;

    return () => {
      mapCanvas?.removeEventListener('touchstart', handleCanvasTouchStart);
      mapCanvas?.removeEventListener('pointerdown', handleCanvasTouchStart);
      mapCanvas?.removeEventListener('touchend', handleCanvasTouchEndAny);
      mapCanvas?.removeEventListener('touchcancel', handleCanvasTouchEndAny);
      mapCanvas?.removeEventListener('pointerup', handleCanvasTouchEndAny);
      mapCanvas?.removeEventListener('pointercancel', handleCanvasTouchEndAny);
      window.removeEventListener('blur', handleWindowBlurTouch);
      isUserTouchingMapRef.current = false;
      if (previewFitDebounceTimerRef.current) {
        clearTimeout(previewFitDebounceTimerRef.current);
        previewFitDebounceTimerRef.current = null;
      }
      if (previewFitTimeoutRef.current) {
        clearTimeout(previewFitTimeoutRef.current);
        previewFitTimeoutRef.current = null;
      }
      if (previewFitInitialRafRef.current !== null) {
        cancelAnimationFrame(previewFitInitialRafRef.current);
        previewFitInitialRafRef.current = null;
      }
      if (recenterWaitTimerRef.current) {
        clearTimeout(recenterWaitTimerRef.current);
        recenterWaitTimerRef.current = null;
      }
      if (programmaticClearTimerRef.current) {
        clearTimeout(programmaticClearTimerRef.current);
        programmaticClearTimerRef.current = null;
      }
      if (programmaticCameraTimerRef.current) {
        clearTimeout(programmaticCameraTimerRef.current);
        programmaticCameraTimerRef.current = null;
      }
      if (idlePitchLockTimerRef.current) {
        clearTimeout(idlePitchLockTimerRef.current);
        idlePitchLockTimerRef.current = null;
      }
      if (pitchFallbackTimerRef.current) {
        clearTimeout(pitchFallbackTimerRef.current);
        pitchFallbackTimerRef.current = null;
      }
      if (styleLoadFallbackTimerRef.current) {
        clearTimeout(styleLoadFallbackTimerRef.current);
        styleLoadFallbackTimerRef.current = null;
      }
      mapCanvas?.removeEventListener('webglcontextlost', handleWebGLContextLost);
      mapCanvas?.removeEventListener('touchend', handleCanvasPointerRelease);
      mapCanvas?.removeEventListener('touchcancel', handleCanvasPointerRelease);
      mapCanvas?.removeEventListener('pointerup', handleCanvasPointerRelease);
      mapCanvas?.removeEventListener('pointercancel', handleCanvasPointerRelease);
      pendingStyleCameraRef.current = null;
      isProgrammaticMoveRef.current = false;
      isProgrammaticCameraRef.current = false;
      isAtomicRecenterInFlightRef.current = false;
      isIdleUserPointerDownRef.current = false;
      idleGestureStartRef.current = null;
      pendingRecenterRef.current = false;
      isMapStyleReadyRef.current = false;
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // 2. Dynamic resize observer for panel collapse/expand and window resizes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapContainerRef.current) return;

    let resizeRaf: number | null = null;
    const handleResize = () => {
      if (resizeRaf) cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.resize();
        }
      });
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(mapContainerRef.current);
    window.addEventListener('resize', handleResize);
    window.addEventListener('ruta-lima-layout-resize', handleResize);

    return () => {
      if (resizeRaf) cancelAnimationFrame(resizeRaf);
      resizeObserver.disconnect();
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('ruta-lima-layout-resize', handleResize);
    };
  }, []);

  // Resize & smooth camera transition when entering or exiting active navigation
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    setTimeout(() => {
      map.resize();
    }, 60);

    let transitionTimer: ReturnType<typeof setTimeout> | null = null;

    if (!prevNavigatingRef.current && isNavigating) {
      // Entering active navigation: enable 3D tilt (if enabled) & smooth easeTo driving view
      userInteractedInPreviewRef.current = false;
      if (previewFitDebounceTimerRef.current) {
        clearTimeout(previewFitDebounceTimerRef.current);
        previewFitDebounceTimerRef.current = null;
      }
      if (previewFitTimeoutRef.current) {
        clearTimeout(previewFitTimeoutRef.current);
        previewFitTimeoutRef.current = null;
      }
      if (previewFitInitialRafRef.current !== null) {
        cancelAnimationFrame(previewFitInitialRafRef.current);
        previewFitInitialRafRef.current = null;
      }
      if (idlePitchLockTimerRef.current) {
        clearTimeout(idlePitchLockTimerRef.current);
        idlePitchLockTimerRef.current = null;
      }
      applyPitchGesturePolicy(map);

      isManuallyRotatedRef.current = false;
      setIsManuallyRotated(false);
      setIsHeadingUp(mapSettingsRef.current.autoRotation);
      syncRouteDataToMap(map);

      const loc = userLocationRef.current;
      const route = activeRouteRef.current;
      const speed = speedKmhRef.current;
      const distTurn = distanceToNextStepRef.current;

      const validBearing = resolveValidBearing(loc, route, speed);
      const targetBearing = mapSettingsRef.current.autoRotation ? validBearing : 0;
      const targetPitch = getEffectiveNavPitch();
      const targetZoom = calculateSmartZoom(distTurn, speed);
      const targetPadding = getLowerThirdPadding(map);

      let targetLat = loc.lat;
      let targetLng = loc.lng;
      if (route && route.coordinates.length >= 2) {
        const match = matchUserToRoute(loc.lat, loc.lng, loc.heading, route.coordinates);
        targetLat = match.arrowPoint[0];
        targetLng = match.arrowPoint[1];
      }

      followCamTargetZoomRef.current = targetZoom;
      followCamTargetBearingRef.current = targetBearing;
      followCamTargetPitchRef.current = targetPitch;
      followCamTargetPaddingRef.current = targetPadding;
      setMapRotation(targetBearing);
      isProgrammaticMoveRef.current = true;
      beginProgrammaticCameraLock(map, 750);
      try {
        map.easeTo({
          ...(targetLat && targetLng ? { center: [targetLng, targetLat] } : {}),
          zoom: targetZoom,
          bearing: targetBearing,
          pitch: targetPitch,
          padding: targetPadding,
          duration: 700,
        });
        if (targetPitch > 0) {
          verifyPitchedRender(map);
        }
      } catch {
        activateFlatFallback(map);
      }
      transitionTimer = setTimeout(() => {
        isProgrammaticMoveRef.current = false;
      }, 750);
    } else if (prevNavigatingRef.current && !isNavigating) {
      // Ending or cancelling route: vuelve a la vista de seguimiento en pantalla principal (60° si Perspectiva 3D activa, o plana Norte arriba si desactivada)
      isManuallyRotatedRef.current = false;
      setIsManuallyRotated(false);
      idleBearingAnimRef.current.active = false;
      if (idleStopNorthTimerRef.current) {
        clearTimeout(idleStopNorthTimerRef.current);
        idleStopNorthTimerRef.current = null;
      }
      isIdleAutoOrientActiveRef.current = true;
      syncRouteDataToMap(map);

      const useTiltedIdle =
        !hasAnyRoutesRef.current &&
        mapSettingsRef.current.perspective3D &&
        !flatFallbackActiveRef.current;
      const currLat = userLocationRef.current.lat;
      const currLng = userLocationRef.current.lng;
      const targetPitch = useTiltedIdle ? getEffectiveIdlePitch() : 0;
      const targetPadding = useTiltedIdle
        ? computeIdleArrowPadding(map.getContainer().clientHeight)
        : { top: 0, bottom: 0, left: 0, right: 0 };
      const targetBearing = useTiltedIdle
        ? resolveIdleTrackingBearing(userLocationRef.current, speedKmhRef.current)
        : 0;

      applyPitchGesturePolicy(map, { unlockingForTransition: true });

      const idleRecenterZoom = calculateIdleZoom(speedKmhRef.current);
      followCamTargetZoomRef.current = idleRecenterZoom;
      followCamTargetBearingRef.current = targetBearing;
      followCamTargetPitchRef.current = targetPitch;
      followCamTargetPaddingRef.current = targetPadding;
      setMapRotation(targetBearing);

      isProgrammaticMoveRef.current = true;
      beginProgrammaticCameraLock(map, 700);
      try {
        map.easeTo({
          ...(currLat && currLng ? { center: [currLng, currLat] } : {}),
          zoom: idleRecenterZoom,
          bearing: targetBearing,
          pitch: targetPitch,
          padding: targetPadding,
          duration: 650,
          essential: true,
        });
        if (targetPitch > 0) {
          verifyPitchedRender(map);
        }
      } catch {
        activateFlatFallback(map);
      }
      transitionTimer = setTimeout(() => {
        isProgrammaticMoveRef.current = false;
        applyPitchGesturePolicy(map);
      }, 700);
    }
    prevNavigatingRef.current = isNavigating;

    return () => {
      if (transitionTimer) clearTimeout(transitionTimer);
    };
  }, [
    isNavigating,
    syncRouteDataToMap,
    resolveValidBearing,
    resolveIdleTrackingBearing,
    getEffectiveNavPitch,
    getEffectiveIdlePitch,
    calculateSmartZoom,
    calculateIdleZoom,
    getLowerThirdPadding,
    computeIdleArrowPadding,
    beginProgrammaticCameraLock,
    verifyPitchedRender,
    activateFlatFallback,
    applyPitchGesturePolicy,
  ]);

  // Ensure full canvas sizing whenever follow mode changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    map.resize();
  }, [isFollowing]);

  // 3. Switch Map Style on Tile Mode change (Day / Night / Satellite), preserving exact pitch, bearing, zoom & center
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    if (prevTileModeRef.current === mapTileMode) return;
    const prevMode = prevTileModeRef.current;
    prevTileModeRef.current = mapTileMode;

    // Si cambiamos entre Día y Noche sobre OpenFreeMap ya cargado, oscurecemos/aclaramos por código al instante sin recargar el estilo
    if (
      prevMode !== 'satellite' &&
      mapTileMode !== 'satellite' &&
      styleFallbackStageRef.current !== 'osm_raster' &&
      isMapStyleReadyForSources(map)
    ) {
      applyWazeStyleEnhancements(map, mapTileMode);
      syncBuildings3DLayer(map);
      syncRouteDataToMap(map);
      syncPoiGeoJsonSourceRef.current?.(map, true);
      syncFixedRadarsOnMapRef.current?.(map);
      if (isOverviewActiveRef.current) {
        overviewSavedLayersRef.current.clear();
        applyOverviewCleanMapStyle(
          map,
          mapTileMode,
          overviewSavedLayersRef.current,
          overviewZoomAnchorRef.current
        );
      }
      return;
    }

    const preservedCamera = {
      center: map.getCenter(),
      zoom: map.getZoom(),
      bearing: map.getBearing(),
      pitch: flatFallbackActiveRef.current ? 0 : map.getPitch(),
      padding: map.getPadding(),
    };
    pendingStyleCameraRef.current = preservedCamera;

    if (mapTileMode !== 'satellite' && prevMode === 'satellite') {
      styleFallbackStageRef.current = 'liberty';
      hasVectorSourceLoadedRef.current = false;
    }

    isMapStyleReadyRef.current = false;
    map.setStyle(getStyleForTileMode(mapTileMode, styleFallbackStageRef.current));
    try {
      beginProgrammaticCameraLock(map, 200);
      map.jumpTo(preservedCamera);
    } catch {}
  }, [mapTileMode, beginProgrammaticCameraLock, syncBuildings3DLayer, syncRouteDataToMap]);

  // Sync 3D buildings visibility whenever setting or overview state changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    syncBuildings3DLayer(map);
  }, [mapSettings.buildings3D, isOverviewActive, syncBuildings3DLayer]);

  // 4. Smooth 60 FPS Linear Position, 1.5s Anticipation, Route Projection, Rotation & Camera Sync
  useEffect(() => {
    const MAX_EXTRAPOLATION_MS = 1500;
    const ROT_ANIM_DURATION_MS = 300;

    if (animFrameIdRef.current !== null) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        wasPageHiddenRef.current = true;
      } else if (document.visibilityState === 'visible' && wasPageHiddenRef.current) {
        wasPageHiddenRef.current = false;
        snapOnNextFixRef.current = true;
        lastGpsFixPerfTimeRef.current = null;
        isVehicleMovingRef.current = false;

        const [tLat, tLng] = targetMarkerPosRef.current;
        const tAngle = targetMarkerAngleRef.current;
        posAnimStartRef.current = [tLat, tLng];
        posAnimEndRef.current = [tLat, tLng];
        posAnimStartTimeRef.current = performance.now();
        currentMarkerPosRef.current = [tLat, tLng];

        rotAnimStartAngleRef.current = tAngle;
        rotAnimDeltaDegRef.current = 0;
        committedTargetAngleRef.current = tAngle;
        currentMarkerAngleRef.current = tAngle;

        if (userMarkerRef.current) {
          userMarkerRef.current.setLngLat([tLng, tLat]);
          userMarkerRef.current.setRotation(tAngle);
        }

        cameraNeedsImmediateSnapRef.current = true;
        lastAnimTimeRef.current = performance.now();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    const animateMarker = (now: number) => {
      const dt = Math.min(Math.max(0.001, (now - lastAnimTimeRef.current) / 1000), 0.1);
      lastAnimTimeRef.current = now;

      if (document.visibilityState === 'hidden') {
        animFrameIdRef.current = requestAnimationFrame(animateMarker);
        return;
      }

      const marker = userMarkerRef.current;
      let positionUpdatedThisFrame = false;

      if (marker) {
        // A. Linear interpolation between last two fixes + max 1.5s dead-reckoning anticipation
        if (isVehicleMovingRef.current) {
          const duration = Math.max(200, posAnimDurationRef.current);
          const elapsed = Math.max(0, now - posAnimStartTimeRef.current);
          let rawLat: number;
          let rawLng: number;

          if (elapsed <= duration) {
            const t = elapsed / duration;
            const [sLat, sLng] = posAnimStartRef.current;
            const [eLat, eLng] = posAnimEndRef.current;
            rawLat = sLat + (eLat - sLat) * t;
            rawLng = sLng + (eLng - sLng) * t;
          } else {
            const overtimeMs = Math.min(elapsed - duration, MAX_EXTRAPOLATION_MS);
            const [eLat, eLng] = posAnimEndRef.current;
            const extraDistMeters = Math.max(0, velocityMpsRef.current) * (overtimeMs / 1000);
            [rawLat, rawLng] = offsetCoordByMeters(
              eLat,
              eLng,
              extraDistMeters,
              velocityBearingRef.current
            );

            if (elapsed - duration >= MAX_EXTRAPOLATION_MS) {
              // Stop extrapolating cleanly once the 1.5s limit is reached
              isVehicleMovingRef.current = false;
              posAnimStartRef.current = [rawLat, rawLng];
              posAnimEndRef.current = [rawLat, rawLng];
            }
          }

          let finalLat = rawLat;
          let finalLng = rawLng;

          // Keep arrow projected onto active route polyline while on-route (even around bends)
          const route = activeRouteRef.current;
          if (
            isNavigatingRef.current &&
            isSnappedToRouteRef.current &&
            route &&
            route.coordinates.length >= 2
          ) {
            const proj = projectPointOntoRoutePolyline(
              rawLat,
              rawLng,
              route.coordinates,
              snappedSegmentIdxRef.current
            );
            snappedSegmentIdxRef.current = proj.segmentIndex;
            finalLat = proj.point[0];
            finalLng = proj.point[1];
            if (elapsed > duration) {
              velocityBearingRef.current = proj.segmentBearing;
            }
          } else if (!isNavigatingRef.current && idleRoadSegmentRef.current) {
            [finalLat, finalLng] = clampPointToRoadSegment(
              rawLat,
              rawLng,
              idleRoadSegmentRef.current
            );
          }

          const [prevLat, prevLng] = currentMarkerPosRef.current;
          if (
            Math.abs(finalLat - prevLat) > 1e-8 ||
            Math.abs(finalLng - prevLng) > 1e-8
          ) {
            currentMarkerPosRef.current = [finalLat, finalLng];
            marker.setLngLat([finalLng, finalLat]);
            positionUpdatedThisFrame = true;
          }
        }

        // B. Smooth shortest-arc rotation (~300 ms, zero 360° wrap jump)
        if (Math.abs(rotAnimDeltaDegRef.current) > 0.01) {
          const rotElapsed = Math.max(0, now - rotAnimStartTimeRef.current);
          const rotT = Math.min(1, rotElapsed / ROT_ANIM_DURATION_MS);
          const nextAngle = normalizeHeadingDeg(
            rotAnimStartAngleRef.current + rotAnimDeltaDegRef.current * rotT
          );
          currentMarkerAngleRef.current = nextAngle;
          marker.setRotation(nextAngle);
          if (rotT >= 1) {
            rotAnimDeltaDegRef.current = 0;
          }
        }
      }

      // C. Synced follow camera moving strictly with the exact same interpolated arrow coordinates
      const map = mapInstanceRef.current;
      const isAutoFollowAllowed = Boolean(
        isFollowingRef.current &&
          (isNavigatingRef.current || !hasAnyRoutesRef.current) &&
          !isProgrammaticMoveRef.current &&
          !isAtomicRecenterInFlightRef.current &&
          !pendingRecenterRef.current &&
          !isOverviewActiveRef.current &&
          !isPickingRadarLocationRef.current &&
          (!isIdleUserPointerDownRef.current || isNavigatingRef.current) &&
          !(
            isUserTouchingMapRef.current &&
            performance.now() - userTouchStartedAtRef.current < 20000
          )
      );

      if (map && isAutoFollowAllowed) {
        const [camLat, camLng] = currentMarkerPosRef.current;
        const tgtZoom = followCamTargetZoomRef.current;
        const tgtBearing = followCamTargetBearingRef.current;
        const tgtPitch = followCamTargetPitchRef.current;
        const tgtPadding = followCamTargetPaddingRef.current;

        if (cameraNeedsImmediateSnapRef.current) {
          cameraNeedsImmediateSnapRef.current = false;
          isProgrammaticCameraRef.current = true;
          isFollowCameraJumpActiveRef.current = true;
          try {
            map.jumpTo({
              center: [camLng, camLat],
              zoom: tgtZoom,
              bearing: tgtBearing,
              pitch: tgtPitch,
              padding: tgtPadding,
            });
            if (tgtPitch > 0) {
              verifyPitchedRender(map);
            }
          } catch {
            activateFlatFallback(map);
          } finally {
            isFollowCameraJumpActiveRef.current = false;
            isProgrammaticCameraRef.current = false;
          }
        } else {
          const curCenter = map.getCenter();
          const curZoom = map.getZoom();
          const curBearing = map.getBearing();
          const curPitch = map.getPitch();
          const curPadding = map.getPadding();
          const curPadTop = typeof curPadding?.top === 'number' ? curPadding.top : 0;
          const tgtPadTop = typeof tgtPadding?.top === 'number' ? tgtPadding.top : 0;

          const centerNeedsUpdate =
            positionUpdatedThisFrame ||
            Math.abs(curCenter.lat - camLat) > 1e-6 ||
            Math.abs(curCenter.lng - camLng) > 1e-6;
          const zoomDiff = tgtZoom - curZoom;
          const bearingDiff = shortestAngleDiffDeg(curBearing, tgtBearing);
          const pitchDiff = tgtPitch - curPitch;
          const padTopDiff = tgtPadTop - curPadTop;
          const isIdleBearingAnimActive = Boolean(
            !isNavigatingRef.current &&
              !hasAnyRoutesRef.current &&
              idleBearingAnimRef.current.active
          );

          const cameraNeedsAdjust =
            centerNeedsUpdate ||
            isIdleBearingAnimActive ||
            Math.abs(zoomDiff) > 0.003 ||
            Math.abs(bearingDiff) > 0.08 ||
            Math.abs(pitchDiff) > 0.08 ||
            Math.abs(padTopDiff) > 0.5;

          if (cameraNeedsAdjust) {
            const camFactor = 1 - Math.exp(-8 * dt);
            const rotCamFactor = 1 - Math.exp(-10 * dt);
            const zoomCamFactor = 1 - Math.exp(-3 * dt);
            const nextZoom = Math.abs(zoomDiff) > 0.003 ? curZoom + zoomDiff * zoomCamFactor : tgtZoom;
            let nextBearing: number;
            if (isIdleBearingAnimActive) {
              const anim = idleBearingAnimRef.current;
              const t = Math.min(1, Math.max(0, (now - anim.startTime) / anim.durationMs));
              const eased = 1 - Math.pow(1 - t, 3);
              const totalDelta = shortestAngleDiffDeg(anim.startBearing, anim.targetBearing);
              nextBearing = normalizeHeadingDeg(anim.startBearing + totalDelta * eased);
              if (t >= 1) {
                anim.active = false;
                nextBearing = anim.targetBearing;
              }
            } else {
              nextBearing =
                Math.abs(bearingDiff) > 0.08
                  ? curBearing + bearingDiff * rotCamFactor
                  : tgtBearing;
            }
            const nextPitch =
              Math.abs(pitchDiff) > 0.08 ? curPitch + pitchDiff * camFactor : tgtPitch;
            const nextPadTop =
              Math.abs(padTopDiff) > 0.5 ? curPadTop + padTopDiff * camFactor : tgtPadTop;

            isProgrammaticCameraRef.current = true;
            isFollowCameraJumpActiveRef.current = true;
            try {
              map.jumpTo({
                center: [camLng, camLat],
                zoom: nextZoom,
                bearing: nextBearing,
                pitch: nextPitch,
                padding: { ...tgtPadding, top: nextPadTop },
              });
            } catch {
              activateFlatFallback(map);
            } finally {
              isFollowCameraJumpActiveRef.current = false;
              isProgrammaticCameraRef.current = false;
            }
          }
        }
      }

      animFrameIdRef.current = requestAnimationFrame(animateMarker);
    };

    lastAnimTimeRef.current = performance.now();
    animFrameIdRef.current = requestAnimationFrame(animateMarker);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (animFrameIdRef.current !== null) {
        cancelAnimationFrame(animFrameIdRef.current);
        animFrameIdRef.current = null;
      }
    };
  }, [activateFlatFallback, verifyPitchedRender]);

  // Escucha pasiva de la brújula del celular (solo apoyo cuando GPS en movimiento > 5 km/h no entregue rumbo)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const handleOrientation = (e: DeviceOrientationEvent) => {
      try {
        const webkitHeading = (e as any).webkitCompassHeading;
        let heading: number | null = null;
        if (typeof webkitHeading === 'number' && Number.isFinite(webkitHeading)) {
          heading = webkitHeading;
        } else if (
          (e.absolute === true || e.type === 'deviceorientationabsolute') &&
          typeof e.alpha === 'number' &&
          Number.isFinite(e.alpha)
        ) {
          const screenAngle =
            typeof window.screen?.orientation?.angle === 'number'
              ? window.screen.orientation.angle
              : 0;
          heading = 360 - e.alpha + screenAngle;
        }
        if (heading !== null) {
          compassHeadingRef.current = normalizeHeadingDeg(heading);
        }
      } catch {}
    };

    window.addEventListener('deviceorientationabsolute', handleOrientation as EventListener, true);
    window.addEventListener('deviceorientation', handleOrientation as EventListener, true);
    return () => {
      window.removeEventListener('deviceorientationabsolute', handleOrientation as EventListener, true);
      window.removeEventListener('deviceorientation', handleOrientation as EventListener, true);
    };
  }, []);

  // Restaurar vista inclinada al cancelar vista previa y volver a la pantalla principal sin ruta
  useEffect(() => {
    const map = mapInstanceRef.current;
    const hasRoute = Boolean(activeRoute || routes.length > 0);
    if (!isNavigating) {
      if (!prevHasActiveRouteRef.current && hasRoute && map) {
        applyPitchGesturePolicy(map, { unlockingForTransition: true });
      } else if (prevHasActiveRouteRef.current && !hasRoute) {
        idleCommittedHeadingRef.current = null;
        idleBearingAnimRef.current.active = false;
        if (idleStopNorthTimerRef.current) {
          clearTimeout(idleStopNorthTimerRef.current);
          idleStopNorthTimerRef.current = null;
        }
        isIdleAutoOrientActiveRef.current = true;
        returnToIdleTrackingView(500);
      }
    }
    prevHasActiveRouteRef.current = hasRoute;
  }, [activeRoute, routes.length, isNavigating, applyPitchGesturePolicy, returnToIdleTrackingView]);

  // Sincronizar política de inclinación y cambio del interruptor "Perspectiva 3D" en pantalla principal
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const perspectiveChanged = prevIdlePerspective3DRef.current !== mapSettings.perspective3D;
    prevIdlePerspective3DRef.current = mapSettings.perspective3D;

    if (
      perspectiveChanged &&
      !isNavigatingRef.current &&
      !hasAnyRoutesRef.current &&
      !isOverviewActiveRef.current
    ) {
      if (idlePitchLockTimerRef.current) {
        clearTimeout(idlePitchLockTimerRef.current);
        idlePitchLockTimerRef.current = null;
      }

      if (!mapSettings.perspective3D) {
        applyPitchGesturePolicy(map, { unlockingForTransition: true });
        isManuallyRotatedRef.current = false;
        setIsManuallyRotated(false);
        setMapRotation(0);
        isIdleAutoOrientActiveRef.current = true;
        idleBearingAnimRef.current.active = false;
        followCamTargetPitchRef.current = 0;
        followCamTargetBearingRef.current = 0;
        followCamTargetPaddingRef.current = { top: 0, bottom: 0, left: 0, right: 0 };
        isProgrammaticMoveRef.current = true;
        beginProgrammaticCameraLock(map, 450);
        try {
          map.easeTo({
            pitch: 0,
            bearing: 0,
            padding: { top: 0, bottom: 0, left: 0, right: 0 },
            duration: 400,
            essential: true,
          });
        } catch {
          activateFlatFallback(map);
        }
        idlePitchLockTimerRef.current = setTimeout(() => {
          idlePitchLockTimerRef.current = null;
          isProgrammaticMoveRef.current = false;
          applyPitchGesturePolicy(map);
        }, 430);
      } else if (!flatFallbackActiveRef.current) {
        if (isFollowingRef.current && !isPickingRadarLocationRef.current) {
          returnToIdleTrackingView(500);
        } else {
          const targetPitch = getEffectiveIdlePitch();
          applyPitchGesturePolicy(map, { unlockingForTransition: true });
          followCamTargetPitchRef.current = targetPitch;
          isProgrammaticMoveRef.current = true;
          beginProgrammaticCameraLock(map, 450);
          try {
            map.easeTo({
              pitch: targetPitch,
              duration: 400,
              essential: true,
            });
            verifyPitchedRender(map);
          } catch {
            activateFlatFallback(map);
          }
          idlePitchLockTimerRef.current = setTimeout(() => {
            idlePitchLockTimerRef.current = null;
            isProgrammaticMoveRef.current = false;
            applyPitchGesturePolicy(map);
          }, 430);
        }
      }
      return;
    }

    if (!isProgrammaticMoveRef.current) {
      applyPitchGesturePolicy(map);
    }
  }, [
    isNavigating,
    mapSettings.perspective3D,
    isOverviewActive,
    applyPitchGesturePolicy,
    beginProgrammaticCameraLock,
    activateFlatFallback,
    returnToIdleTrackingView,
    getEffectiveIdlePitch,
    verifyPitchedRender,
  ]);

  useEffect(() => {
    return () => {
      if (idleStopNorthTimerRef.current) {
        clearTimeout(idleStopNorthTimerRef.current);
        idleStopNorthTimerRef.current = null;
      }
    };
  }, []);

  // 5. Target State Calculation, Snap-to-Road, Remaining Route Trim & Camera Target Sync
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const nowPerf = performance.now();
    const validBearing = resolveValidBearing(userLocation, activeRoute, speedKmh);

    // Sync follow camera targets continuously when follow / route / zoom inputs update
    const hasPendingTrigger =
      (recenterTrigger && recenterTrigger !== lastHandledRecenterTriggerRef.current) ||
      (overviewTrigger && overviewTrigger !== lastHandledOverviewTriggerRef.current);

    // Registro de desplazamiento en pantalla principal sin ruta para calcular rumbo de movimiento si hace falta
    const prevIdlePos = prevIdleGpsPosRef.current;
    let movedBearingFromGps: number | null = null;
    if (prevIdlePos) {
      const movedDist = getDistanceMeters(
        prevIdlePos.lat,
        prevIdlePos.lng,
        userLocation.lat,
        userLocation.lng
      );
      if (movedDist >= 2.5) {
        const b = getBearing(prevIdlePos.lat, prevIdlePos.lng, userLocation.lat, userLocation.lng);
        if (Number.isFinite(b)) {
          movedBearingFromGps = normalizeHeadingDeg(b);
        }
        prevIdleGpsPosRef.current = { lat: userLocation.lat, lng: userLocation.lng };
      }
    } else {
      prevIdleGpsPosRef.current = { lat: userLocation.lat, lng: userLocation.lng };
    }

    if (
      isFollowing &&
      (isNavigating || !hasAnyRoutesRef.current) &&
      !isProgrammaticMoveRef.current &&
      !isAtomicRecenterInFlightRef.current &&
      !pendingRecenterRef.current &&
      !hasPendingTrigger &&
      (!isIdleUserPointerDownRef.current || isNavigating) &&
      !(
        isUserTouchingMapRef.current &&
        performance.now() - userTouchStartedAtRef.current < 20000
      )
    ) {
      const targetZoom = isNavigating
        ? calculateSmartZoom(distanceToNextStep, speedKmh)
        : calculateIdleZoom(speedKmh);
      let targetBearing =
        isNavigating && mapSettings.autoRotation && isHeadingUp ? validBearing : 0;

      // Orientación automática e inclinación en pantalla principal sin ruta activa
      if (!isNavigating && !hasAnyRoutesRef.current) {
        if (
          mapSettings.perspective3D &&
          !flatFallbackActiveRef.current &&
          mapSettings.autoRotation &&
          isIdleAutoOrientActiveRef.current
        ) {
          if (speedKmh > 5) {
            if (idleStopNorthTimerRef.current) {
              clearTimeout(idleStopNorthTimerRef.current);
              idleStopNorthTimerRef.current = null;
            }

            let candidateHeading: number | null = null;
            if (movedBearingFromGps !== null) {
              candidateHeading = movedBearingFromGps;
            } else if (
              userLocation.heading !== null &&
              userLocation.heading !== undefined &&
              Number.isFinite(userLocation.heading) &&
              userLocation.heading !== 0
            ) {
              candidateHeading = normalizeHeadingDeg(userLocation.heading);
            } else if (compassHeadingRef.current !== null) {
              // Brújula del celular solo como apoyo si el GPS no entrega rumbo en movimiento > 5 km/h
              candidateHeading = compassHeadingRef.current;
            }

            if (candidateHeading !== null) {
              if (
                idleCommittedHeadingRef.current === null ||
                Math.abs(shortestAngleDiffDeg(idleCommittedHeadingRef.current, candidateHeading)) >= 10
              ) {
                idleCommittedHeadingRef.current = candidateHeading;
              }
            }
          }
          // Si está detenido o < 5 km/h, mantiene la última orientación sin girar
          targetBearing = idleCommittedHeadingRef.current ?? 0;

          if (
            Math.abs(shortestAngleDiffDeg(followCamTargetBearingRef.current, targetBearing)) >= 0.5
          ) {
            idleBearingAnimRef.current = {
              active: true,
              startBearing: map.getBearing(),
              targetBearing,
              startTime: performance.now(),
              durationMs: 400,
            };
          }
        } else {
          idleBearingAnimRef.current.active = false;
          targetBearing = 0;
        }
      }

      const targetPitch = isNavigating
        ? getEffectiveNavPitch()
        : !hasAnyRoutesRef.current && mapSettings.perspective3D && !flatFallbackActiveRef.current
        ? getEffectiveIdlePitch()
        : 0;
      const targetPadding = getLowerThirdPadding(map);

      followCamTargetZoomRef.current = targetZoom;
      followCamTargetBearingRef.current = targetBearing;
      followCamTargetPitchRef.current = targetPitch;
      followCamTargetPaddingRef.current = targetPadding;

      if (!isManuallyRotatedRef.current) {
        setMapRotation(targetBearing);
      }
    }

    const fixSignature = `${userLocation.lat.toFixed(7)},${userLocation.lng.toFixed(7)},${
      userLocation.timestamp || 0
    },${isNavigating ? 1 : 0},${activeRoute?.id || ''}`;
    const isNewPositionEvent = fixSignature !== lastProcessedFixSignatureRef.current;

    if (isNewPositionEvent) {
      lastProcessedFixSignatureRef.current = fixSignature;

      let targetLat = userLocation.lat;
      let targetLng = userLocation.lng;
      let targetArrowBearing = normalizeHeadingDeg(validBearing);
      let snappedToRoute = false;

      const rawSpeedKmh =
        userLocation.speed !== null &&
        userLocation.speed !== undefined &&
        Number.isFinite(userLocation.speed)
          ? userLocation.speed * 3.6
          : speedKmh;

      if (isNavigating && activeRoute && activeRoute.coordinates.length >= 2) {
        idleRoadSegmentRef.current = null;
        const match = matchUserToRoute(
          userLocation.lat,
          userLocation.lng,
          userLocation.heading,
          activeRoute.coordinates
        );

        targetLat = match.arrowPoint[0];
        targetLng = match.arrowPoint[1];
        targetArrowBearing = Number.isFinite(match.arrowBearing)
          ? normalizeHeadingDeg(match.arrowBearing)
          : targetArrowBearing;
        snappedToRoute = match.isSnapped;

        // Update remaining active route trimmed cleanly from the arrow's closest route point
        if (isMapStyleReadyRef.current && isMapStyleReadyForSources(map)) {
          const activeSrc = map.getSource(ACTIVE_ROUTE_SOURCE_ID) as
            | maplibregl.GeoJSONSource
            | undefined;
          if (activeSrc) {
            const coordsToDraw =
              match.remainingCoords.length >= 2 ? match.remainingCoords : activeRoute.coordinates;
            activeSrc.setData({
              type: 'FeatureCollection',
              features: [
                {
                  type: 'Feature',
                  properties: {},
                  geometry: {
                    type: 'LineString',
                    coordinates: coordsToLngLat(coordsToDraw),
                  },
                },
              ],
            });
          }
        }
      } else if (!isNavigating) {
        // Orientación fiel al movimiento/dirección real en pantalla principal antes de iniciar ruta
        const hasMovingGpsHeading =
          userLocation.heading !== null &&
          userLocation.heading !== undefined &&
          Number.isFinite(userLocation.heading) &&
          (rawSpeedKmh >= 2 ||
            movedBearingFromGps !== null ||
            (lastValidHeadingRef.current === 0 && userLocation.heading !== 0));

        if (movedBearingFromGps !== null) {
          targetArrowBearing = movedBearingFromGps;
          lastValidHeadingRef.current = movedBearingFromGps;
        } else if (hasMovingGpsHeading) {
          targetArrowBearing = normalizeHeadingDeg(userLocation.heading as number);
          lastValidHeadingRef.current = targetArrowBearing;
        } else if (idleCommittedHeadingRef.current !== null) {
          targetArrowBearing = idleCommittedHeadingRef.current;
        } else if (compassHeadingRef.current !== null && rawSpeedKmh >= 1.5) {
          targetArrowBearing = compassHeadingRef.current;
        }

        // Proyección visual sobre la calzada sin alterar coordenadas GPS reales ni forzar al centro
        const roadProj = projectArrowOntoRoadSurface(
          map,
          userLocation.lat,
          userLocation.lng,
          targetArrowBearing,
          Boolean(rawSpeedKmh >= 2 || movedBearingFromGps !== null || targetArrowBearing !== 0)
        );
        targetLat = roadProj.point[0];
        targetLng = roadProj.point[1];
        idleRoadSegmentRef.current = roadProj.segment;
      }

      isSnappedToRouteRef.current = snappedToRoute;
      if (snappedToRoute && activeRoute && activeRoute.coordinates.length >= 2) {
        const segProj = projectPointOntoRoutePolyline(
          targetLat,
          targetLng,
          activeRoute.coordinates,
          snappedSegmentIdxRef.current
        );
        snappedSegmentIdxRef.current = segProj.segmentIndex;
      } else {
        snappedSegmentIdxRef.current = 0;
      }

      const [curLat, curLng] = currentMarkerPosRef.current;
      const jumpMeters = getDistanceMeters(curLat, curLng, targetLat, targetLng);

      const shouldSnapDirectly =
        !hasInitializedArrowRef.current || snapOnNextFixRef.current || jumpMeters > 50;

      if (shouldSnapDirectly) {
        snapOnNextFixRef.current = false;
        hasInitializedArrowRef.current = true;
        targetMarkerPosRef.current = [targetLat, targetLng];
        currentMarkerPosRef.current = [targetLat, targetLng];
        posAnimStartRef.current = [targetLat, targetLng];
        posAnimEndRef.current = [targetLat, targetLng];
        posAnimStartTimeRef.current = nowPerf;
        posAnimDurationRef.current = 1000;
        lastGpsFixPerfTimeRef.current = nowPerf;
        isVehicleMovingRef.current = false;
        velocityMpsRef.current = Math.max(0, rawSpeedKmh / 3.6);
        velocityBearingRef.current = targetArrowBearing;

        committedTargetAngleRef.current = targetArrowBearing;
        targetMarkerAngleRef.current = targetArrowBearing;
        currentMarkerAngleRef.current = targetArrowBearing;
        rotAnimStartAngleRef.current = targetArrowBearing;
        rotAnimDeltaDegRef.current = 0;

        if (userMarkerRef.current) {
          userMarkerRef.current.setLngLat([targetLng, targetLat]);
          userMarkerRef.current.setRotation(targetArrowBearing);
        }
        cameraNeedsImmediateSnapRef.current = true;
      } else if (rawSpeedKmh < 2) {
        if (!isNavigating && jumpMeters >= 1.5) {
          // Desplazamiento real lento o lateral dentro de la calzada: acompañar sin congelar
          targetMarkerPosRef.current = [targetLat, targetLng];
          posAnimStartRef.current = [curLat, curLng];
          posAnimEndRef.current = [targetLat, targetLng];
          posAnimStartTimeRef.current = nowPerf;
          posAnimDurationRef.current = 600;
          lastGpsFixPerfTimeRef.current = nowPerf;
          isVehicleMovingRef.current = true;
          velocityMpsRef.current = 0;
          velocityBearingRef.current = targetArrowBearing;
        } else {
          // Detenido sin desplazamiento real (< 1.5m): evitar temblor GPS
          isVehicleMovingRef.current = false;
          velocityMpsRef.current = 0;
          lastGpsFixPerfTimeRef.current = null;
          posAnimStartRef.current = [...currentMarkerPosRef.current];
          posAnimEndRef.current = [...currentMarkerPosRef.current];
          targetMarkerPosRef.current = [...currentMarkerPosRef.current];
        }

        if (!isNavigating) {
          const headingDelta = shortestAngleDiffDeg(
            committedTargetAngleRef.current,
            targetArrowBearing
          );
          if (Math.abs(headingDelta) >= (jumpMeters >= 1.5 ? 5 : 8)) {
            committedTargetAngleRef.current = targetArrowBearing;
            targetMarkerAngleRef.current = targetArrowBearing;
            rotAnimStartAngleRef.current = currentMarkerAngleRef.current;
            rotAnimDeltaDegRef.current = shortestAngleDiffDeg(
              currentMarkerAngleRef.current,
              targetArrowBearing
            );
            rotAnimStartTimeRef.current = nowPerf;
          }
        }
      } else {
        // Normal moving update: linear interpolation over elapsed inter-fix interval (~1000 ms)
        let intervalMs = 1000;
        if (lastGpsFixPerfTimeRef.current !== null) {
          const measuredMs = nowPerf - lastGpsFixPerfTimeRef.current;
          if (measuredMs >= 200 && measuredMs <= 2500) {
            intervalMs = Math.max(250, Math.min(2000, measuredMs));
          }
        }
        lastGpsFixPerfTimeRef.current = nowPerf;

        targetMarkerPosRef.current = [targetLat, targetLng];
        posAnimStartRef.current = [curLat, curLng];
        posAnimEndRef.current = [targetLat, targetLng];
        posAnimStartTimeRef.current = nowPerf;
        posAnimDurationRef.current = intervalMs;
        isVehicleMovingRef.current = true;

        const segSpeedMps = jumpMeters > 0.3 ? jumpMeters / (intervalMs / 1000) : rawSpeedKmh / 3.6;
        velocityMpsRef.current = rawSpeedKmh >= 2 ? rawSpeedKmh / 3.6 : segSpeedMps;
        velocityBearingRef.current = targetArrowBearing;

        // Smooth rotation (~300 ms) along shortest angular arc, ignoring < 5° heading noise
        const headingDelta = shortestAngleDiffDeg(
          committedTargetAngleRef.current,
          targetArrowBearing
        );
        if (Math.abs(headingDelta) >= 5) {
          committedTargetAngleRef.current = targetArrowBearing;
          targetMarkerAngleRef.current = targetArrowBearing;
          rotAnimStartAngleRef.current = currentMarkerAngleRef.current;
          rotAnimDeltaDegRef.current = shortestAngleDiffDeg(
            currentMarkerAngleRef.current,
            targetArrowBearing
          );
          rotAnimStartTimeRef.current = nowPerf;
        }
      }
    }

    // Create or swap marker element only when navigating / preview / idle mode changes
    const isPreviewMode = !isNavigating && (routes.length > 0 || Boolean(activeRoute));
    const desiredIconKey = isNavigating
      ? 'nav_waze'
      : isPreviewMode
      ? 'preview_dot'
      : 'idle_waze';
    if (!userMarkerRef.current || currentIconModeRef.current !== desiredIconKey) {
      currentIconModeRef.current = desiredIconKey;

      if (userMarkerRef.current) {
        userMarkerRef.current.remove();
        userMarkerRef.current = null;
      }

      const el = document.createElement('div');
      el.className = 'vehicle-nav-marker pointer-events-none select-none';
      el.style.width = isNavigating ? '60px' : isPreviewMode ? '36px' : '84px';
      el.style.height = isNavigating ? '60px' : isPreviewMode ? '36px' : '84px';

      if (isNavigating) {
        el.innerHTML = `
          <div class="relative flex items-center justify-center w-[60px] h-[60px] pointer-events-none select-none">
            <div class="absolute w-14 h-14 rounded-full bg-sky-500/15 border border-sky-400/25"></div>
            <div class="relative w-[56px] h-[56px] flex items-center justify-center">
              <svg viewBox="0 0 64 64" class="w-full h-full" style="filter: drop-shadow(0 5px 10px rgba(0, 0, 0, 0.45));">
                <path
                  d="M32 6 L56 54 L32 43 L8 54 Z"
                  fill="#00d2ff"
                  stroke="#ffffff"
                  stroke-width="4.2"
                  stroke-linejoin="round"
                  stroke-linecap="round"
                />
              </svg>
            </div>
          </div>
        `;
      } else if (isPreviewMode) {
        el.innerHTML = `
          <div class="relative flex items-center justify-center w-[36px] h-[36px] pointer-events-none select-none">
            <div class="absolute w-8 h-8 rounded-full bg-sky-500/30 border border-sky-400/45"></div>
            <div class="relative w-4 h-4 rounded-full bg-[#0284c7] border-[2.5px] border-white shadow-[0_2px_8px_rgba(2,132,199,0.75)]"></div>
          </div>
        `;
      } else {
        el.innerHTML = `
          <div class="relative flex items-center justify-center w-[84px] h-[84px] pointer-events-none select-none">
            <div class="absolute w-16 h-16 rounded-full bg-sky-500/18 border border-sky-400/35"></div>
            <div class="relative w-[78px] h-[78px] flex items-center justify-center">
              <svg viewBox="0 0 64 64" class="w-full h-full" style="filter: drop-shadow(0 5px 10px rgba(0, 0, 0, 0.45));">
                <path
                  d="M32 6 L56 54 L32 43 L8 54 Z"
                  fill="#00d2ff"
                  stroke="#ffffff"
                  stroke-width="4.2"
                  stroke-linejoin="round"
                  stroke-linecap="round"
                />
              </svg>
            </div>
          </div>
        `;
      }

      const [initLat, initLng] = currentMarkerPosRef.current;
      const initAngle = isPreviewMode ? 0 : currentMarkerAngleRef.current;

      const marker = new maplibregl.Marker({
        element: el,
        anchor: 'center',
        rotationAlignment: isPreviewMode ? 'viewport' : 'map',
        pitchAlignment: isPreviewMode ? 'viewport' : 'map',
        subpixelPositioning: true,
      })
        .setLngLat([initLng, initLat])
        .setRotation(initAngle)
        .addTo(map);

      el.style.zIndex = '50';
      userMarkerRef.current = marker;
    }
  }, [
    userLocation,
    isFollowing,
    isNavigating,
    isHeadingUp,
    mapSettings.autoRotation,
    mapSettings.perspective3D,
    mapTileMode,
    activeRoute,
    routes.length,
    distanceToNextStep,
    speedKmh,
    recenterTrigger,
    overviewTrigger,
    calculateSmartZoom,
    calculateIdleZoom,
    getLowerThirdPadding,
    resolveValidBearing,
    getEffectiveNavPitch,
    getEffectiveIdlePitch,
  ]);

  const computePreviewFitLayout = useCallback(
    (
      map: maplibregl.Map,
      routesList: RouteData[],
      destForBounds: Coordinates | null
    ) => {
      const bounds = new maplibregl.LngLatBounds();
      for (const r of routesList) {
        for (const [lat, lng] of r.coordinates) {
          bounds.extend([lng, lat]);
        }
      }
      const currUserLoc = userLocationRef.current;
      if (
        Number.isFinite(currUserLoc?.lat) &&
        Number.isFinite(currUserLoc?.lng) &&
        !(Math.abs(currUserLoc.lat) < 0.01 && Math.abs(currUserLoc.lng) < 0.01)
      ) {
        bounds.extend([currUserLoc.lng, currUserLoc.lat]);
      }
      if (destForBounds && Number.isFinite(destForBounds.lat) && Number.isFinite(destForBounds.lng)) {
        bounds.extend([destForBounds.lng, destForBounds.lat]);
      }

      const containerHeight = map.getContainer()?.clientHeight || window.innerHeight || 720;
      const containerWidth = map.getContainer()?.clientWidth || window.innerWidth || 360;
      const navCardEl =
        typeof document !== 'undefined' ? document.querySelector('.nav-card') : null;
      const measuredPanelHeight = navCardEl
        ? Math.round(navCardEl.getBoundingClientRect().height)
        : 215;

      const topPad = 100;
      const rightPad = containerWidth < 260 ? 60 : 90;
      const leftPad = containerWidth < 260 ? 20 : 40;
      const desiredBottomPad = measuredPanelHeight + 30;
      const maxSafeBottomPad = Math.max(120, containerHeight - topPad - 60);
      const bottomPad = Math.min(desiredBottomPad, maxSafeBottomPad);

      return {
        bounds,
        measuredPanelHeight,
        padding: { top: topPad, bottom: bottomPad, left: leftPad, right: rightPad },
      };
    },
    []
  );

  const runPreviewFitBounds = useCallback(
    (
      map: maplibregl.Map,
      routesList: RouteData[],
      destForBounds: Coordinates | null,
      durationMs: number = 600,
      reason: string = 'preview'
    ) => {
      if (isNavigatingRef.current || routesList.length === 0) return;

      // 1. Pausar seguimiento automático y cancelar cualquier animación/temporizador de cámara previo
      if (previewFitTimeoutRef.current) {
        clearTimeout(previewFitTimeoutRef.current);
        previewFitTimeoutRef.current = null;
      }
      if (idlePitchLockTimerRef.current) {
        clearTimeout(idlePitchLockTimerRef.current);
        idlePitchLockTimerRef.current = null;
      }
      if (idleStopNorthTimerRef.current) {
        clearTimeout(idleStopNorthTimerRef.current);
        idleStopNorthTimerRef.current = null;
      }
      if (programmaticClearTimerRef.current) {
        clearTimeout(programmaticClearTimerRef.current);
        programmaticClearTimerRef.current = null;
      }
      if (recenterWaitTimerRef.current) {
        clearTimeout(recenterWaitTimerRef.current);
        recenterWaitTimerRef.current = null;
      }

      idleBearingAnimRef.current.active = false;
      cameraNeedsImmediateSnapRef.current = false;
      isIdleAutoOrientActiveRef.current = false;
      isAtomicRecenterInFlightRef.current = false;
      pendingRecenterRef.current = false;
      isManuallyRotatedRef.current = false;
      setIsManuallyRotated(false);
      setMapRotation(0);

      if (isFollowingRef.current) {
        onToggleFollowRef.current(false);
      }

      map.stop();

      // 2. Limpiar padding residual de la pantalla principal y fijar vista vertical (pitch 0, Norte arriba)
      try {
        map.setPadding({ top: 0, bottom: 0, left: 0, right: 0 });
      } catch {}

      applyPitchGesturePolicy(map, { unlockingForTransition: true });
      try {
        map.setMinZoom(8);
        map.setMaxZoom(19);
      } catch {}

      const { bounds, measuredPanelHeight, padding } = computePreviewFitLayout(
        map,
        routesList,
        destForBounds
      );
      if (bounds.isEmpty()) {
        applyPitchGesturePolicy(map);
        return;
      }
      lastFittedPanelHeightRef.current = measuredPanelHeight;

      followCamTargetPitchRef.current = 0;
      followCamTargetBearingRef.current = 0;
      followCamTargetPaddingRef.current = { top: 0, bottom: 0, left: 0, right: 0 };

      let computedZoom: number | null = null;
      try {
        const cam = map.cameraForBounds(bounds, {
          padding,
          bearing: 0,
          maxZoom: 17,
        });
        if (cam && typeof cam.zoom === 'number' && Number.isFinite(cam.zoom)) {
          computedZoom = Math.min(17, Math.max(8, cam.zoom));
        }
      } catch {}

      const sw = bounds.getSouthWest();
      const ne = bounds.getNorthEast();
      console.log('[RutaLima][PreviewFitBounds]', {
        reason,
        zoom: computedZoom !== null ? Number(computedZoom.toFixed(2)) : null,
        bounds: {
          southWest: { lat: Number(sw.lat.toFixed(6)), lng: Number(sw.lng.toFixed(6)) },
          northEast: { lat: Number(ne.lat.toFixed(6)), lng: Number(ne.lng.toFixed(6)) },
        },
        padding,
        routesCount: routesList.length,
      });

      isProgrammaticMoveRef.current = true;
      beginProgrammaticCameraLock(map, durationMs + 80);

      let finalized = false;
      const finalizePreviewFit = () => {
        if (finalized) return;
        finalized = true;
        map.off('moveend', finalizePreviewFit);
        if (previewFitTimeoutRef.current) {
          clearTimeout(previewFitTimeoutRef.current);
          previewFitTimeoutRef.current = null;
        }
        isProgrammaticMoveRef.current = false;
        if (!isNavigatingRef.current && hasAnyRoutesRef.current) {
          applyPitchGesturePolicy(map);
        }
      };

      map.once('moveend', finalizePreviewFit);
      previewFitTimeoutRef.current = setTimeout(finalizePreviewFit, durationMs + 95);

      try {
        map.fitBounds(bounds, {
          padding,
          bearing: 0,
          pitch: 0,
          maxZoom: 17,
          duration: durationMs,
          linear: true,
          essential: true,
        });
      } catch {
        finalizePreviewFit();
      }
    },
    [computePreviewFitLayout, applyPitchGesturePolicy, beginProgrammaticCameraLock]
  );

  const schedulePreviewFitBounds = useCallback(
    (reason: string, delayMs: number = 300, opts?: { force?: boolean }) => {
      if (previewFitDebounceTimerRef.current) {
        clearTimeout(previewFitDebounceTimerRef.current);
        previewFitDebounceTimerRef.current = null;
      }
      if (!opts?.force && userInteractedInPreviewRef.current) return;

      previewFitDebounceTimerRef.current = setTimeout(() => {
        previewFitDebounceTimerRef.current = null;
        const map = mapInstanceRef.current;
        if (!map || isNavigatingRef.current) return;
        if (!opts?.force && userInteractedInPreviewRef.current) return;
        const currRoutes =
          routesRef.current.length > 0
            ? routesRef.current
            : activeRouteRef.current
            ? [activeRouteRef.current]
            : [];
        if (currRoutes.length === 0) return;

        const destForBounds =
          activeRouteRef.current?.destinationCoords ||
          routesRef.current[0]?.destinationCoords ||
          destinationCoordsRef.current ||
          null;
        runPreviewFitBounds(map, currRoutes, destForBounds, 600, reason);
      }, delayMs);
    },
    [runPreviewFitBounds]
  );

  handleUserPreviewRouteTapRef.current = (tappedRoute: RouteData) => {
    userInteractedInPreviewRef.current = false;
    if (previewFitDebounceTimerRef.current) {
      clearTimeout(previewFitDebounceTimerRef.current);
      previewFitDebounceTimerRef.current = null;
    }
    if (previewFitInitialRafRef.current !== null) {
      cancelAnimationFrame(previewFitInitialRafRef.current);
      previewFitInitialRafRef.current = null;
    }
    lastSelectedPreviewRouteIdRef.current = tappedRoute.id;
    onSelectRouteRef.current?.(tappedRoute);

    const map = mapInstanceRef.current;
    if (map && !isNavigatingRef.current) {
      const currRoutes =
        routesRef.current.length > 0
          ? routesRef.current
          : activeRouteRef.current
          ? [activeRouteRef.current]
          : [tappedRoute];
      const destForBounds =
        tappedRoute.destinationCoords ||
        activeRouteRef.current?.destinationCoords ||
        destinationCoordsRef.current ||
        null;
      runPreviewFitBounds(map, currRoutes, destForBounds, 600, 'route-tap');
    }
  };

  // 6. Draw Routes, Globitos & Destination Pin
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Update GeoJSON lines
    if (isMapStyleReadyRef.current && isMapStyleReadyForSources(map)) {
      syncRouteDataToMap(map);
    }

    // Clear previous globitos
    routeTimeMarkersRef.current.forEach((m) => m.remove());
    routeTimeMarkersRef.current = [];

    // Clear previous destination marker
    if (destMarkerRef.current) {
      destMarkerRef.current.remove();
      destMarkerRef.current = null;
    }

    const routesToDraw = isNavigating
      ? activeRoute
        ? [activeRoute]
        : []
      : routes.length > 0
      ? routes
      : activeRoute
      ? [activeRoute]
      : [];

    if (routesToDraw.length === 0) {
      lastFittedRouteKeyRef.current = null;
      lastFittedDestKeyRef.current = null;
      lastFittedPanelHeightRef.current = null;
      lastSelectedPreviewRouteIdRef.current = null;
      userInteractedInPreviewRef.current = false;
      if (previewFitDebounceTimerRef.current) {
        clearTimeout(previewFitDebounceTimerRef.current);
        previewFitDebounceTimerRef.current = null;
      }
      if (previewFitInitialRafRef.current !== null) {
        cancelAnimationFrame(previewFitInitialRafRef.current);
        previewFitInitialRafRef.current = null;
      }
      if (destinationCoords) {
        const destEl = document.createElement('div');
        destEl.className = 'dest-pin-marker';
        destEl.innerHTML = createExactDestPinHTML();
        destMarkerRef.current = new maplibregl.Marker({
          element: destEl,
          anchor: 'bottom',
          rotationAlignment: 'viewport',
          pitchAlignment: 'viewport',
        })
          .setLngLat([destinationCoords.lng, destinationCoords.lat])
          .addTo(map);
        syncDestCollisionBlocker(map, destinationCoords);
      } else {
        syncDestCollisionBlocker(map, null);
      }
      return;
    }

    const allCoordinates: [number, number][] = [];
    const sortedByDuration = [...routesToDraw].sort((a, b) => a.duration - b.duration);
    const fastestId = sortedByDuration[0]?.id;
    const selectedId = activeRoute ? activeRoute.id : fastestId;
    const targetDestination = activeRoute || (routes.length > 0 ? routes[0] : null);
    const destForBounds =
      targetDestination?.destinationCoords || destinationCoords || null;

    routesToDraw.forEach((r) => {
      allCoordinates.push(...r.coordinates);
    });

    if (!isNavigating && allCoordinates.length > 0) {
      const { padding } = computePreviewFitLayout(map, routesToDraw, destForBounds);
      const labelCoordsMap = computeNonOverlappingRouteLabelCoords(
        map,
        routesToDraw,
        selectedId,
        fastestId,
        userLocationRef.current,
        destForBounds,
        padding
      );

      routesToDraw.forEach((r) => {
        if (r.coordinates.length < 2) return;
        const isSelected = r.id === selectedId;
        const isFastest = r.id === fastestId;
        const mins = Math.max(1, Math.round(r.duration / 60));
        const globitoCoord =
          labelCoordsMap.get(r.id) ||
          r.coordinates[Math.floor(r.coordinates.length / 2)];

        const globitoHtml = isSelected
          ? `<div class="route-time-pill flex flex-col items-center cursor-pointer active:scale-95 transition-transform select-none">
              <div class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-white font-black text-[13px] leading-none border-2 border-purple-200/90 shadow-[0_6px_18px_rgba(76,29,149,0.55)]" style="background-color:#4c1d95;">
                <span>${mins} min</span>
                ${
                  isFastest
                    ? '<span class="text-[10px] px-1.5 py-0.5 rounded-md bg-white/20 text-white font-black leading-none">Mejor</span>'
                    : ''
                }
              </div>
              <div style="width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:6px solid #4c1d95;margin-top:-1px;"></div>
            </div>`
          : `<div class="route-time-pill flex flex-col items-center cursor-pointer hover:scale-105 active:scale-95 transition-transform select-none">
              <div class="flex items-center px-2.5 py-1 rounded-xl bg-white text-slate-900 font-extrabold text-[11px] leading-none border border-slate-300 shadow-[0_4px_12px_rgba(15,23,42,0.28)]">
                <span>${mins} min</span>
              </div>
              <div style="width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-top:5px solid #ffffff;margin-top:-1px;filter:drop-shadow(0 2px 2px rgba(15,23,42,0.18));"></div>
            </div>`;

        const pillEl = document.createElement('div');
        pillEl.className = 'route-time-marker';
        pillEl.style.zIndex = isSelected ? '26' : '16';
        pillEl.innerHTML = globitoHtml;
        pillEl.addEventListener('click', (ev) => {
          ev.stopPropagation();
          if (!isNavigatingRef.current) {
            handleUserPreviewRouteTapRef.current(r);
          }
        });

        const timeMarker = new maplibregl.Marker({
          element: pillEl,
          anchor: 'bottom',
          rotationAlignment: 'viewport',
          pitchAlignment: 'viewport',
        })
          .setLngLat([globitoCoord[1], globitoCoord[0]])
          .addTo(map);

        routeTimeMarkersRef.current.push(timeMarker);
      });
    }

    // Destination Pin for the active route (exact tip anchored at destination coordinate)
    if (targetDestination) {
      const destCoords = targetDestination.destinationCoords;
      const destEl = document.createElement('div');
      destEl.className = 'dest-pin-marker';
      destEl.innerHTML = createExactDestPinHTML();

      destMarkerRef.current = new maplibregl.Marker({
        element: destEl,
        anchor: 'bottom',
        rotationAlignment: 'viewport',
        pitchAlignment: 'viewport',
      })
        .setLngLat([destCoords.lng, destCoords.lat])
        .addTo(map);
      syncDestCollisionBlocker(map, destCoords);
    } else {
      syncDestCollisionBlocker(map, null);
    }

    // Auto-fit routes when previewing (from point A to point B, flat, North-up, clear of HUD/buttons)
    if (!isNavigating && allCoordinates.length > 0) {
      const destKey = destForBounds
        ? `${destForBounds.lat.toFixed(5)}_${destForBounds.lng.toFixed(5)}`
        : 'none';
      const currentRouteKey =
        routesToDraw.map((r) => `${r.id}_${r.coordinates.length}`).join('|') + `_${destKey}`;

      const wasEmpty = lastFittedRouteKeyRef.current === null;
      const isNewDestination = lastFittedDestKeyRef.current !== destKey;

      if (isNewDestination) {
        lastFittedDestKeyRef.current = destKey;
        userInteractedInPreviewRef.current = false;
      }

      if (lastFittedRouteKeyRef.current !== currentRouteKey) {
        lastFittedRouteKeyRef.current = currentRouteKey;
        lastSelectedPreviewRouteIdRef.current = selectedId || null;

        if (wasEmpty || isNewDestination) {
          userInteractedInPreviewRef.current = false;
          if (isFollowingRef.current) {
            onToggleFollowRef.current(false);
          }
          map.stop();
          if (previewFitInitialRafRef.current !== null) {
            cancelAnimationFrame(previewFitInitialRafRef.current);
          }
          previewFitInitialRafRef.current = requestAnimationFrame(() => {
            previewFitInitialRafRef.current = null;
            if (!isNavigatingRef.current && !userInteractedInPreviewRef.current) {
              runPreviewFitBounds(map, routesToDraw, destForBounds, 600, 'initial-preview');
            }
          });
        } else if (!userInteractedInPreviewRef.current) {
          schedulePreviewFitBounds('alternative-route-updated', 300);
        }
      } else if (selectedId && selectedId !== lastSelectedPreviewRouteIdRef.current) {
        lastSelectedPreviewRouteIdRef.current = selectedId;
        userInteractedInPreviewRef.current = false;
        runPreviewFitBounds(map, routesToDraw, destForBounds, 600, 'route-selected');
      }
    } else if (isNavigating) {
      lastFittedRouteKeyRef.current = null;
      lastFittedDestKeyRef.current = null;
      lastFittedPanelHeightRef.current = null;
      lastSelectedPreviewRouteIdRef.current = null;
      userInteractedInPreviewRef.current = false;
    }
  }, [
    routes,
    activeRoute,
    destinationCoords,
    isNavigating,
    syncRouteDataToMap,
    syncDestCollisionBlocker,
    computePreviewFitLayout,
    runPreviewFitBounds,
    schedulePreviewFitBounds,
  ]);

  // 6a-bis. Reencuadra suavemente (debounce ~300 ms) al terminar de cargar, cambiar tamaño del panel o rotar/redimensionar pantalla
  useEffect(() => {
    const map = mapInstanceRef.current;
    const routesToFit =
      routes.length > 0 ? routes : activeRoute ? [activeRoute] : [];

    const finishedLoading = prevIsLoadingRouteRef.current && !isLoadingRoute;
    prevIsLoadingRouteRef.current = isLoadingRoute;

    if (!map || isNavigating || routesToFit.length === 0) return;

    if (finishedLoading && !userInteractedInPreviewRef.current) {
      schedulePreviewFitBounds('loading-finished', 300);
    }

    let observer: ResizeObserver | null = null;
    let attachRaf: number | null = null;

    const handleScreenResize = () => {
      if (isNavigatingRef.current || !hasAnyRoutesRef.current || userInteractedInPreviewRef.current) {
        return;
      }
      schedulePreviewFitBounds('screen-resize', 300);
    };

    window.addEventListener('resize', handleScreenResize);
    window.addEventListener('orientationchange', handleScreenResize);

    const attachObserver = () => {
      const navCardEl =
        typeof document !== 'undefined' ? document.querySelector('.nav-card') : null;
      if (!navCardEl || typeof ResizeObserver === 'undefined') return false;

      observer = new ResizeObserver(() => {
        if (isNavigatingRef.current || userInteractedInPreviewRef.current) return;
        const currRoutes =
          routesRef.current.length > 0
            ? routesRef.current
            : activeRouteRef.current
            ? [activeRouteRef.current]
            : [];
        if (currRoutes.length === 0) return;
        const nextHeight = Math.round(navCardEl.getBoundingClientRect().height);
        if (
          lastFittedPanelHeightRef.current !== null &&
          Math.abs(nextHeight - lastFittedPanelHeightRef.current) < 4
        ) {
          return;
        }
        schedulePreviewFitBounds('panel-resize', 300);
      });
      observer.observe(navCardEl);
      return true;
    };

    if (!attachObserver()) {
      attachRaf = requestAnimationFrame(() => {
        attachObserver();
      });
    }

    return () => {
      window.removeEventListener('resize', handleScreenResize);
      window.removeEventListener('orientationchange', handleScreenResize);
      if (attachRaf !== null) cancelAnimationFrame(attachRaf);
      if (observer) observer.disconnect();
    };
  }, [isNavigating, isLoadingRoute, routes, activeRoute, destinationCoords, schedulePreviewFitBounds]);

  // 6b. Active Navigation Maneuver Overlays on Blue Route (full-curve Waze turn arrow + light-cyan next street bubble)
  useEffect(() => {
    const map = mapInstanceRef.current;
    const clearTurnArrow = () => {
      maneuverGeoJsonRef.current = EMPTY_MANEUVER_FC;
      if (map) {
        try {
          const src = map.getSource(MANEUVER_ARROW_SOURCE_ID) as maplibregl.GeoJSONSource | undefined;
          src?.setData(EMPTY_MANEUVER_FC);
        } catch {}
      }
    };
    const clearStreetBubble = () => {
      if (nextStreetBubbleMarkerRef.current) {
        nextStreetBubbleMarkerRef.current.remove();
        nextStreetBubbleMarkerRef.current = null;
      }
      nextStreetBubbleLabelRef.current = '';
    };

    if (
      !map ||
      !isNavigating ||
      !activeRoute ||
      activeRoute.coordinates.length < 2 ||
      !currentStep
    ) {
      clearTurnArrow();
      clearStreetBubble();
      return;
    }

    const coords = activeRoute.coordinates;
    const stepLat = currentStep.coordinates[0];
    const stepLng = currentStep.coordinates[1];

    // Locate closest vertex on route polyline for the next maneuver
    let turnIdx = 0;
    let bestStepDist = Infinity;
    for (let i = 0; i < coords.length; i++) {
      const d = getDistanceMeters(stepLat, stepLng, coords[i][0], coords[i][1]);
      if (d < bestStepDist) {
        bestStepDist = d;
        turnIdx = i;
      }
    }
    const turnPt = coords[turnIdx] || currentStep.coordinates;
    const distUserToTurn = getDistanceMeters(userLocation.lat, userLocation.lng, turnPt[0], turnPt[1]);

    const isDayMode = mapTileMode === 'day';

    // A) Flecha blanca con contorno oscuro sobre la ruta morada (solo el siguiente giro dentro de 300 m)
    const effectiveTurnDistance = Number.isFinite(distanceToNextStep)
      ? Math.min(distanceToNextStep, distUserToTurn)
      : distUserToTurn;
    const shouldShowRouteArrow =
      effectiveTurnDistance <= 300 &&
      currentStep.type !== 'depart' &&
      !(currentStep.type === 'arrive' && effectiveTurnDistance < 12);
    const maneuverGeoJSON = shouldShowRouteArrow
      ? buildManeuverArrowGeoJSON(coords, currentStep)
      : EMPTY_MANEUVER_FC;
    maneuverGeoJsonRef.current = maneuverGeoJSON;

    if (isMapStyleReadyRef.current && isMapStyleReadyForSources(map)) {
      try {
        if (ensureRouteLayers(map)) {
          const src = map.getSource(MANEUVER_ARROW_SOURCE_ID) as
            | maplibregl.GeoJSONSource
            | undefined;
          src?.setData(maneuverGeoJSON);
        }
      } catch {}
    }

    // B) Next-street bubble on the active route
    const rawStreetName = (currentStep.name || nextStep?.name || '').trim();
    if (!rawStreetName) {
      clearStreetBubble();
      return;
    }

    // In Day Mode, hide the next-turn street bubble when the turn is more than 800m away
    if (isDayMode && distUserToTurn > 800) {
      clearStreetBubble();
      return;
    }

    const walkAlongRouteFrom = (startIdx: number, targetMeters: number): [number, number] => {
      let walked = 0;
      for (let i = startIdx; i < coords.length - 1; i++) {
        const segLen = getDistanceMeters(coords[i][0], coords[i][1], coords[i + 1][0], coords[i + 1][1]);
        if (walked + segLen >= targetMeters && segLen > 0) {
          const ratio = (targetMeters - walked) / segLen;
          return [
            coords[i][0] + (coords[i + 1][0] - coords[i][0]) * ratio,
            coords[i][1] + (coords[i + 1][1] - coords[i][1]) * ratio,
          ];
        }
        walked += segLen;
      }
      return coords[Math.max(startIdx, coords.length - 2)] || coords[coords.length - 1];
    };

    let bubblePt: [number, number] | null = null;
    if (isDayMode) {
      // Place near the next turn on the route line
      bubblePt =
        turnIdx < coords.length - 1 ? walkAlongRouteFrom(turnIdx, 24) : turnPt;
    } else if (distUserToTurn <= 260 && turnIdx < coords.length - 1) {
      // Place 36m after the turn directly on the outgoing street
      bubblePt = walkAlongRouteFrom(turnIdx, 36);
    } else {
      // Long approach (>260m): find nearest user vertex and place 135m ahead on the visible blue route
      let userIdx = 0;
      let bestUserDist = Infinity;
      for (let i = 0; i <= turnIdx; i++) {
        const d = getDistanceMeters(userLocation.lat, userLocation.lng, coords[i][0], coords[i][1]);
        if (d < bestUserDist) {
          bestUserDist = d;
          userIdx = i;
        }
      }
      bubblePt = walkAlongRouteFrom(userIdx, Math.min(135, Math.max(55, distUserToTurn * 0.45)));
    }

    const destCoords = activeRoute.destinationCoords;
    const distFromUser = bubblePt
      ? getDistanceMeters(userLocation.lat, userLocation.lng, bubblePt[0], bubblePt[1])
      : 0;
    const distFromDest =
      bubblePt && destCoords
        ? getDistanceMeters(destCoords.lat, destCoords.lng, bubblePt[0], bubblePt[1])
        : 999;

    if (!bubblePt || distFromUser < 40 || distFromDest < 24) {
      clearStreetBubble();
      return;
    }

    if (
      !nextStreetBubbleMarkerRef.current ||
      nextStreetBubbleLabelRef.current !== rawStreetName ||
      nextStreetBubbleModeRef.current !== mapTileMode
    ) {
      clearStreetBubble();
      const safeLabel = rawStreetName.replace(/</g, '&lt;').replace(/>/g, '&gt;');
      const bubbleEl = document.createElement('div');
      bubbleEl.className = 'nav-next-street-bubble pointer-events-none select-none';
      bubbleEl.style.zIndex = '46';
      if (isDayMode) {
        bubbleEl.innerHTML = `
          <div class="flex flex-col items-center">
            <div class="px-2.5 py-1 rounded-lg bg-slate-900 text-white border border-sky-400/80 shadow-[0_3px_10px_rgba(0,0,0,0.4)] font-extrabold text-[11px] leading-tight tracking-tight whitespace-nowrap max-w-[155px] truncate">${safeLabel}</div>
            <div class="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[6px] border-t-slate-900 -mt-[1px]"></div>
          </div>
        `;
      } else {
        bubbleEl.innerHTML = `<div class="px-2 py-0.5 rounded-md bg-sky-200 text-slate-950 border border-slate-900/90 shadow-[0_2px_6px_rgba(0,0,0,0.6)] font-extrabold text-[11px] leading-tight tracking-tight whitespace-nowrap max-w-[140px] truncate">${safeLabel}</div>`;
      }
      nextStreetBubbleLabelRef.current = rawStreetName;
      nextStreetBubbleModeRef.current = mapTileMode;
      nextStreetBubbleMarkerRef.current = new maplibregl.Marker({
        element: bubbleEl,
        anchor: isDayMode ? 'bottom' : 'center',
      })
        .setLngLat([bubblePt[1], bubblePt[0]])
        .addTo(map);
    } else {
      nextStreetBubbleMarkerRef.current.setLngLat([bubblePt[1], bubblePt[0]]);
    }
  }, [isNavigating, mapTileMode, activeRoute, currentStep, nextStep, distanceToNextStep, userLocation.lat, userLocation.lng]);

  // 6c. Resolve current street name pill for Day Mode navigation
  useEffect(() => {
    if (!isNavigating || mapTileMode !== 'day') {
      setResolvedCurrentStreet('');
      return;
    }

    const trimmedRouteStreet = (currentRoadName || '').trim();
    let isNearActiveRoute = false;
    if (trimmedRouteStreet && activeRoute && activeRoute.coordinates.length >= 2) {
      const match = matchUserToRoute(
        userLocation.lat,
        userLocation.lng,
        userLocation.heading,
        activeRoute.coordinates
      );
      if (match.distanceToRoute <= 40) {
        isNearActiveRoute = true;
      }
    }

    if (trimmedRouteStreet && isNearActiveRoute) {
      setResolvedCurrentStreet(trimmedRouteStreet);
      return;
    }

    const map = mapInstanceRef.current;
    if (map && isMapStyleReadyRef.current && isMapStyleReadyForSources(map)) {
      try {
        const pt = map.project([userLocation.lng, userLocation.lat]);
        const queryLayers = [
          'roadname_minor',
          'roadname_sec',
          'roadname_pri',
          'roadname_major',
          'road_minor_fill',
          'road_sec_fill_noramp',
          'road_pri_fill_noramp',
          'road_trunk_fill_noramp',
          'road_mot_fill_noramp',
        ].filter((id) => Boolean(map.getLayer(id)));

        if (queryLayers.length > 0) {
          const features = map.queryRenderedFeatures(
            [
              [pt.x - 32, pt.y - 32],
              [pt.x + 32, pt.y + 32],
            ],
            { layers: queryLayers }
          );
          for (const f of features) {
            const props = f.properties as Record<string, any> | undefined;
            const n1 = typeof props?.name === 'string' ? props.name.trim() : '';
            const n2 = typeof props?.name2 === 'string' ? props.name2.trim() : '';
            const combined = [n1, n2].filter(Boolean).join(' ').trim();
            if (combined) {
              setResolvedCurrentStreet(combined);
              return;
            }
          }
        }
      } catch {}
    }

    setResolvedCurrentStreet(trimmedRouteStreet);
  }, [
    isNavigating,
    mapTileMode,
    currentRoadName,
    activeRoute,
    userLocation.lat,
    userLocation.lng,
    userLocation.heading,
  ]);

  // 7. Traffic Incident Markers with Unified Community Report Card
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    alertMarkersRef.current.forEach((m) => m.remove());
    alertMarkersRef.current = [];

    const now = Date.now();
    const activeAlerts = trafficAlerts.filter((a) => !isAlertExpired(a, now));

    const renderCommunityAlertBubbleSvg = (
      bgHex: string,
      iconInnerSvg: string,
      widthPx: number = 50
    ): string => {
      const heightPx = Math.round((widthPx * 74) / 64);
      return `
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 64 74"
          width="${widthPx}"
          height="${heightPx}"
          style="display:block;overflow:visible;filter:drop-shadow(0 3px 6px rgba(0,0,0,0.52));"
        >
          <path
            d="M22.2 50.9 A24 24 0 1 1 41.8 50.9 C38.2 54.6 34.5 60 32 68.5 C29.5 60 25.8 54.6 22.2 50.9 Z"
            fill="${bgHex}"
            stroke="#ffffff"
            stroke-width="4.2"
            stroke-linejoin="round"
          />
          ${iconInnerSvg}
        </svg>
      `;
    };

    activeAlerts.forEach((alert) => {
      const isPoliceAlert = alert.type === 'police';
      const policeSubtype = isPoliceAlert ? normalizePoliceSubtype(alert) : 'visible';
      const policeSubtypeLabel = isPoliceAlert ? getPoliceSubtypeLabel(policeSubtype) : alert.title;
      const isInspectorAlert = alert.type === 'inspectors';
      const inspectorSubtype = isInspectorAlert ? normalizeInspectorSubtype(alert) : 'inspector_a';
      const inspectorSubtypeLabel = isInspectorAlert
        ? getInspectorSubtypeLabel(inspectorSubtype)
        : alert.title;

      const markerOpacity = alert.type === 'inspectors' ? getInspectorMarkerOpacity(alert, now) : 1;
      const markerCoordsList = getAlertTargetCoords(alert);

      markerCoordsList.forEach((coord) => {
        const alertEl = document.createElement('div');
        alertEl.className = 'alert-map-marker cursor-pointer';
        alertEl.dataset.baseOpacity = String(markerOpacity);
        const hiddenByOverview = isOverviewActiveRef.current;
        const shouldFadeInAfterOverview =
          !hiddenByOverview && justExitedOverviewUntilRef.current > Date.now();
        alertEl.style.opacity =
          hiddenByOverview || shouldFadeInAfterOverview ? '0' : String(markerOpacity);
        alertEl.style.pointerEvents = hiddenByOverview ? 'none' : 'auto';
        if (hiddenByOverview) {
          alertEl.setAttribute('aria-hidden', 'true');
        }
        alertEl.style.zIndex = isPoliceAlert || isInspectorAlert ? '47' : '45';

        if (isPoliceAlert) {
          alertEl.innerHTML = `
            <div class="relative flex flex-col items-center justify-end" aria-label="${policeSubtypeLabel}">
              ${renderPoliceMarkerSvg(policeSubtype, 50)}
            </div>
          `;
        } else if (isInspectorAlert) {
          alertEl.innerHTML = `
            <div class="relative flex flex-col items-center justify-end" aria-label="${inspectorSubtypeLabel}">
              ${renderInspectorMarkerHtml(inspectorSubtype, 50)}
            </div>
          `;
        } else {
          const { bgHex, bubbleIconSvg } = getCommunityAlertVisual(alert.type);
          alertEl.innerHTML = `
            <div class="relative flex flex-col items-center justify-end" aria-label="${alert.title}">
              ${renderCommunityAlertBubbleSvg(bgHex, bubbleIconSvg, 50)}
            </div>
          `;
        }

        alertEl.addEventListener('click', (ev) => {
          if (isOverviewActiveRef.current) return;
          ev.stopPropagation();
          if (shouldSuppressMapClick()) return;
          dismissLongPressRef.current();
          setSelectedPoi(null);
          setSelectedFixedRadar(null);
          openCommunityAlertCard(alert);
        });

        const m = new maplibregl.Marker({
          element: alertEl,
          anchor: 'bottom',
          offset: [0, 3],
          rotationAlignment: 'viewport',
          pitchAlignment: 'viewport',
          subpixelPositioning: true,
        })
          .setLngLat([coord.lng, coord.lat])
          .addTo(map);

        if (shouldFadeInAfterOverview) {
          requestAnimationFrame(() => {
            if (!isOverviewActiveRef.current) {
              alertEl.style.opacity = alertEl.dataset.baseOpacity || String(markerOpacity);
            }
          });
        }

        alertMarkersRef.current.push(m);
      });
    });
  }, [trafficAlerts, alertOpacityTick, openCommunityAlertCard]);

  // Keep selectedCommunityAlert synchronized with latest trafficAlerts state
  useEffect(() => {
    if (isCommunityAlertClosingRef.current) return;
    setSelectedCommunityAlert((prev) => {
      if (!prev) return null;
      const latest = trafficAlerts.find((a) => a.id === prev.id);
      if (!latest || isAlertExpired(latest, Date.now()) || (latest.removalVotes || 0) >= 3) {
        return null;
      }
      return latest;
    });
  }, [trafficAlerts, alertOpacityTick]);

  // 7b. OpenStreetMap POIs (Overpass + extracción instantánea de teselas vectoriales CARTO/OSM)
  const poiVectorSyncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const syncVectorTilePoisFromMap = useCallback((map: maplibregl.Map): number => {
    try {
      if (!isMapStyleReadyForSources(map)) return 0;
      const currentZoom = map.getZoom();
      if (currentZoom < 15) return 0;
      if (!map.getSource('protomaps')) return 0;
      const features = map.querySourceFeatures('protomaps', { sourceLayer: 'pois' });
      if (!features || features.length === 0) return 0;
      const added = ingestVectorTileFeatures(features, currentZoom);
      if (added > 0) {
        onPoisUpdatedRef.current?.(getAllCachedPois());
      }
      return added;
    } catch {
      return 0;
    }
  }, []);

  const updatePoiLayerVisibility = useCallback((map: maplibregl.Map) => {
    if (!isMapStyleReadyForSources(map)) return;
    const visible = Boolean(mapSettingsRef.current.poiEnabled && !isOverviewActiveRef.current);
    const visVal = visible ? 'visible' : 'none';
    for (const layerId of [POI_REGULAR_LAYER_ID, POI_ESSENTIAL_LAYER_ID]) {
      try {
        if (map.getLayer(layerId)) {
          map.setLayoutProperty(layerId, 'visibility', visVal);
        }
      } catch {}
    }
  }, []);

  const syncPoiGeoJsonSource = useCallback(
    (map: maplibregl.Map, forceDataUpdate = false) => {
      if (!isMapStyleReadyForSources(map)) return;

      // Sincroniza cualquier POI ya cargado en los vector tiles antes de actualizar la fuente GeoJSON
      syncVectorTilePoisFromMap(map);

      // Asegura íconos 2x registrados en el estilo actual (Día / Noche / Satelital)
      registerPoiMapIcons(map);

      if (!map.getSource(POI_SOURCE_ID)) {
        lastPoiSourceSignatureRef.current = '';
        map.addSource(POI_SOURCE_ID, {
          type: 'geojson',
          data: { type: 'FeatureCollection', features: [] },
        });
      }

      const beforeOverlayId = map.getLayer(FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID)
        ? FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID
        : map.getLayer('ruta-preview-glow')
        ? 'ruta-preview-glow'
        : map.getLayer('ruta-active-glow')
        ? 'ruta-active-glow'
        : map.getLayer('ruta-maneuver-outline')
        ? 'ruta-maneuver-outline'
        : map.getLayer(DEST_COLLISION_LAYER_ID)
        ? DEST_COLLISION_LAYER_ID
        : undefined;

      const currentSettings = mapSettingsRef.current;
      const shouldBeVisible = Boolean(currentSettings.poiEnabled && !isOverviewActiveRef.current);
      const visibilityVal = shouldBeVisible ? 'visible' : 'none';

      // Capa 1 (zoom cercano >= 14.8): resto de lugares (colegios, tiendas, restaurantes, paraderos, etc.)
      if (!map.getLayer(POI_REGULAR_LAYER_ID)) {
        map.addLayer(
          {
            id: POI_REGULAR_LAYER_ID,
            type: 'symbol',
            source: POI_SOURCE_ID,
            minzoom: 14.8,
            filter: ['==', ['get', 'tier'], 'regular'],
            layout: {
              'icon-image': ['get', 'iconKey'],
              'symbol-sort-key': ['get', 'sortKey'],
              'icon-size': ['interpolate', ['linear'], ['zoom'], 14.8, 0.9, 16, 0.96, 18, 1.04],
              'icon-allow-overlap': false,
              'icon-ignore-placement': false,
              'icon-padding': 4,
              'icon-anchor': 'center',
              'icon-rotation-alignment': 'viewport',
              'icon-pitch-alignment': 'viewport',
              visibility: visibilityVal,
            },
          },
          beforeOverlayId
        );
      }

      // Capa 2 (zoom medio >= 13.0): lugares más importantes (hospitales, urgencias, comisarías, bomberos)
      // Ubicada después en estilo para tener prioridad absoluta en colisiones sobre la capa regular
      if (!map.getLayer(POI_ESSENTIAL_LAYER_ID)) {
        map.addLayer(
          {
            id: POI_ESSENTIAL_LAYER_ID,
            type: 'symbol',
            source: POI_SOURCE_ID,
            minzoom: 13.0,
            filter: ['==', ['get', 'tier'], 'essential'],
            layout: {
              'icon-image': ['get', 'iconKey'],
              'symbol-sort-key': ['get', 'sortKey'],
              'icon-size': ['interpolate', ['linear'], ['zoom'], 13, 0.86, 15, 0.94, 17, 1.02],
              'icon-allow-overlap': false,
              'icon-ignore-placement': false,
              'icon-padding': 4,
              'icon-anchor': 'center',
              'icon-rotation-alignment': 'viewport',
              'icon-pitch-alignment': 'viewport',
              visibility: visibilityVal,
            },
          },
          beforeOverlayId
        );
      }

      updatePoiLayerVisibility(map);

      if (!poiLayerListenersBoundRef.current) {
        poiLayerListenersBoundRef.current = true;
        const handlePoiLayerClick = (e: maplibregl.MapLayerMouseEvent) => {
          if (isPickingRadarLocationRef.current) return;
          if (shouldSuppressMapClick()) return;
          if (isOverviewActiveRef.current || !mapSettingsRef.current.poiEnabled) return;
          const poiId = e.features?.[0]?.properties?.poiId;
          if (!poiId) return;
          const found = cachedPoisByIdRef.current.get(String(poiId));
          if (!found) return;
          poiFeatureClickedAtRef.current = performance.now();
          dismissLongPressRef.current();
          setSelectedFixedRadar(null);
          closeCommunityAlertImmediate();
          setSelectedPoi(found);
        };
        const handlePoiEnter = () => {
          if (!isOverviewActiveRef.current && mapSettingsRef.current.poiEnabled) {
            map.getCanvas().style.cursor = 'pointer';
          }
        };
        const handlePoiLeave = () => {
          map.getCanvas().style.cursor = '';
        };
        map.on('click', POI_ESSENTIAL_LAYER_ID, handlePoiLayerClick);
        map.on('click', POI_REGULAR_LAYER_ID, handlePoiLayerClick);
        map.on('mouseenter', POI_ESSENTIAL_LAYER_ID, handlePoiEnter);
        map.on('mouseenter', POI_REGULAR_LAYER_ID, handlePoiEnter);
        map.on('mouseleave', POI_ESSENTIAL_LAYER_ID, handlePoiLeave);
        map.on('mouseleave', POI_REGULAR_LAYER_ID, handlePoiLeave);
      }

      const enabledCats = currentSettings.poiCategories || {};
      const enabledKey = Object.entries(enabledCats)
        .filter(([, v]) => v !== false)
        .map(([k]) => k)
        .sort()
        .join(',');

      const allCached = currentSettings.poiEnabled ? getAllCachedPois() : [];
      const isNavActive = isNavigatingRef.current;
      const navRouteCoords = activeRouteRef.current?.coordinates;
      const navRouteId = activeRouteRef.current?.id || 'none';
      const filtered = allCached.filter((poi) => {
        if (enabledCats[poi.category] === false) return false;
        if (isNavActive) {
          if (!NAV_USEFUL_POI_CATEGORIES.has(poi.category)) return false;
          if (navRouteCoords && navRouteCoords.length >= 2) {
            return isPoiNearActiveRoute(poi.lat, poi.lng, navRouteCoords, 150);
          }
        }
        return true;
      });
      const signature = `${currentSettings.poiEnabled ? 1 : 0}:${isNavActive ? 1 : 0}:${navRouteId}:${enabledKey}:${filtered.length}`;
      if (!forceDataUpdate && signature === lastPoiSourceSignatureRef.current) {
        return;
      }
      lastPoiSourceSignatureRef.current = signature;

      const lookup = new Map<string, MapPOI>();
      const features = filtered.map((poi) => {
        lookup.set(poi.id, poi);
        return {
          type: 'Feature' as const,
          properties: {
            poiId: poi.id,
            iconKey: getPoiIconKey(poi),
            sortKey: getPoiSortKey(poi),
            tier: getPoiZoomTier(poi),
          },
          geometry: {
            type: 'Point' as const,
            coordinates: [poi.lng, poi.lat] as [number, number],
          },
        };
      });
      cachedPoisByIdRef.current = lookup;

      const src = map.getSource(POI_SOURCE_ID) as maplibregl.GeoJSONSource | undefined;
      if (src) {
        src.setData({
          type: 'FeatureCollection',
          features,
        });
      }
    },
    [syncVectorTilePoisFromMap, updatePoiLayerVisibility]
  );

  const syncPoiGeoJsonSourceRef = useRef(syncPoiGeoJsonSource);
  syncPoiGeoJsonSourceRef.current = syncPoiGeoJsonSource;

  const schedulePoiRefresh = useCallback(
    (immediate = false) => {
      const map = mapInstanceRef.current;
      if (!map) return;

      if (poiDebounceTimerRef.current) {
        clearTimeout(poiDebounceTimerRef.current);
        poiDebounceTimerRef.current = null;
      }
      if (poiRetryTimerRef.current) {
        clearTimeout(poiRetryTimerRef.current);
        poiRetryTimerRef.current = null;
      }

      // Sincroniza inmediatamente la capa nativa de lugares sin recalcular posiciones en cada frame
      syncPoiGeoJsonSource(map, false);

      const currentSettings = mapSettingsRef.current;
      const hasAnyCategoryEnabled = Object.values(currentSettings.poiCategories || {}).some(Boolean);
      if (!currentSettings.poiEnabled || !hasAnyCategoryEnabled || map.getZoom() < 11) {
        if (poiAbortControllerRef.current) {
          poiAbortControllerRef.current.abort();
          poiAbortControllerRef.current = null;
          inFlightPoiBoundsRef.current = null;
        }
        return;
      }

      const b = map.getBounds();
      const bounds: GeoBounds = {
        south: b.getSouth(),
        west: b.getWest(),
        north: b.getNorth(),
        east: b.getEast(),
      };
      const detailLevel = getPoiDetailLevelForZoom(map.getZoom());

      if (isBoundsCoveredByCache(bounds, detailLevel)) {
        onPoisUpdatedRef.current?.(getAllCachedPois());
        return;
      }

      // Si ya hay una consulta Overpass en vuelo que cubre o solapa >=55% de esta vista, déjala terminar
      if (
        poiAbortControllerRef.current &&
        inFlightPoiBoundsRef.current &&
        (doesBoundsCover(inFlightPoiBoundsRef.current, bounds) ||
          boundsOverlapRatio(inFlightPoiBoundsRef.current, bounds) >= 0.55)
      ) {
        return;
      }

      const runFetch = async () => {
        const activeMap = mapInstanceRef.current;
        if (!activeMap || activeMap.getZoom() < 11 || !mapSettingsRef.current.poiEnabled) {
          return;
        }

        const latestB = activeMap.getBounds();
        const latestBounds: GeoBounds = {
          south: latestB.getSouth(),
          west: latestB.getWest(),
          north: latestB.getNorth(),
          east: latestB.getEast(),
        };
        const latestDetail = getPoiDetailLevelForZoom(activeMap.getZoom());

        if (isBoundsCoveredByCache(latestBounds, latestDetail)) {
          syncPoiGeoJsonSource(activeMap, false);
          return;
        }

        if (
          poiAbortControllerRef.current &&
          inFlightPoiBoundsRef.current &&
          (doesBoundsCover(inFlightPoiBoundsRef.current, latestBounds) ||
            boundsOverlapRatio(inFlightPoiBoundsRef.current, latestBounds) >= 0.55)
        ) {
          return;
        }

        if (poiAbortControllerRef.current) {
          poiAbortControllerRef.current.abort();
          poiAbortControllerRef.current = null;
          inFlightPoiBoundsRef.current = null;
        }

        const expandedQueryBounds = expandBoundsSlightly(latestBounds);
        const controller = new AbortController();
        poiAbortControllerRef.current = controller;
        inFlightPoiBoundsRef.current = expandedQueryBounds;

        const result = await fetchOverpassPOIsForBounds(
          latestBounds,
          mapSettingsRef.current.poiCategories,
          controller.signal,
          expandedQueryBounds,
          latestDetail
        );

        if (poiAbortControllerRef.current === controller) {
          poiAbortControllerRef.current = null;
          inFlightPoiBoundsRef.current = null;
        }

        if (result.aborted || controller.signal.aborted) return;

        if (result.ok) {
          poiRetryCountRef.current = 0;
          if (mapInstanceRef.current) {
            syncPoiGeoJsonSource(mapInstanceRef.current, true);
          }
          onPoisUpdatedRef.current?.(getAllCachedPois());
        } else {
          if (mapInstanceRef.current) {
            syncPoiGeoJsonSource(mapInstanceRef.current, false);
          }
          // Reintento silencioso en segundo plano (sin bloquear mapa ni saturar)
          const retryNum = poiRetryCountRef.current;
          if (retryNum < 4) {
            poiRetryCountRef.current = retryNum + 1;
            const delayMs = Math.min(30000, Math.round(6000 * Math.pow(1.6, retryNum)));
            poiRetryTimerRef.current = setTimeout(() => {
              schedulePoiRefresh(true);
            }, delayMs);
          }
        }
      };

      if (immediate) {
        runFetch();
      } else {
        poiDebounceTimerRef.current = setTimeout(runFetch, 450);
      }
    },
    [syncPoiGeoJsonSource]
  );

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const handleMapMoved = () => {
      if (isFollowCameraJumpActiveRef.current) {
        const now = performance.now();
        if (now - lastFollowPoiRefreshTimeRef.current < 1600) {
          return;
        }
        lastFollowPoiRefreshTimeRef.current = now;
        schedulePoiRefresh(true);
        return;
      }
      schedulePoiRefresh(false);
    };
    const handleMapLoaded = () => schedulePoiRefresh(true);
    const handleSourceData = (e: any) => {
      if (e?.sourceId === 'protomaps' && e?.isSourceLoaded) {
        if (poiVectorSyncTimerRef.current) return;
        poiVectorSyncTimerRef.current = setTimeout(() => {
          poiVectorSyncTimerRef.current = null;
          if (mapInstanceRef.current) {
            const added = syncVectorTilePoisFromMap(mapInstanceRef.current);
            if (added > 0 || cachedPoisByIdRef.current.size === 0) {
              syncPoiGeoJsonSource(mapInstanceRef.current, added > 0);
            }
          }
        }, 160);
      }
    };
    const handleMapBgClick = (e: maplibregl.MapMouseEvent) => {
      if (isPickingRadarLocationRef.current) {
        confirmRadarPickAtCoordsRef.current(e.lngLat.lat, e.lngLat.lng);
        return;
      }
      if (justTriggeredLongPressRef.current) return;
      if (performance.now() - poiFeatureClickedAtRef.current < 100) return;
      if (performance.now() - routeLineClickedAtRef.current < 100) return;
      if (!isNavigatingRef.current && routesRef.current.length > 0) {
        const routeHitLayers = ['ruta-preview-line', 'ruta-preview-outline'].filter((id) =>
          Boolean(map.getLayer(id))
        );
        if (routeHitLayers.length > 0) {
          try {
            const hitFeatures = map.queryRenderedFeatures(
              [
                [e.point.x - 14, e.point.y - 14],
                [e.point.x + 14, e.point.y + 14],
              ],
              { layers: routeHitLayers }
            );
            if (hitFeatures && hitFeatures.length > 0) {
              const currActiveId = activeRouteRef.current?.id;
              const preferred =
                hitFeatures.find((f) => f.properties?.routeId && f.properties.routeId !== currActiveId) ||
                hitFeatures[0];
              const hitRouteId = preferred?.properties?.routeId;
              if (hitRouteId) {
                const found = routesRef.current.find((r) => r.id === hitRouteId);
                if (found) {
                  handleUserPreviewRouteTapRef.current(found);
                  return;
                }
              }
            }
          } catch {}
        }
      }
      setSelectedPoi(null);
      setSelectedFixedRadar(null);
      setDraggingRadarId(null);
      setDraggedRadarCoords(null);
      closeCommunityAlertImmediate();
      dismissLongPressRef.current();
    };

    map.on('load', handleMapLoaded);
    map.on('idle', handleMapLoaded);
    map.on('sourcedata', handleSourceData);
    map.on('moveend', handleMapMoved);
    map.on('zoomend', handleMapMoved);
    map.on('click', handleMapBgClick);

    // Arranque inmediato en la vista inicial
    schedulePoiRefresh(true);

    return () => {
      map.off('load', handleMapLoaded);
      map.off('idle', handleMapLoaded);
      map.off('sourcedata', handleSourceData);
      map.off('moveend', handleMapMoved);
      map.off('zoomend', handleMapMoved);
      map.off('click', handleMapBgClick);
      if (poiVectorSyncTimerRef.current) {
        clearTimeout(poiVectorSyncTimerRef.current);
        poiVectorSyncTimerRef.current = null;
      }
      if (poiDebounceTimerRef.current) {
        clearTimeout(poiDebounceTimerRef.current);
        poiDebounceTimerRef.current = null;
      }
      if (poiRetryTimerRef.current) {
        clearTimeout(poiRetryTimerRef.current);
        poiRetryTimerRef.current = null;
      }
      if (poiAbortControllerRef.current) {
        poiAbortControllerRef.current.abort();
        poiAbortControllerRef.current = null;
        inFlightPoiBoundsRef.current = null;
      }
    };
  }, [schedulePoiRefresh, syncVectorTilePoisFromMap, syncPoiGeoJsonSource]);

  useEffect(() => {
    setSelectedPoi((prev) => {
      if (
        prev &&
        (!mapSettings.poiEnabled || mapSettings.poiCategories?.[prev.category] === false)
      ) {
        return null;
      }
      return prev;
    });
    if (mapInstanceRef.current) {
      syncPoiGeoJsonSource(mapInstanceRef.current, true);
    }
  }, [mapSettings.poiEnabled, mapSettings.poiCategories, mapTileMode, isNavigating, activeRoute?.id, syncPoiGeoJsonSource]);

  // 7c. Radares fijos referenciales & tramos Sutran (carga por región/ruta, marcadores y franjas)
  const lastFixedRadarScopeKeyRef = useRef<string>('');

  const refreshFixedRadarsData = useCallback(() => {
    const activeRegions = getActiveRegionsForFilter(
      { lat: userLocationRef.current.lat, lng: userLocationRef.current.lng },
      activeRouteRef.current?.coordinates,
      mapSettingsRef.current.fixedRadarRegionFilter || 'auto'
    );
    const merged = getMergedFixedRadarsForRegions(activeRegions);
    setFixedRadarsList(merged);
    onFixedRadarsUpdatedRef.current?.(merged);
  }, []);

  useEffect(() => {
    const activeRegions = getActiveRegionsForFilter(
      { lat: userLocation.lat, lng: userLocation.lng },
      activeRoute?.coordinates,
      mapSettings.fixedRadarRegionFilter || 'auto'
    );
    const regionsKey =
      activeRegions === 'ALL' ? 'ALL' : Array.from(activeRegions).sort().join('|');
    const scopeKey = `${regionsKey}::${Boolean(mapSettings.fixedRadarsEnabled)}::${
      activeRoute?.id || 'none'
    }`;

    if (lastFixedRadarScopeKeyRef.current === scopeKey) {
      return;
    }
    lastFixedRadarScopeKeyRef.current = scopeKey;

    refreshFixedRadarsData();
    if (!mapSettings.fixedRadarsEnabled) return;

    resolvePendingRadarsForRegions(activeRegions, () => {
      refreshFixedRadarsData();
    });
  }, [
    userLocation.lat,
    userLocation.lng,
    activeRoute?.id,
    activeRoute?.coordinates,
    mapSettings.fixedRadarsEnabled,
    mapSettings.fixedRadarRegionFilter,
    refreshFixedRadarsData,
  ]);

  const syncFixedRadarsOnMap = useCallback((map: maplibregl.Map) => {
    fixedRadarMarkersRef.current.forEach((m) => m.remove());
    fixedRadarMarkersRef.current = [];

    const enabled = mapSettingsRef.current.fixedRadarsEnabled !== false;
    const radars = enabled ? fixedRadarsListRef.current : [];

    // 1. Franjas de carretera Sutran en fuente GeoJSON (por debajo de la ruta azul)
    if (isMapStyleReadyForSources(map) && ensureRouteLayers(map)) {
      const stripSrc = map.getSource(FIXED_RADAR_STRIPS_SOURCE_ID) as
        | maplibregl.GeoJSONSource
        | undefined;
      if (stripSrc) {
        const features = radars
          .filter(
            (r) =>
              r.tipo === 'carretera' &&
              Array.isArray(r.tramoCoordenadas) &&
              r.tramoCoordenadas.length >= 2
          )
          .map((r) => ({
            type: 'Feature' as const,
            properties: {
              radarId: r.id,
              nombre: r.nombre,
              precision: r.precision,
            },
            geometry: {
              type: 'LineString' as const,
              coordinates: r.tramoCoordenadas!.map(([lat, lng]) => [lng, lat]),
            },
          }));
        stripSrc.setData({ type: 'FeatureCollection', features });
      }
      const stripsHidden = isOverviewActiveRef.current;
      try {
        if (map.getLayer(FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID)) {
          map.setPaintProperty(
            FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID,
            'line-opacity',
            stripsHidden ? 0 : 0.88
          );
        }
        if (map.getLayer(FIXED_RADAR_STRIPS_FILL_LAYER_ID)) {
          map.setPaintProperty(
            FIXED_RADAR_STRIPS_FILL_LAYER_ID,
            'line-opacity',
            stripsHidden ? 0 : 0.92
          );
        }
      } catch {}
    }

    if (!enabled) return;

    // 2. Marcadores urbanos de cámara de velocidad magenta (distintos a "Radar temporal")
    const currentZoom = map.getZoom();
    const editingId = draggingRadarIdRef.current;
    const hiddenByOverview = isOverviewActiveRef.current;
    const shouldFadeInAfterOverview =
      !hiddenByOverview && justExitedOverviewUntilRef.current > Date.now();

    for (const radar of radars) {
      if (radar.tipo !== 'urbano') continue;
      if (radar.latitud === null || radar.longitud === null) continue;

      const isEditingThis = editingId === radar.id;
      const isHigh = radar.prioridad === 'alta';

      // Prioridad alta visible desde zoom más bajo (11); normal al acercarse (14.2)
      if (!isEditingThis) {
        if (isHigh && currentZoom < 11) continue;
        if (!isHigh && currentZoom < 14.2) continue;
      }

      const sizePx = isHigh ? 36 : 27;
      const isConfirmed = radar.precision === 'confirmado';

      const markerEl = document.createElement('div');
      markerEl.className = 'fixed-radar-marker cursor-pointer';
      markerEl.style.opacity = hiddenByOverview || shouldFadeInAfterOverview ? '0' : '1';
      markerEl.style.pointerEvents = hiddenByOverview ? 'none' : 'auto';
      if (hiddenByOverview) {
        markerEl.setAttribute('aria-hidden', 'true');
      }
      markerEl.style.zIndex = isEditingThis ? '55' : isHigh ? '44' : '42';
      markerEl.title = `${radar.nombre} (${radar.distrito})`;
      markerEl.innerHTML = `
        <div style="position:relative;display:flex;align-items:center;justify-content:center;">
          <div style="
            width:${sizePx}px;
            height:${sizePx}px;
            border-radius:10px;
            background:${isEditingThis ? '#be123c' : '#be185d'};
            border:2px solid ${isEditingThis ? '#fde047' : '#ffffff'};
            box-shadow:${
              isEditingThis
                ? '0 0 0 4px rgba(253,224,71,0.45), 0 6px 14px rgba(0,0,0,0.6)'
                : '0 3px 10px rgba(190,24,93,0.55)'
            };
            display:flex;
            align-items:center;
            justify-content:center;
            color:#ffffff;
          ">
            <svg viewBox="0 0 24 24" width="${Math.round(sizePx * 0.6)}" height="${Math.round(
        sizePx * 0.6
      )}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="4" y="4" width="14" height="10" rx="2.5" fill="rgba(255,255,255,0.18)" />
              <circle cx="11" cy="9" r="2.6" fill="#fbcfe8" />
              <path d="M11 14v6M8 20h6" />
              <circle cx="15.3" cy="6.6" r="1" fill="#fde047" stroke="none" />
            </svg>
          </div>
          ${
            isConfirmed
              ? `<span style="position:absolute;top:-4px;right:-4px;width:12px;height:12px;border-radius:9999px;background:#10b981;border:1.5px solid #ffffff;box-shadow:0 1px 3px rgba(0,0,0,0.4);"></span>`
              : ''
          }
        </div>
      `;

      markerEl.addEventListener('click', (ev) => {
        if (isOverviewActiveRef.current) return;
        if (isPickingRadarLocationRef.current) return;
        ev.stopPropagation();
        if (shouldSuppressMapClick()) return;
        dismissLongPressRef.current();
        if (draggingRadarIdRef.current && draggingRadarIdRef.current !== radar.id) {
          setDraggingRadarId(null);
          setDraggedRadarCoords(null);
        }
        setSelectedPoi(null);
        closeCommunityAlertImmediate();
        setRadarActionFeedback(null);
        setSelectedFixedRadar(radar);
      });

      const marker = new maplibregl.Marker({
        element: markerEl,
        anchor: 'center',
        draggable: isEditingThis,
        rotationAlignment: 'viewport',
        pitchAlignment: 'viewport',
      })
        .setLngLat([radar.longitud, radar.latitud])
        .addTo(map);

      if (shouldFadeInAfterOverview) {
        requestAnimationFrame(() => {
          if (!isOverviewActiveRef.current) {
            markerEl.style.opacity = '1';
          }
        });
      }

      if (isEditingThis) {
        marker.on('dragend', () => {
          const pos = marker.getLngLat();
          setDraggedRadarCoords({ lat: pos.lat, lng: pos.lng });
        });
      }

      fixedRadarMarkersRef.current.push(marker);
    }
  }, [ensureRouteLayers]);

  const syncFixedRadarsOnMapRef = useRef(syncFixedRadarsOnMap);
  syncFixedRadarsOnMapRef.current = syncFixedRadarsOnMap;

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    syncFixedRadarsOnMap(map);
  }, [
    fixedRadarsList,
    mapSettings.fixedRadarsEnabled,
    draggingRadarId,
    mapTileMode,
    syncFixedRadarsOnMap,
  ]);

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    const handleZoomChange = () => {
      if (draggingRadarIdRef.current !== null) return;
      syncFixedRadarsOnMapRef.current(map);
    };
    map.on('zoomend', handleZoomChange);
    return () => {
      map.off('zoomend', handleZoomChange);
      fixedRadarMarkersRef.current.forEach((m) => m.remove());
      fixedRadarMarkersRef.current = [];
    };
  }, []);

  // 7d. Presión larga (~500 ms) sobre el mapa con marcador temporal y opciones "Ruta" y "Compartir"
  const dismissLongPress = useCallback((fromPopstate = false) => {
    if (longPressReverseAbortRef.current) {
      longPressReverseAbortRef.current.abort();
      longPressReverseAbortRef.current = null;
    }
    if (longPressMarkerRef.current) {
      longPressMarkerRef.current.remove();
      longPressMarkerRef.current = null;
    }
    setLongPressPoint(null);
    setLongPressScreenPos(null);
    setShareCopiedToast(false);

    if (!fromPopstate && hasPushedLongPressHistoryRef.current) {
      hasPushedLongPressHistoryRef.current = false;
      if (window.history.state?.rutaLimaLongPress) {
        ignoringLongPressPopstateRef.current = true;
        try {
          window.history.back();
        } catch {
          ignoringLongPressPopstateRef.current = false;
        }
        setTimeout(() => {
          ignoringLongPressPopstateRef.current = false;
        }, 150);
      }
    } else if (fromPopstate) {
      hasPushedLongPressHistoryRef.current = false;
    }
  }, []);

  const dismissLongPressRef = useRef(dismissLongPress);
  dismissLongPressRef.current = dismissLongPress;

  // Cerrar automáticamente si se entra a navegación activa o se abre un panel encima
  useEffect(() => {
    if (isNavigating || isOverlayModalOpen || isSettingsOpen || isAddFixedRadarOpen) {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
        longPressTimerRef.current = null;
      }
      if (longPressPoint) {
        dismissLongPress();
      }
      closeAllSmallOverlays();
    }
  }, [
    isNavigating,
    isOverlayModalOpen,
    isSettingsOpen,
    isAddFixedRadarOpen,
    longPressPoint,
    dismissLongPress,
  ]);

  // Botón atrás del navegador / celular o tecla Escape cierra marcador temporal y ventanita
  useEffect(() => {
    const handlePopState = () => {
      if (ignoringLongPressPopstateRef.current) {
        ignoringLongPressPopstateRef.current = false;
        return;
      }
      if (hasPushedLongPressHistoryRef.current) {
        dismissLongPressRef.current(true);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && longPressMarkerRef.current) {
        dismissLongPressRef.current(false);
      }
    };
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // Sincronizar marcador temporal y posición en pantalla de la ventanita
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (!longPressPoint) {
      if (longPressMarkerRef.current) {
        longPressMarkerRef.current.remove();
        longPressMarkerRef.current = null;
      }
      setLongPressScreenPos(null);
      return;
    }

    if (!longPressMarkerRef.current) {
      const pinEl = document.createElement('div');
      pinEl.className = 'long-press-temp-marker pointer-events-none';
      pinEl.style.zIndex = '52';
      pinEl.innerHTML = `
        <div style="position:relative;display:flex;flex-direction:column;align-items:center;transform:translateY(-6px);">
          <div style="
            width:32px;
            height:32px;
            border-radius:9999px 9999px 9999px 4px;
            transform:rotate(-45deg);
            background:linear-gradient(135deg,#38bdf8,#0284c7);
            border:2.5px solid #ffffff;
            box-shadow:0 6px 16px rgba(2,132,199,0.55);
            display:flex;
            align-items:center;
            justify-content:center;
          ">
            <div style="width:10px;height:10px;border-radius:9999px;background:#ffffff;transform:rotate(45deg);"></div>
          </div>
          <div style="width:10px;height:4px;border-radius:9999px;background:rgba(15,23,42,0.55);margin-top:2px;"></div>
        </div>
      `;
      longPressMarkerRef.current = new maplibregl.Marker({
        element: pinEl,
        anchor: 'bottom',
        rotationAlignment: 'viewport',
        pitchAlignment: 'viewport',
      })
        .setLngLat([longPressPoint.lng, longPressPoint.lat])
        .addTo(map);
    } else {
      longPressMarkerRef.current.setLngLat([longPressPoint.lng, longPressPoint.lat]);
    }

    const updateScreenPos = () => {
      try {
        const projected = map.project([longPressPoint.lng, longPressPoint.lat]);
        const rect = map.getCanvas().getBoundingClientRect();
        setLongPressScreenPos({ x: rect.left + projected.x, y: rect.top + projected.y });
      } catch {}
    };

    updateScreenPos();
    map.on('move', updateScreenPos);
    map.on('zoom', updateScreenPos);
    return () => {
      map.off('move', updateScreenPos);
      map.off('zoom', updateScreenPos);
    };
  }, [longPressPoint]);

  // Listener de presión larga (~500 ms) únicamente sobre el canvas del mapa (sin interferir con gestos ni marcadores)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    const canvas = map.getCanvas();
    if (!canvas) return;

    let startX = 0;
    let startY = 0;
    let lastTouchTime = 0;

    const clearTimer = () => {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
        longPressTimerRef.current = null;
      }
    };

    const openLongPressPopupAt = (lat: number, lng: number) => {
      if (
        isNavigatingRef.current ||
        isAnyOverlayOpenRef.current ||
        draggingRadarIdRef.current !== null ||
        hasAnyOpenSmallOverlay()
      ) {
        return;
      }

      const fallbackCoordsText = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;

      // Cerrar otras tarjetas abiertas para evitar superposición
      setSelectedPoi(null);
      setSelectedFixedRadar(null);
      closeCommunityAlertImmediate();
      setDraggingRadarId(null);
      setShareCopiedToast(false);

      if (longPressReverseAbortRef.current) {
        longPressReverseAbortRef.current.abort();
      }
      const abortCtrl = new AbortController();
      longPressReverseAbortRef.current = abortCtrl;

      if (!hasPushedLongPressHistoryRef.current) {
        try {
          window.history.pushState({ rutaLimaLongPress: true }, '');
          hasPushedLongPressHistoryRef.current = true;
        } catch {}
      }

      setLongPressPoint({
        lat,
        lng,
        label: fallbackCoordsText,
        address: null,
        isLoadingLabel: true,
        addressFound: false,
      });

      reverseGeocodeCoords(lat, lng, abortCtrl.signal).then((geo) => {
        if (abortCtrl.signal.aborted) return;
        setLongPressPoint((prev) => {
          if (!prev || Math.abs(prev.lat - lat) > 1e-6 || Math.abs(prev.lng - lng) > 1e-6) {
            return prev;
          }
          if (!geo) {
            return {
              ...prev,
              isLoadingLabel: false,
              addressFound: false,
            };
          }
          return {
            ...prev,
            label: geo.name,
            address: geo.address,
            district: geo.district,
            isLoadingLabel: false,
            addressFound: true,
          };
        });
      });
    };

    const triggerLongPressAt = (clientX: number, clientY: number) => {
      clearTimer();
      const isPickingRadar = isPickingRadarLocationRef.current;
      if (
        !isPickingRadar &&
        (isNavigatingRef.current ||
          isAnyOverlayOpenRef.current ||
          draggingRadarIdRef.current !== null ||
          hasAnyOpenSmallOverlay() ||
          shouldSuppressMapClick())
      ) {
        return;
      }

      const rect = canvas.getBoundingClientRect();
      const relX = clientX - rect.left;
      const relY = clientY - rect.top;
      if (relX < 0 || relY < 0 || relX > rect.width || relY > rect.height) {
        return;
      }

      let lngLat: maplibregl.LngLat;
      try {
        lngLat = map.unproject([relX, relY]);
      } catch {
        return;
      }

      const lat = lngLat.lat;
      const lng = lngLat.lng;

      // Vibración sutil si el dispositivo lo soporta
      try {
        if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
          navigator.vibrate(35);
        }
      } catch {}

      justTriggeredLongPressRef.current = true;
      setTimeout(() => {
        justTriggeredLongPressRef.current = false;
      }, 350);

      if (isPickingRadar) {
        confirmRadarPickAtCoordsRef.current(lat, lng);
        return;
      }

      openLongPressPopupAt(lat, lng);
    };

    const handleTouchStart = (e: TouchEvent) => {
      lastTouchTime = Date.now();
      if (e.target !== canvas || e.touches.length !== 1) {
        clearTimer();
        return;
      }
      if (
        !isPickingRadarLocationRef.current &&
        (isNavigatingRef.current ||
          isAnyOverlayOpenRef.current ||
          draggingRadarIdRef.current !== null ||
          hasAnyOpenSmallOverlay() ||
          shouldSuppressMapClick())
      ) {
        clearTimer();
        return;
      }
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      clearTimer();
      longPressTimerRef.current = setTimeout(() => {
        triggerLongPressAt(startX, startY);
      }, 500);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!longPressTimerRef.current) return;
      if (e.touches.length !== 1) {
        clearTimer();
        return;
      }
      const dx = e.touches[0].clientX - startX;
      const dy = e.touches[0].clientY - startY;
      if (Math.hypot(dx, dy) > 8) {
        clearTimer();
      }
    };

    const handleTouchEndOrCancel = () => {
      clearTimer();
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (Date.now() - lastTouchTime < 700) return;
      if (e.button !== 0 || e.target !== canvas) {
        clearTimer();
        return;
      }
      if (
        !isPickingRadarLocationRef.current &&
        (isNavigatingRef.current ||
          isAnyOverlayOpenRef.current ||
          draggingRadarIdRef.current !== null ||
          hasAnyOpenSmallOverlay() ||
          shouldSuppressMapClick())
      ) {
        clearTimer();
        return;
      }
      startX = e.clientX;
      startY = e.clientY;
      clearTimer();
      longPressTimerRef.current = setTimeout(() => {
        triggerLongPressAt(startX, startY);
      }, 500);
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!longPressTimerRef.current) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.hypot(dx, dy) > 8) {
        clearTimer();
      }
    };

    const handleMouseUpOrLeave = () => {
      clearTimer();
    };

    const handleContextMenu = (e: MouseEvent) => {
      if (justTriggeredLongPressRef.current || longPressTimerRef.current) {
        e.preventDefault();
      }
    };

    canvas.addEventListener('touchstart', handleTouchStart, { passive: true });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: true });
    canvas.addEventListener('touchend', handleTouchEndOrCancel, { passive: true });
    canvas.addEventListener('touchcancel', handleTouchEndOrCancel, { passive: true });
    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseup', handleMouseUpOrLeave);
    canvas.addEventListener('mouseleave', handleMouseUpOrLeave);
    canvas.addEventListener('contextmenu', handleContextMenu);

    return () => {
      clearTimer();
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEndOrCancel);
      canvas.removeEventListener('touchcancel', handleTouchEndOrCancel);
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseup', handleMouseUpOrLeave);
      canvas.removeEventListener('mouseleave', handleMouseUpOrLeave);
      canvas.removeEventListener('contextmenu', handleContextMenu);
      if (longPressMarkerRef.current) {
        longPressMarkerRef.current.remove();
        longPressMarkerRef.current = null;
      }
    };
  }, []);

  // Sincroniza la visibilidad visual (sin borrar datos) de burbujas de reportes, radares fijos y tramos Sutran en Vista general
  const syncOverviewReportsAndRadarsVisibility = useCallback((map: maplibregl.Map | null) => {
    const hidden = isOverviewActiveRef.current;

    alertMarkersRef.current.forEach((m) => {
      const el = m.getElement();
      if (!el) return;
      el.style.opacity = hidden ? '0' : el.dataset.baseOpacity || '1';
      el.style.pointerEvents = hidden ? 'none' : 'auto';
      if (hidden) {
        el.setAttribute('aria-hidden', 'true');
      } else {
        el.removeAttribute('aria-hidden');
      }
    });

    fixedRadarMarkersRef.current.forEach((m) => {
      const el = m.getElement();
      if (!el) return;
      el.style.opacity = hidden ? '0' : '1';
      el.style.pointerEvents = hidden ? 'none' : 'auto';
      if (hidden) {
        el.setAttribute('aria-hidden', 'true');
      } else {
        el.removeAttribute('aria-hidden');
      }
    });

    if (map && isMapStyleReadyForSources(map)) {
      try {
        if (map.getLayer(FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID)) {
          map.setPaintProperty(
            FIXED_RADAR_STRIPS_OUTLINE_LAYER_ID,
            'line-opacity',
            hidden ? 0 : 0.88
          );
        }
        if (map.getLayer(FIXED_RADAR_STRIPS_FILL_LAYER_ID)) {
          map.setPaintProperty(
            FIXED_RADAR_STRIPS_FILL_LAYER_ID,
            'line-opacity',
            hidden ? 0 : 0.92
          );
        }
      } catch {}
    }
  }, []);

  // Effect for Overview Route button ("Vista general": fit bounds from user to destination using real panel heights)
  useEffect(() => {
    if (
      !overviewTrigger ||
      overviewTrigger === lastHandledOverviewTriggerRef.current ||
      !mapInstanceRef.current
    ) {
      return;
    }
    lastHandledOverviewTriggerRef.current = overviewTrigger;
    const map = mapInstanceRef.current;

    // Ocultar visualmente lugares, reportes, radares fijos y tramos mientras Vista general esté activa
    justExitedOverviewUntilRef.current = 0;
    isOverviewActiveRef.current = true;
    setIsOverviewActive(true);
    setSelectedPoi(null);
    setSelectedFixedRadar(null);
    closeCommunityAlertImmediate();
    updatePoiLayerVisibility(map);
    syncOverviewReportsAndRadarsVisibility(map);
    applyOverviewCleanMapStyle(map, mapTileModeRef.current, overviewSavedLayersRef.current);

    pendingRecenterRef.current = false;
    isAtomicRecenterInFlightRef.current = false;
    if (recenterWaitTimerRef.current) {
      clearTimeout(recenterWaitTimerRef.current);
      recenterWaitTimerRef.current = null;
    }
    if (programmaticClearTimerRef.current) {
      clearTimeout(programmaticClearTimerRef.current);
      programmaticClearTimerRef.current = null;
    }

    isProgrammaticMoveRef.current = true;
    map.stop();

    isManuallyRotatedRef.current = false;
    setIsManuallyRotated(false);
    setIsHeadingUp(false);
    setMapRotation(0);

    const rafId = requestAnimationFrame(() => {
      if (!mapInstanceRef.current) return;

      const currLocation = userLocationRef.current;
      const currRoute = activeRouteRef.current;
      const currDest = destinationCoordsRef.current;

      const bounds = new maplibregl.LngLatBounds();
      bounds.extend([currLocation.lng, currLocation.lat]);

      if (currRoute && currRoute.coordinates && currRoute.coordinates.length > 0) {
        currRoute.coordinates.forEach(([lat, lng]) => bounds.extend([lng, lat]));
      }

      if (currDest) {
        bounds.extend([currDest.lng, currDest.lat]);
      } else if (currRoute?.destinationCoords) {
        bounds.extend([currRoute.destinationCoords.lng, currRoute.destinationCoords.lat]);
      }

      // Measure real on-screen heights of top banner and bottom trip panel / compact bar
      const topBannerEl =
        document.getElementById('turn-by-turn-banner') ||
        (document.querySelector('.top-navigation-bar') as HTMLElement | null);
      const topRect = topBannerEl?.getBoundingClientRect();
      const realTopHeight = topRect ? Math.max(0, Math.round(topRect.bottom)) : 0;

      const compactBarEl = document.getElementById('nav-compact-bar');
      const bottomCardEl = document.querySelector('.bottom-trip-panel .nav-card') as HTMLElement | null;
      const compactH = compactBarEl ? Math.round(compactBarEl.getBoundingClientRect().height) : 0;
      const bottomCardH = bottomCardEl ? Math.round(bottomCardEl.getBoundingClientRect().height) : 0;
      const realBottomHeight = Math.max(compactH, bottomCardH);

      const topPad = realTopHeight + 16;
      const bottomPad = realBottomHeight + 16;
      const sidePad = 24;

      // Calcular el zoom objetivo del encuadre general sin modificarlo, para anclar la aparición gradual de calles al acercar
      try {
        const targetCam = map.cameraForBounds(bounds, {
          padding: { top: topPad, bottom: bottomPad, left: sidePad, right: sidePad },
          bearing: 0,
          maxZoom: 18,
        });
        const targetZoom = typeof targetCam?.zoom === 'number' ? targetCam.zoom : undefined;
        overviewZoomAnchorRef.current = targetZoom;
        if (targetZoom !== undefined) {
          applyOverviewCleanMapStyle(
            map,
            mapTileModeRef.current,
            overviewSavedLayersRef.current,
            targetZoom
          );
        }
      } catch {}

      let overviewCleared = false;
      const clearOverviewFlags = () => {
        if (overviewCleared) return;
        overviewCleared = true;
        if (programmaticClearTimerRef.current) {
          clearTimeout(programmaticClearTimerRef.current);
          programmaticClearTimerRef.current = null;
        }
        map.off('moveend', clearOverviewFlags);
        isProgrammaticMoveRef.current = false;
        isAtomicRecenterInFlightRef.current = false;
      };

      map.once('moveend', clearOverviewFlags);
      programmaticClearTimerRef.current = setTimeout(clearOverviewFlags, 1000);

      beginProgrammaticCameraLock(map, 600);
      map.setPadding({ top: 0, bottom: 0, left: 0, right: 0 });
      map.fitBounds(bounds, {
        padding: { top: topPad, bottom: bottomPad, left: sidePad, right: sidePad },
        bearing: 0,
        pitch: 0,
        maxZoom: 18,
        duration: 600,
      });
    });

    return () => cancelAnimationFrame(rafId);
  }, [overviewTrigger]);

  // Triggered by bottom bar "Volver a centrar" button
  useEffect(() => {
    if (
      !recenterTrigger ||
      recenterTrigger === lastHandledRecenterTriggerRef.current ||
      !mapInstanceRef.current
    ) {
      return;
    }
    lastHandledRecenterTriggerRef.current = recenterTrigger;
    if (isOverviewActiveRef.current) {
      justExitedOverviewUntilRef.current = Date.now() + 900;
    }
    isOverviewActiveRef.current = false;
    setIsOverviewActive(false);
    syncOverviewReportsAndRadarsVisibility(mapInstanceRef.current);
    isManuallyRotatedRef.current = false;
    setIsManuallyRotated(false);
    isIdleAutoOrientActiveRef.current = true;
    idleBearingAnimRef.current.active = false;
    setIsHeadingUp(mapSettingsRef.current.autoRotation);
    executeAtomicRecenter();
  }, [recenterTrigger, executeAtomicRecenter, syncOverviewReportsAndRadarsVisibility]);

  // Salir de Vista general al retomar seguimiento o terminar/cancelar la navegación
  useEffect(() => {
    if (isOverviewActiveRef.current && (!isNavigating || isFollowing)) {
      justExitedOverviewUntilRef.current = Date.now() + 900;
      isOverviewActiveRef.current = false;
      setIsOverviewActive(false);
    }
  }, [isNavigating, isFollowing]);

  // Sincronizar visibilidad visual de lugares, reportes, radares y estilo limpio de mapa al entrar o salir de Vista general
  const prevOverviewActiveRef = useRef<boolean>(false);
  useEffect(() => {
    isOverviewActiveRef.current = isOverviewActive;
    if (prevOverviewActiveRef.current === isOverviewActive) return;
    prevOverviewActiveRef.current = isOverviewActive;

    const map = mapInstanceRef.current;
    if (!isOverviewActive) {
      justExitedOverviewUntilRef.current = Date.now() + 900;
    } else {
      justExitedOverviewUntilRef.current = 0;
    }
    if (map) {
      updatePoiLayerVisibility(map);
      syncOverviewReportsAndRadarsVisibility(map);
      if (isOverviewActive) {
        applyOverviewCleanMapStyle(
          map,
          mapTileModeRef.current,
          overviewSavedLayersRef.current,
          overviewZoomAnchorRef.current
        );
      } else {
        overviewZoomAnchorRef.current = undefined;
        restoreNormalMapStyleFromOverview(
          map,
          mapTileModeRef.current,
          overviewSavedLayersRef.current
        );
        syncBuildings3DLayer(map);
        syncPoiGeoJsonSource(map, true);
      }
    }
  }, [
    isOverviewActive,
    syncBuildings3DLayer,
    syncPoiGeoJsonSource,
    updatePoiLayerVisibility,
    syncOverviewReportsAndRadarsVisibility,
  ]);

  // Compass button (solo visible cuando el mapa fue girado manualmente): vuelve al Norte arriba (bearing 0)
  const handleResetNorthUp = () => {
    const map = mapInstanceRef.current;
    isManuallyRotatedRef.current = false;
    setIsManuallyRotated(false);
    setMapRotation(0);
    if (!map) return;

    isProgrammaticMoveRef.current = true;
    beginProgrammaticCameraLock(map, 400);
    try {
      map.easeTo({
        bearing: 0,
        duration: 350,
      });
    } catch {
      activateFlatFallback(map);
    }
    setTimeout(() => {
      isProgrammaticMoveRef.current = false;
    }, 400);
  };

  // Botón azul de ubicación: en selección de ruta reencuadra toda la ruta; en pantalla principal vuelve a seguimiento inclinado
  const handleCenterOnUserIdle = useCallback(() => {
    const map = mapInstanceRef.current;
    if (map && !isNavigatingRef.current && hasAnyRoutesRef.current) {
      const currRoutes =
        routesRef.current.length > 0
          ? routesRef.current
          : activeRouteRef.current
          ? [activeRouteRef.current]
          : [];
      if (currRoutes.length > 0) {
        const destForBounds =
          activeRouteRef.current?.destinationCoords ||
          routesRef.current[0]?.destinationCoords ||
          destinationCoordsRef.current ||
          null;
        userInteractedInPreviewRef.current = false;
        if (previewFitDebounceTimerRef.current) {
          clearTimeout(previewFitDebounceTimerRef.current);
          previewFitDebounceTimerRef.current = null;
        }
        if (previewFitInitialRafRef.current !== null) {
          cancelAnimationFrame(previewFitInitialRafRef.current);
          previewFitInitialRafRef.current = null;
        }
        runPreviewFitBounds(map, currRoutes, destForBounds, 600, 'location-button');
        return;
      }
    }
    onRequestLocationRef.current?.();
    returnToIdleTrackingView(500);
  }, [returnToIdleTrackingView, runPreviewFitBounds]);

  // Selector de 3 modos: Diurno -> Nocturno -> Satelital -> Diurno
  const handleCycleTileMode = () => {
    if (mapTileMode === 'day') {
      onTileModeChange('night');
    } else if (mapTileMode === 'night') {
      onTileModeChange('satellite');
    } else {
      onTileModeChange('day');
    }
  };

  return (
    <div
      ref={rootContainerRef}
      className={`relative w-full h-full min-h-full overflow-hidden select-none ${
        mapTileMode === 'day' ? 'bg-[#f3f4f6]' : 'bg-slate-950'
      }`}
    >
      {/* Full-screen MapLibre GL WebGL Canvas (100% coverage, zero dark zones, upright street labels) */}
      <div
        ref={mapContainerRef}
        id="ruta-lima-leaflet-map"
        className="relative z-0 w-full h-full min-h-full"
      />

      {pitchFallbackNotice && (
        <button
          type="button"
          onClick={() => {
            if (pitchFallbackTimerRef.current) {
              clearTimeout(pitchFallbackTimerRef.current);
              pitchFallbackTimerRef.current = null;
            }
            setPitchFallbackNotice(null);
          }}
          className="fixed top-24 left-1/2 -translate-x-1/2 z-50 px-3.5 py-2 rounded-xl bg-slate-900/95 text-amber-200 border border-amber-400/50 shadow-lg text-xs font-semibold pointer-events-auto cursor-pointer flex items-center gap-2 hover:bg-slate-800/95 active:scale-95 transition"
          aria-label="Cerrar aviso"
        >
          <span>{pitchFallbackNotice}</span>
          <X className="w-3.5 h-3.5 text-amber-300/90 flex-shrink-0" />
        </button>
      )}

      {/* Píldora con el nombre de la calle actual (Modo Día durante ruta, encima del panel inferior y a la derecha del círculo de velocidad) */}
      {isNavigating && mapTileMode === 'day' && resolvedCurrentStreet && (
        <div
          className="fixed left-[92px] sm:left-[104px] right-3.5 z-30 flex justify-start pointer-events-none select-none transition-all duration-300"
          style={{
            bottom: isFollowing
              ? 'calc(env(safe-area-inset-bottom, 0px) + 102px)'
              : 'calc(env(safe-area-inset-bottom, 0px) + 82px)',
          }}
        >
          <div className="px-3.5 py-1.5 rounded-2xl bg-white/98 text-slate-900 border border-slate-200/95 shadow-[0_3px_12px_rgba(0,0,0,0.22)] font-extrabold text-[13px] leading-[1.2] max-w-[230px] sm:max-w-[280px] line-clamp-2">
            {resolvedCurrentStreet}
          </div>
        </div>
      )}

      {/* Visible Attribution badge */}
      <div className="absolute bottom-2 left-2 z-30 pointer-events-none flex flex-wrap items-center gap-1.5 max-w-[calc(100vw-24px)] select-none">
        <div className="text-[10px] text-slate-400 bg-slate-950/75 backdrop-blur-sm px-2 py-0.5 rounded-md border border-slate-800/80 shadow-sm flex items-center gap-1.5">
          {activeAttributionMode === 'openfreemap' ? (
            <span>
              <a
                href="https://openfreemap.org"
                target="_blank"
                rel="noreferrer"
                className="underline pointer-events-auto hover:text-white"
              >
                OpenFreeMap
              </a>{' '}
              ©{' '}
              <a
                href="https://openmaptiles.org"
                target="_blank"
                rel="noreferrer"
                className="underline pointer-events-auto hover:text-white"
              >
                OpenMapTiles
              </a>
              , datos de{' '}
              <a
                href="https://www.openstreetmap.org/copyright"
                target="_blank"
                rel="noreferrer"
                className="underline pointer-events-auto hover:text-white"
              >
                OpenStreetMap
              </a>
            </span>
          ) : (
            <span>
              ©{' '}
              <a
                href="https://www.openstreetmap.org/copyright"
                target="_blank"
                rel="noreferrer"
                className="underline pointer-events-auto hover:text-white"
              >
                OpenStreetMap
              </a>{' '}
              contributors
            </span>
          )}
        </div>
      </div>

      {/* Floating Action Controls on Right Edge (Centrados verticalmente) */}
      <div
        data-map-control="true"
        className="absolute right-3.5 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-1.5 transition-all duration-300 ease-out translate-x-0 opacity-100 pointer-events-auto"
      >
        {/* 1. Brújula: visible solo cuando el mapa está girado manualmente; al tocarla vuelve al Norte arriba */}
        {isManuallyRotated && Math.abs((((mapRotation % 360) + 540) % 360) - 180) > 1.5 && (
          <button
            type="button"
            onClick={handleResetNorthUp}
            className={`flex items-center justify-center ${controlSizeClass} rounded-2xl border shadow-xl backdrop-blur-md active:scale-95 transition bg-slate-900/90 text-sky-300 border-sky-400/70 hover:bg-slate-800 animate-in fade-in zoom-in-95 duration-150`}
            title="Volver al Norte arriba"
            aria-label="Volver al Norte arriba"
          >
            <Compass
              className="w-5 h-5 transition-transform duration-150"
              style={{
                transform: `rotate(${-mapRotation}deg)`,
              }}
            />
          </button>
        )}

        {/* 2. Ubicación: Botón azul para volver a centrar en el usuario (solo antes de iniciar ruta) */}
        {!isNavigating && (
          <button
            type="button"
            onClick={handleCenterOnUserIdle}
            className={`flex items-center justify-center ${controlSizeClass} rounded-2xl border shadow-xl backdrop-blur-md active:scale-95 transition ${
              isFollowing
                ? 'bg-sky-500 text-white border-sky-300 shadow-sky-500/40'
                : 'bg-blue-600 hover:bg-blue-500 text-white border-sky-400 shadow-blue-500/40'
            }`}
            title="Centrar en mi ubicación"
            aria-label="Centrar en mi ubicación"
          >
            <LocateFixed className="w-5 h-5" />
          </button>
        )}

        {/* 3. Alertas: Advertencias / Incidentes (Triángulo Ámbar Brillante #FFB000) */}
        {onOpenReportIncident && (
          <button
            onClick={onOpenReportIncident}
            className={`flex items-center justify-center ${controlSizeClass} rounded-2xl bg-[#FFB000]/20 hover:bg-[#FFB000]/30 text-[#FFB000] border-2 border-[#FFB000] shadow-[0_0_15px_rgba(255,176,0,0.35)] backdrop-blur-md active:scale-95 transition`}
            title="Reportar advertencia vial o incidente"
            aria-label="Reportar incidente vial"
          >
            <AlertTriangle className="w-5 h-5 text-[#FFB000] fill-[#FFB000]/20" />
          </button>
        )}

        {/* 4. Capas: Selector de Modos de Cartografía (Diurno -> Nocturno -> Satelital) */}
        <button
          onClick={handleCycleTileMode}
          className={`flex items-center justify-center ${controlSizeClass} rounded-2xl bg-slate-900/90 text-slate-200 border border-slate-700/80 shadow-xl backdrop-blur-md hover:bg-slate-800 active:scale-95 transition`}
          title={`Modo actual: ${
            mapTileMode === 'day'
              ? 'Diurno (OpenStreetMap)'
              : mapTileMode === 'night'
              ? 'Nocturno (OpenStreetMap Oscuro)'
              : 'Satelital (Esri Aerial)'
          }. Toca para cambiar.`}
          aria-label="Cambiar estilo de mapa"
        >
          <Layers
            className={`w-5 h-5 ${
              mapTileMode === 'day'
                ? 'text-amber-400'
                : mapTileMode === 'night'
                ? 'text-sky-400'
                : 'text-emerald-400'
            }`}
          />
        </button>

        {/* 5. Ajustes: Configuración de mapa y voz (oculto durante navegación activa) */}
        {!isNavigating && (
          <button
            onClick={() => setIsSettingsOpen(true)}
            className={`flex items-center justify-center ${controlSizeClass} rounded-2xl bg-slate-900/90 text-slate-300 border border-slate-700/80 shadow-xl backdrop-blur-md hover:bg-slate-800 active:scale-95 transition`}
            title="Ajustes de mapa y voz"
            aria-label="Ajustes de mapa"
          >
            <Settings className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Compact Selected POI Card */}
      {selectedPoi && !isOverviewActive && (() => {
        const meta = POI_CATEGORY_META[selectedPoi.category];
        const distMeters = getDistanceMeters(
          userLocation.lat,
          userLocation.lng,
          selectedPoi.lat,
          selectedPoi.lng
        );
        let cardBadgeColor = meta.color;
        let iconMarkup =
          selectedPoi.category === 'restaurant' && selectedPoi.isPizza
            ? PIZZA_ICON_SVG
            : meta.iconSvg;

        if (selectedPoi.category === 'school' && selectedPoi.schoolType === 'private_small') {
          cardBadgeColor = '#b45309';
          iconMarkup = `<span style="color:#ffffff;font-size:15px;font-weight:900;line-height:1;">P</span>`;
        } else if (selectedPoi.category === 'military_academy') {
          switch (selectedPoi.militaryBranch) {
            case 'police_academy':
              cardBadgeColor = '#1e3a8a';
              iconMarkup = `<span style="font-size:17px;line-height:1;">👮</span>`;
              break;
            case 'air_force':
              cardBadgeColor = '#0369a1';
              iconMarkup = `<span style="font-size:17px;line-height:1;">✈️</span>`;
              break;
            case 'navy':
              cardBadgeColor = '#1e293b';
              iconMarkup = `<span style="font-size:17px;line-height:1;">⚓</span>`;
              break;
            case 'army':
            default:
              cardBadgeColor = '#3f6212';
              iconMarkup = `<span style="font-size:17px;line-height:1;">🪖</span>`;
              break;
          }
        }

        const typeDisplayLabel =
          selectedPoi.category === 'hospital' && selectedPoi.amenityTag === 'clinic'
            ? 'Clínica'
            : selectedPoi.category === 'hospital' && selectedPoi.amenityTag === 'hospital'
            ? 'Hospital'
            : selectedPoi.category === 'school'
            ? selectedPoi.schoolType === 'private_small'
              ? 'Colegio privado'
              : 'Colegio nacional'
            : selectedPoi.category === 'institute'
            ? 'Instituto civil'
            : selectedPoi.category === 'university'
            ? 'Universidad'
            : selectedPoi.category === 'military_academy'
            ? selectedPoi.militaryBranch === 'police_academy'
              ? 'Escuela de la Policía Nacional'
              : selectedPoi.militaryBranch === 'air_force'
              ? 'Escuela de la Fuerza Aérea'
              : selectedPoi.militaryBranch === 'navy'
              ? 'Escuela de la Marina de Guerra'
              : 'Escuela del Ejército'
            : selectedPoi.category === 'park'
            ? 'Parque'
            : selectedPoi.isPizza
            ? 'Pizzería'
            : meta.label;
        return (
          <div
            data-small-overlay="poi_card"
            className="fixed inset-x-3 z-40 max-w-sm mx-auto pointer-events-auto animate-in fade-in slide-in-from-bottom-2 duration-200"
            style={{
              bottom: isNavigating
                ? 'calc(env(safe-area-inset-bottom, 0px) + 150px)'
                : 'calc(env(safe-area-inset-bottom, 0px) + 20px)',
            }}
          >
            <div className="rounded-2xl bg-slate-900/95 border border-slate-700/90 shadow-[0_16px_40px_rgba(0,0,0,0.75)] backdrop-blur-xl p-3.5 text-white">
              <div className="flex items-start gap-3">
                <div
                  className={`w-9 h-9 ${
                    selectedPoi.category === 'hospital' ? 'rounded-xl' : 'rounded-full'
                  } border-2 border-white/90 flex items-center justify-center flex-shrink-0 shadow-md mt-0.5`}
                  style={{ backgroundColor: cardBadgeColor }}
                  dangerouslySetInnerHTML={{ __html: iconMarkup }}
                />
                <div className="min-w-0 flex-1">
                  <h4 className="text-sm font-black text-white leading-snug line-clamp-2">
                    {selectedPoi.name}
                  </h4>
                  <div className="flex items-center flex-wrap gap-1.5 mt-0.5 text-[11px] font-semibold text-slate-300">
                    <span className={meta.textClass}>{typeDisplayLabel}</span>
                    <span className="text-slate-500">•</span>
                    <span>A {formatPoiDistance(distMeters)}</span>
                    {selectedPoi.category === 'hospital' && selectedPoi.hasEmergency === true && (
                      <span className="px-1.5 py-0.5 rounded-md bg-red-500/25 border border-red-400/60 text-red-200 text-[10px] font-extrabold">
                        Emergencias
                      </span>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedPoi(null)}
                  className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white active:scale-95 transition flex-shrink-0"
                  aria-label="Cerrar tarjeta de lugar"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="mt-3 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    const target = selectedPoi;
                    setSelectedPoi(null);
                    onNavigateToPOIRef.current?.(target);
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 active:scale-95 text-slate-950 font-black text-xs shadow-lg shadow-sky-500/25 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Navigation className="w-3.5 h-3.5 fill-slate-950" />
                  <span>Ir hasta aquí</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Compact Selected Fixed Radar Card */}
      {selectedFixedRadar && (() => {
        const isConfirmed = selectedFixedRadar.precision === 'confirmado';
        const isEditingThis = draggingRadarId === selectedFixedRadar.id;
        const isHighway = selectedFixedRadar.tipo === 'carretera';
        const hasCoords =
          selectedFixedRadar.latitud !== null && selectedFixedRadar.longitud !== null;
        const distMeters = hasCoords
          ? getDistanceMeters(
              userLocation.lat,
              userLocation.lng,
              selectedFixedRadar.latitud!,
              selectedFixedRadar.longitud!
            )
          : null;

        return (
          <div
            data-small-overlay="radar_card"
            className="fixed inset-x-3 z-40 max-w-sm mx-auto pointer-events-auto animate-in fade-in slide-in-from-bottom-2 duration-200"
            style={{
              bottom: isNavigating
                ? 'calc(env(safe-area-inset-bottom, 0px) + 150px)'
                : 'calc(env(safe-area-inset-bottom, 0px) + 20px)',
            }}
          >
            <div className="rounded-2xl bg-slate-900/95 border border-pink-500/50 shadow-[0_16px_40px_rgba(0,0,0,0.78)] backdrop-blur-xl p-3.5 text-white">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-pink-700 border-2 border-white/90 flex items-center justify-center flex-shrink-0 shadow-md mt-0.5 text-white">
                  <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="4" y="4" width="14" height="10" rx="2.5" fill="rgba(255,255,255,0.18)" />
                    <circle cx="11" cy="9" r="2.6" fill="#fbcfe8" />
                    <path d="M11 14v6M8 20h6" />
                  </svg>
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center flex-wrap gap-1.5 mb-1">
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-black border ${
                        isConfirmed
                          ? 'bg-emerald-500/20 border-emerald-400/60 text-emerald-200'
                          : 'bg-amber-500/20 border-amber-400/60 text-amber-200'
                      }`}
                    >
                      {isConfirmed ? 'Confirmada' : 'Ubicación referencial, puede variar'}
                    </span>
                    {selectedFixedRadar.fuente === 'Sutran' && (
                      <span className="px-2 py-0.5 rounded-md bg-pink-500/20 border border-pink-400/50 text-pink-200 text-[10px] font-black">
                        Fuente: Sutran
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-black text-white leading-snug line-clamp-2">
                    {selectedFixedRadar.direccion}
                  </h4>
                  <div className="flex items-center flex-wrap gap-1.5 mt-0.5 text-[11px] font-semibold text-slate-300">
                    <span>{selectedFixedRadar.distrito}</span>
                    <span className="text-slate-500">•</span>
                    <span>{selectedFixedRadar.region}</span>
                    {distMeters !== null && (
                      <>
                        <span className="text-slate-500">•</span>
                        <span>A {formatPoiDistance(distMeters)}</span>
                      </>
                    )}
                  </div>

                  {selectedFixedRadar.isCommunitySuggested && (
                    <p className="mt-1 text-[10px] text-slate-400 font-semibold">
                      Confirmaciones comunitarias: {selectedFixedRadar.confirmations || 1}/3
                    </p>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setDraggingRadarId(null);
                    setDraggedRadarCoords(null);
                    setRadarActionFeedback(null);
                    setSelectedFixedRadar(null);
                  }}
                  className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white active:scale-95 transition flex-shrink-0"
                  aria-label="Cerrar tarjeta de radar"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {isEditingThis && (
                <div className="mt-2.5 p-2 rounded-xl bg-amber-500/15 border border-amber-400/50 text-[11px] text-amber-100 font-semibold">
                  Arrastra el marcador del radar en el mapa hasta el punto exacto y luego presiona Guardar ubicación.
                </div>
              )}

              {radarActionFeedback && (
                <div className="mt-2 p-2 rounded-xl bg-emerald-500/15 border border-emerald-400/40 text-[11px] text-emerald-200 font-semibold">
                  {radarActionFeedback}
                </div>
              )}

              <div className="mt-3 flex flex-wrap gap-2">
                {isEditingThis ? (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        const lat =
                          draggedRadarCoords?.lat ?? selectedFixedRadar.latitud ?? undefined;
                        const lng =
                          draggedRadarCoords?.lng ?? selectedFixedRadar.longitud ?? undefined;
                        const res = confirmFixedRadarLocation(selectedFixedRadar, lat, lng);
                        setDraggingRadarId(null);
                        setDraggedRadarCoords(null);
                        refreshFixedRadarsData();
                        setSelectedFixedRadar((prev) =>
                          prev
                            ? {
                                ...prev,
                                ...(typeof lat === 'number' && typeof lng === 'number'
                                  ? { latitud: lat, longitud: lng }
                                  : {}),
                                precision: res.precision,
                                confirmations: res.confirmations,
                              }
                            : null
                        );
                        setRadarActionFeedback(
                          res.precision === 'confirmado'
                            ? 'Ubicación guardada como Confirmada.'
                            : `Confirmación registrada (${res.confirmations}/3).`
                        );
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1 cursor-pointer transition"
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>Guardar ubicación</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDraggingRadarId(null);
                        setDraggedRadarCoords(null);
                      }}
                      className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer transition"
                    >
                      Cancelar
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        if (!isHighway) {
                          setDraggingRadarId(selectedFixedRadar.id);
                          setDraggedRadarCoords(
                            hasCoords
                              ? {
                                  lat: selectedFixedRadar.latitud!,
                                  lng: selectedFixedRadar.longitud!,
                                }
                              : null
                          );
                          setRadarActionFeedback(null);
                        } else {
                          const res = confirmFixedRadarLocation(selectedFixedRadar);
                          refreshFixedRadarsData();
                          setSelectedFixedRadar((prev) =>
                            prev ? { ...prev, precision: res.precision } : null
                          );
                          setRadarActionFeedback('Tramo confirmado.');
                        }
                      }}
                      className="flex-1 py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-[11px] flex items-center justify-center gap-1 cursor-pointer transition"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Confirmar ubicación</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const res = reportFixedRadarRemoved(selectedFixedRadar);
                        refreshFixedRadarsData();
                        if (res.isHidden) {
                          setSelectedFixedRadar(null);
                        } else {
                          setRadarActionFeedback(
                            `Reporte "Ya no está" registrado (${res.removedVotes}/3).`
                          );
                        }
                      }}
                      className="py-2 px-2.5 rounded-xl bg-rose-600/85 hover:bg-rose-500 active:scale-95 text-white font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Ya no está</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFixedRadar(null);
                        setIsAddFixedRadarOpen(true);
                      }}
                      className="py-2 px-2.5 rounded-xl bg-pink-600/30 hover:bg-pink-600/45 border border-pink-400/50 text-pink-200 font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer transition"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>Agregar radar</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* Tarjeta unificada y simplificada para TODOS los reportes de la comunidad */}
      {selectedCommunityAlert && (() => {
        const isPolice = selectedCommunityAlert.type === 'police';
        const isInspector = selectedCommunityAlert.type === 'inspectors';

        const titleLabel = isPolice
          ? getPoliceSubtypeLabel(normalizePoliceSubtype(selectedCommunityAlert))
          : isInspector
          ? getInspectorSubtypeLabel(normalizeInspectorSubtype(selectedCommunityAlert))
          : selectedCommunityAlert.title;

        const locationLine = (
          selectedCommunityAlert.address ||
          selectedCommunityAlert.zone ||
          ''
        ).trim();

        const rawDesc = (selectedCommunityAlert.description || '').trim();
        const normalizedDesc = rawDesc.toLowerCase();
        const normalizedTitle = titleLabel.trim().toLowerCase();
        const normalizedAlertTitle = (selectedCommunityAlert.title || '').trim().toLowerCase();
        const customNoteText =
          rawDesc &&
          normalizedDesc !== normalizedTitle &&
          normalizedDesc !== normalizedAlertTitle &&
          normalizedDesc !== 'control de inspectores' &&
          normalizedDesc !== 'reporte de policía' &&
          normalizedDesc !== 'reporte de policia'
            ? rawDesc
            : null;

        const alertVisual =
          !isPolice && !isInspector
            ? getCommunityAlertVisual(selectedCommunityAlert.type)
            : null;

        return (
          <div
            data-small-overlay="alert_popup"
            className={`fixed inset-x-3 z-40 max-w-sm mx-auto transition-all duration-150 ease-out ${
              isCommunityAlertClosing
                ? 'opacity-0 translate-y-2 scale-[0.98] pointer-events-none'
                : 'pointer-events-auto animate-in fade-in slide-in-from-bottom-2 duration-150 opacity-100 translate-y-0 scale-100'
            }`}
            style={{
              bottom: isNavigating
                ? 'calc(env(safe-area-inset-bottom, 0px) + 150px)'
                : 'calc(env(safe-area-inset-bottom, 0px) + 20px)',
            }}
          >
            <div className="rounded-2xl bg-slate-900/95 border border-slate-700/90 shadow-[0_16px_40px_rgba(0,0,0,0.78)] backdrop-blur-xl p-3.5 text-white">
              <div className="flex items-start gap-3">
                {isPolice ? (
                  <div
                    className="flex-shrink-0"
                    dangerouslySetInnerHTML={{
                      __html: renderPoliceMarkerSvg(
                        normalizePoliceSubtype(selectedCommunityAlert),
                        44
                      ),
                    }}
                  />
                ) : isInspector ? (
                  <div className="w-11 h-11 rounded-full overflow-hidden border-2 border-white shadow-md bg-white flex-shrink-0">
                    <img
                      src={getInspectorSubtypeImage(
                        normalizeInspectorSubtype(selectedCommunityAlert)
                      )}
                      alt={titleLabel}
                      className="w-full h-full object-cover scale-[1.04] block pointer-events-none"
                      draggable={false}
                    />
                  </div>
                ) : alertVisual ? (
                  <div
                    className="w-11 h-11 rounded-full border-2 border-white shadow-md flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: alertVisual.bgHex }}
                    dangerouslySetInnerHTML={{ __html: alertVisual.cardIconSvg }}
                  />
                ) : null}

                <div className="min-w-0 flex-1">
                  <h4 className="text-sm font-black text-white leading-snug">
                    {titleLabel}
                  </h4>

                  {locationLine && (
                    <p className="mt-0.5 text-xs font-medium text-slate-300 truncate">
                      {locationLine}
                    </p>
                  )}

                  <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] leading-snug">
                    <span className="font-medium text-slate-400">
                      {formatDirectionLabelSpanish(
                        selectedCommunityAlert.heading,
                        selectedCommunityAlert.bothDirections
                      )}
                    </span>
                    {selectedCommunityAlert.heading !== null &&
                      selectedCommunityAlert.heading !== undefined &&
                      Number.isFinite(selectedCommunityAlert.heading) && (
                        <button
                          type="button"
                          onClick={() =>
                            onToggleAlertBothDirectionsRef.current?.(selectedCommunityAlert.id)
                          }
                          className="font-semibold text-sky-400 hover:text-sky-300 underline underline-offset-2 cursor-pointer"
                        >
                          {selectedCommunityAlert.bothDirections
                            ? 'Solo un sentido'
                            : 'Marcar para ambos sentidos'}
                        </button>
                      )}
                  </div>

                  {customNoteText && (
                    <p className="mt-1 text-xs text-slate-300 leading-snug truncate">
                      {customNoteText}
                    </p>
                  )}
                </div>

                <button
                  type="button"
                  onClick={closeCommunityAlertImmediate}
                  className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white active:scale-95 transition flex-shrink-0"
                  aria-label="Cerrar tarjeta de reporte"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    onConfirmAlertRef.current?.(selectedCommunityAlert.id);
                    closeCommunityAlertSmooth();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-sm flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Sigue ahí</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onRemoveAlertRef.current?.(selectedCommunityAlert.id);
                    closeCommunityAlertSmooth();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-black text-sm flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer"
                >
                  <X className="w-4 h-4 stroke-[3]" />
                  <span>Ya no está</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Modal Agregar Radar Comunitario (Todo el Perú) */}
      <AddFixedRadarModal
        isOpen={isAddFixedRadarOpen}
        isHiddenForMapPick={isPickingRadarLocation}
        onStartMapPick={() => setIsPickingRadarLocation(true)}
        pickedMapCoords={pickedRadarCoords}
        onClose={() => {
          setIsPickingRadarLocation(false);
          setIsAddFixedRadarOpen(false);
        }}
        userCoords={{ lat: userLocation.lat, lng: userLocation.lng }}
        mapCenterCoords={
          mapInstanceRef.current
            ? {
                lat: mapInstanceRef.current.getCenter().lat,
                lng: mapInstanceRef.current.getCenter().lng,
              }
            : null
        }
        onAdded={(newRadar) => {
          refreshFixedRadarsData();
          setSelectedFixedRadar(newRadar);
        }}
      />

      {/* Modo "Elegir en el mapa": barra discreta superior + pin fijo central + confirmar */}
      {isAddFixedRadarOpen && isPickingRadarLocation && (
        <>
          {/* Barra superior discreta */}
          <div
            className="fixed inset-x-3 z-[46] max-w-md mx-auto pointer-events-auto animate-in fade-in slide-in-from-top-2 duration-150"
            style={{ top: 'calc(env(safe-area-inset-top, 0px) + 12px)' }}
          >
            <div className="flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-2xl bg-slate-900/95 border border-pink-500/50 shadow-[0_12px_32px_rgba(0,0,0,0.75)] backdrop-blur-xl text-white">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-xl bg-pink-600/25 border border-pink-400/50 flex items-center justify-center text-pink-300 flex-shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-white leading-snug">
                  Mueve el mapa y toca el lugar del radar
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsPickingRadarLocation(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 text-slate-200 text-xs font-bold flex-shrink-0 cursor-pointer transition"
              >
                Cancelar
              </button>
            </div>
          </div>

          {/* Pin fijo en el centro exacto de la pantalla */}
          <div className="fixed inset-0 pointer-events-none z-[44]">
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-pink-500/35 border border-pink-300/80 shadow-[0_0_12px_rgba(236,72,153,0.7)]" />
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-full pb-0.5 flex flex-col items-center drop-shadow-[0_6px_12px_rgba(0,0,0,0.65)]">
              <div className="w-9 h-9 rounded-full rounded-bl-sm -rotate-45 bg-gradient-to-br from-pink-500 to-rose-600 border-2 border-white flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-white rotate-45" />
              </div>
            </div>
          </div>

          {/* Botón inferior para confirmar el punto del pin central */}
          <div
            className="fixed inset-x-3 z-[46] max-w-xs mx-auto pointer-events-auto animate-in fade-in slide-in-from-bottom-2 duration-150"
            style={{
              bottom: isNavigating
                ? 'calc(env(safe-area-inset-bottom, 0px) + 150px)'
                : 'calc(env(safe-area-inset-bottom, 0px) + 24px)',
            }}
          >
            <button
              type="button"
              onClick={() => {
                const map = mapInstanceRef.current;
                if (map) {
                  const canvas = map.getCanvas();
                  const rect = canvas.getBoundingClientRect();
                  const lngLat = map.unproject([
                    window.innerWidth / 2 - rect.left,
                    window.innerHeight / 2 - rect.top,
                  ]);
                  confirmRadarPickAtCoords(lngLat.lat, lngLat.lng);
                } else {
                  setIsPickingRadarLocation(false);
                }
              }}
              className="w-full py-3 px-4 rounded-2xl bg-pink-600 hover:bg-pink-500 active:scale-95 text-white font-black text-xs shadow-[0_10px_28px_rgba(219,39,119,0.5)] border border-pink-300/60 flex items-center justify-center gap-1.5 cursor-pointer transition"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Confirmar ubicación</span>
            </button>
          </div>
        </>
      )}

      {/* Ventanita pequeña de presión larga junto al marcador temporal ("Ruta" y "Compartir") */}
      {longPressPoint && longPressScreenPos && !isNavigating && (() => {
        const vw = typeof window !== 'undefined' ? window.innerWidth : 390;
        const vh = typeof window !== 'undefined' ? window.innerHeight : 844;
        const cardWidth = Math.min(268, vw - 24);
        const clampedLeft = Math.max(
          12,
          Math.min(vw - cardWidth - 12, Math.round(longPressScreenPos.x - cardWidth / 2))
        );
        const placeBelow = longPressScreenPos.y < 190;
        const cardTop = placeBelow
          ? Math.min(vh - 155, Math.round(longPressScreenPos.y + 14))
          : Math.max(76, Math.round(longPressScreenPos.y - 44));

        const coordsSubtitle = `${longPressPoint.lat.toFixed(5)}, ${longPressPoint.lng.toFixed(5)}`;
        const shareAddressText = longPressPoint.address || longPressPoint.label;
        const osmShareUrl = `https://www.openstreetmap.org/?mlat=${longPressPoint.lat.toFixed(
          6
        )}&mlon=${longPressPoint.lng.toFixed(6)}#map=17/${longPressPoint.lat.toFixed(
          6
        )}/${longPressPoint.lng.toFixed(6)}`;

        const handleCopyLink = async (textToCopy: string) => {
          try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
              await navigator.clipboard.writeText(textToCopy);
            } else {
              const ta = document.createElement('textarea');
              ta.value = textToCopy;
              ta.style.position = 'fixed';
              ta.style.opacity = '0';
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
            }
          } catch {}
          setShareCopiedToast(true);
          setTimeout(() => setShareCopiedToast(false), 2200);
        };

        const handleShareLongPress = async () => {
          const shareMessage = `Mira este lugar: ${shareAddressText}`;
          if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
            try {
              await navigator.share({
                title: longPressPoint.label,
                text: shareMessage,
                url: osmShareUrl,
              });
              return;
            } catch (err: any) {
              if (err?.name === 'AbortError') {
                return;
              }
            }
          }
          await handleCopyLink(osmShareUrl);
        };

        const handleRouteToLongPress = () => {
          const dest: SearchResult = {
            id: `longpress_${Date.now()}`,
            name: longPressPoint.label,
            display_name: shareAddressText,
            lat: longPressPoint.lat,
            lng: longPressPoint.lng,
            district: longPressPoint.district,
            category: 'street',
          };
          dismissLongPress();
          onStartRouteToDestinationRef.current?.(dest);
        };

        return (
          <div
            data-small-overlay="long_press"
            className="fixed z-[45] pointer-events-auto animate-in fade-in zoom-in-95 duration-150"
            style={{
              left: `${clampedLeft}px`,
              top: `${cardTop}px`,
              width: `${cardWidth}px`,
              transform: placeBelow ? 'translateY(0)' : 'translateY(-100%)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="rounded-2xl bg-slate-900/95 border border-slate-700/90 shadow-[0_14px_36px_rgba(0,0,0,0.8)] backdrop-blur-xl p-3 text-white">
              <div className="flex items-start gap-2">
                <div className="w-7 h-7 rounded-xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center flex-shrink-0 text-sky-400 mt-0.5">
                  <MapPin className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    {longPressPoint.isLoadingLabel && (
                      <Loader2 className="w-3 h-3 text-sky-400 animate-spin flex-shrink-0" />
                    )}
                    <p className="text-xs font-black text-white leading-snug line-clamp-2">
                      {longPressPoint.address || longPressPoint.label}
                    </p>
                  </div>
                  {longPressPoint.addressFound && (
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">
                      {coordsSubtitle}
                    </p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => dismissLongPress()}
                  className="p-1 rounded-full bg-slate-800/90 hover:bg-slate-700 text-slate-400 hover:text-white active:scale-95 transition flex-shrink-0 cursor-pointer"
                  aria-label="Cerrar marcador temporal"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {shareCopiedToast && (
                <div className="mt-2 px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 text-[11px] font-bold text-center">
                  Enlace copiado
                </div>
              )}

              <div className="mt-2.5 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleRouteToLongPress}
                  className="py-2 px-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 active:scale-95 text-slate-950 font-black text-xs shadow-md shadow-sky-500/25 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Navigation className="w-3.5 h-3.5 fill-slate-950" />
                  <span>Ruta</span>
                </button>
                <button
                  type="button"
                  onClick={handleShareLongPress}
                  className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-100 border border-slate-600/80 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5 text-sky-400" />
                  <span>Compartir</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Settings Modal */}
      <MapSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={mapSettings}
        onUpdateSettings={handleUpdateSettings}
        onOpenAddFixedRadar={() => setIsAddFixedRadarOpen(true)}
      />
    </div>
  );
};
